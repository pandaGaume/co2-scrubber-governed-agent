// reflect-metadata polyfills Reflect.{define,get}Metadata, used by
// core's class-level decorators (e.g. @runnableAffordance). Core has
// the same import at its barrel, but its sideEffects:false manifest
// lets webpack tree-shake the side-effect import when only specific
// named exports are pulled in. Importing here guarantees the polyfill
// lands in the nodeeditor bundle.
import "reflect-metadata";

// Bundled stylesheet. mini-css-extract-plugin pulls this out of the JS
// bundle into a sibling nodeeditor.css that embedders load via <link>.
// Side-effect import only; nothing is named-exported from this module.
import "./styles/nodeeditor.css";

export { NodeEditor } from "./editor";
export { GraphViewer } from "./components/graph-viewer";
export { enrichNodeDefFromMeta } from "./node-def";
export { registerLifecycleNodes, LIFECYCLE_START_TYPE_ID, LIFECYCLE_STOP_TYPE_ID } from "./lifecycle-nodes";
export { Palette, PALETTE_DRAG_MIME } from "./components/palette";
export type { PaletteOptions } from "./components/palette";
export { Permissions } from "./permissions";
export { StandardsRegistry, renderStandardShields, normalizeStandardSpec } from "./standards";
export type { IStandardInfo, IStandardEntry, StandardSpec } from "./standards";
export { LinkRegistry, NodeRegistry, StartNode, StopNode, RunnableNode, resolveDocPath, listDocLocales } from "spikypanda-core";
export type { ILinkRegistry, ILinkMeta, LinkFactory, INodeRegistry, INodeMeta, NodeFactory } from "spikypanda-core";
export { CONTROL_PORT_ENABLE, CONTROL_PORT_ENABLED, CONTROL_PORT_START, CONTROL_PORT_STOP, CONTROL_PORT_STARTED, CONTROL_PORT_STOPPED } from "spikypanda-core";
export { defaultLayout } from "./auto-layout";
export type { LayoutStrategy } from "./auto-layout";
export { FileHandlerRegistry } from "./file-handler";
export type { FileHandler } from "./file-handler";
export { NodeUI } from "./node-ui";
export { Port } from "./port";
export { Connection, ConnectionPreview, deriveLinkKind } from "./connection";
export type { LinkKind } from "./connection";
export { NavigationStack, SIM_GRAPH_TYPE_ID, SUB_GRAPH_JSON_KEY } from "./navigation-stack";
export type { NavigationLevel } from "./navigation-stack";
export { Breadcrumb } from "./components/breadcrumb";
export { Camera } from "./camera";
export { PropertyPanel } from "./property-panel";
export { UIItemBase, isInspectable, isSerializable } from "./inspectable";
export type { Inspectable, Serializable, PropertyEntry } from "./inspectable";
export { EditorRegistry } from "./editor-registry";
export type { IEditor, EditorFactory } from "./editor-registry";
export { installBuiltinEditors, vector3Editor, vector4Editor, quaternionEditor, numberEditor, sliderEditor, booleanEditor } from "./editors";
export { LiveBinder } from "./live-binder";
export { GraphRunner } from "./graph-runner";
export type { RunnerState, RunnerMode } from "./graph-runner";
export { GraphInferrer } from "./graph-inferrer";
export { buildSessionFromViewer, disposeChannels, syncConfigLinksFromCanvas } from "./graph-session-builder";
export { APPLY_TO_LINK_TYPE, GENERIC_CHANNEL_LINK_TYPE, GENERIC_RELATION_LINK_TYPE } from "./link-model";
export { VariadicReconciler } from "./variadic-reconciler";
export { DebugBus } from "./debug-bus";
export type { DebugLevel, IDebugEntry, DebugHandler } from "./debug-bus";
export { DebugConsole } from "./components/debug-console";
export type { DebugConsoleOptions } from "./components/debug-console";
export { PropertyEditor } from "./components/property-editor";
export type { PropertyEditorOptions } from "./components/property-editor";
export { DocsViewer } from "./components/docs-viewer";
export type { DocsViewerOptions } from "./components/docs-viewer";
export { SkinRegistry } from "./skin-registry";
export type { Skin } from "./skin-registry";
export { darkSkin } from "./styles/skins/dark";
export { lightSkin } from "./styles/skins/light";
export { heliosSkin } from "./styles/skins/helios";
export { transparentDarkSkin, transparentLightSkin } from "./styles/skins/transparent";

// Re-export the editor-schema authoring helpers from core so apps that
// declare their model classes against the nodeeditor bundle do not
// need a separate dependency on spikypanda-core just for decorators.
export { editor, editable, viewable, getEditorSchema } from "spikypanda-core";
export type { IEditableField, IEditorSchema } from "spikypanda-core";
export { PORT_COLORS, arePortTypesCompatible, isConfigLinkType, CONFIG_LINK_TYPES } from "./types";
export type { IPlugin, IPluginContext, IPluginManifest, IPluginNodeEntry, IPluginEditorEntry, ISubPluginManifest } from "./plugin.interfaces";
export { loadPlugin, loadPluginFromUrl } from "./plugin.loader";
export type { LoadPluginOptions, LoadPluginFromUrlOptions, LoadPluginResult } from "./plugin.loader";
export type { PortDirection, PortType, PortDef, NodeDef, Vec2, SerializedGraph, SerializedNode, SerializedConnection } from "./types";

export { Dashboard, isRenderable } from "./dashboard";
export type { IRenderable, ISerializedTile, ISerializedDashboard } from "./dashboard";
