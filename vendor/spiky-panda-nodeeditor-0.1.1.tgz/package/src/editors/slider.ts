import { EditorFactory, IEditor } from "../editor-registry";

interface ISliderOptions {
    readonly min?: number;
    readonly max?: number;
    readonly step?: number;
}

/**
 * Range-input editor for `@editable("slider")` fields.
 *
 * Renders a native `<input type="range">` paired with a numeric readout
 * showing the current value. The range bounds and step are sourced
 * from the @editable options first (static, decorator-supplied), then
 * from the model's own `min` / `max` / `step` properties if present
 * (dynamic, user-editable). When the model exposes those sibling
 * fields, changing them via the property panel updates the slider's
 * bounds live thanks to a per-field subscription on
 * `model.onPropertyChanged`.
 *
 * Used by `NumberSliderNode` for its `value` field; reusable for any
 * runtime node that wants a bounded scalar widget.
 */
export const sliderEditor: EditorFactory = (host, model, propertyName, options, editable): IEditor => {
    if (!propertyName) return { dispose: () => {} };

    const opts = options && typeof options === "object" ? (options as ISliderOptions) : {};

    const wrap = document.createElement("div");
    wrap.style.cssText = "display:flex;gap:8px;align-items:center;width:100%;";

    const input = document.createElement("input");
    input.type = "range";
    input.readOnly = editable === false;
    input.style.cssText = "flex:1;min-width:0;accent-color:var(--ne-color-primary);";

    const readout = document.createElement("span");
    readout.style.cssText = "font-family:var(--ne-font-mono);font-size:0.78em;min-width:48px;text-align:right;" + "color:var(--ne-color-text);flex-shrink:0;";

    const m = model as Record<string, unknown>;
    const numOr = (v: unknown, fallback: number): number => (typeof v === "number" && Number.isFinite(v) ? v : fallback);

    const resolveBounds = (): { min: number; max: number; step: number } => ({
        min: numOr(opts.min, numOr(m.min, 0)),
        max: numOr(opts.max, numOr(m.max, 1)),
        step: numOr(opts.step, numOr(m.step, 0.01)),
    });

    const fmtStep = (step: number): number => {
        // Choose readout precision based on the step magnitude so the
        // user sees `25.00` for a 0.01 slider and `25` for an int slider.
        // Generic formula via -log10(step) so sub-millisecond sliders
        // (e.g. dt sources in [1e-5, 1e-3] for MCSA closed-loop sims)
        // get enough decimals to distinguish positions; capped at 9 to
        // stay readable. Falls back to 0 for step ≤ 0 / NaN / Infinity.
        if (!(step > 0) || !Number.isFinite(step)) return 0;
        if (step >= 1) return 0;
        return Math.min(9, Math.max(0, Math.ceil(-Math.log10(step))));
    };

    const refreshBounds = (): void => {
        const { min, max, step } = resolveBounds();
        input.min = String(min);
        input.max = String(max);
        input.step = String(step);
    };
    refreshBounds();

    const refreshValue = (): void => {
        const v = numOr(m[propertyName], 0);
        if (document.activeElement !== input) {
            input.value = String(v);
        }
        const step = numOr(opts.step, numOr(m.step, 0.01));
        readout.textContent = v.toFixed(fmtStep(step));
    };
    refreshValue();

    input.addEventListener("input", () => {
        const v = Number(input.value);
        if (Number.isFinite(v)) {
            m[propertyName] = v;
            const step = numOr(opts.step, numOr(m.step, 0.01));
            readout.textContent = v.toFixed(fmtStep(step));
        }
    });

    wrap.appendChild(input);
    wrap.appendChild(readout);
    host.appendChild(wrap);

    // Subscribe so external mutations (LiveBinder, drag from a different
    // panel, programmatic set) keep the widget in sync, and so changing
    // min/max/step from sibling fields adjusts the bounds. rAF-coalesced
    // for the same reason as numberEditor: at audio / RF sim rates the
    // bound field can fire onPropertyChanged 1 M+ times per wall second
    // and a synchronous setter + readout update each notification
    // saturates the main thread.
    let valuePending = false;
    let boundsPending = false;
    let rafId: number | null = null;
    const flush = (): void => {
        rafId = null;
        if (boundsPending) {
            refreshBounds();
            boundsPending = false;
        }
        if (valuePending) {
            refreshValue();
            valuePending = false;
        }
    };
    const schedule = (): void => {
        if (rafId === null) rafId = requestAnimationFrame(flush);
    };
    let sub: { dispose(): void } | null = null;
    const candidate = model as { onPropertyChanged?: { add(cb: (args: { propertyName?: string }) => void): { dispose(): void } | null } };
    if (candidate.onPropertyChanged && typeof candidate.onPropertyChanged.add === "function") {
        sub = candidate.onPropertyChanged.add((args) => {
            if (!args) return;
            const p = args.propertyName;
            if (p === propertyName) {
                valuePending = true;
                schedule();
            } else if (p === "min" || p === "max" || p === "step") {
                boundsPending = true;
                valuePending = true;
                schedule();
            }
        });
    }

    return {
        dispose: (): void => {
            if (rafId !== null) cancelAnimationFrame(rafId);
            if (sub) sub.dispose();
            if (wrap.parentNode === host) host.removeChild(wrap);
        },
    };
};
