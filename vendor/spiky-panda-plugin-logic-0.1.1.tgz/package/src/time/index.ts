import type { IPlugin, IPluginContext } from "spikypanda-nodeeditor";
import { ClockNode, DeltaTimeNode } from "../nodes/time.js";
import { TimerNode } from "../nodes/timer.js";
import { TimelineNode } from "../nodes/timeline.js";

const UE5 = ["ue5"] as const;

export const logicTimeSubPlugin: IPlugin = {
    activate(ctx: IPluginContext): void {
        ctx.nodes.register("Logic.Time:clock", () => new ClockNode() as never, {
            label: "Clock",
            docPath: ctx.assetUrl("docs/logic/time/clock.md"),
            category: "Logic.Time",
            inputPorts: [],
            outputPorts: [{ slot: "t", optional: false, type: "float" }],
            standards: UE5,
        });
        ctx.nodes.register("Logic.Time:deltaTime", () => new DeltaTimeNode() as never, {
            label: "Delta Time",
            docPath: ctx.assetUrl("docs/logic/time/deltatime.md"),
            category: "Logic.Time",
            inputPorts: [],
            outputPorts: [{ slot: "dt", optional: false, type: "float" }],
            standards: UE5,
        });
        ctx.nodes.register("Logic.Time:timer", () => new TimerNode() as never, {
            label: "Timer",
            docPath: ctx.assetUrl("docs/logic/time/timer.md"),
            category: "Logic.Time",
            inputPorts: [
                { slot: "duration", optional: true, type: "float" },
                { slot: "from", optional: true, type: "float" },
                { slot: "to", optional: true, type: "float" },
            ],
            outputPorts: [
                { slot: "progress", optional: false, type: "float" },
                { slot: "value", optional: false, type: "float" },
            ],
            standards: UE5,
        });
        // Timeline: a piecewise-constant source, the schedule of a scenario
        // (segments { from, to, value } in session seconds, edited as JSON).
        ctx.nodes.register("Logic.Time:timeline", () => new TimelineNode() as never, {
            label: "Timeline",
            docPath: ctx.assetUrl("docs/logic/time/timeline.md"),
            category: "Logic.Time",
            inputPorts: [],
            outputPorts: [{ slot: "value", optional: false, type: "any" }],
            // For a planner: the schedule of a scenario, whatever the value means; its unit is the consumer's.
            signature: {
                purpose: "a piecewise-constant source in session time: the schedule of a scenario (segments from, to, value), for any quantity",
                inputs: {},
                outputs: { value: { quantity: "Any", description: "the segment's value at the current session time" } },
                capabilities: ["source", "schedule", "scenario", "time"],
            },
        });
    },
};
