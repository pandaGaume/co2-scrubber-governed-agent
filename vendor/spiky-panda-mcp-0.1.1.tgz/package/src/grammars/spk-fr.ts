// Generated from ../../grammars/spk-fr.json on 2026-09-21: a module, not a JSON import, so Node (which demands an import attribute) and webpack load it alike.
export default {
    "registry_list_nodes": {
        "description": "Liste tous les types de nœuds enregistrés par les plugins activés, avec leurs ports, les standards d'interopérabilité déclarés et la documentation résolue. À consulter avant tout câblage : un port déclare un type, une nature flux ou signal, et souvent une unité physique. Relier au jugé produit un graphe que l'exécution refuse.",
        "properties": {
            "locale": "Langue de documentation préférée, par exemple « fr ». Repli sur l'anglais. Les nœuds ne portent pas tous les mêmes langues ; le champ `docLocales` du résultat dit lesquelles existent."
        }
    },
    "registry_describe_node": {
        "description": "Décrit un type de nœud avant de l'instancier. Les ports portent une unité déclarée quand le nœud en a une : c'est le seul typage physique lisible par machine, il faut s'y fier plutôt que de déduire d'après le nom.",
        "properties": {
            "type": "Identifiant de type exactement tel que `registry_list_nodes` le rapporte, par exemple « Physics.Scene ». Un libellé n'est pas un identifiant de type.",
            "locale": "Langue de documentation préférée."
        }
    },
    "registry_thing_model": {
        "description": "Thing Model W3C WoT d'un type de noeud : ses proprietes en affordances JSON Schema avec leur unite UCUM et leurs annotations QUDT, et ses ports en liens. Un Thing Model et non une Thing Description, parce qu'un type du catalogue n'a pas d'instance et donc aucune adresse vers laquelle pointer un formulaire.",
        "properties": {
            "type": "Identifiant de type exactement tel que `registry_list_nodes` le rapporte.",
            "locale": "Langue de documentation preferee."
        }
    },
    "graph_describe": {
        "description": "Le graphe courant : identifiants de nœuds, types, positions et connexions. Tous les autres outils adressent les nœuds par les identifiants trouvés ici, c'est donc normalement le premier appel d'une session."
    },
    "graph_add_node": {
        "description": "Instancie un nœud du catalogue. Les ports proviennent de la déclaration du nœud dans le registre, jamais de l'appelant.",
        "properties": {
            "type": "Identifiant de type issu de `registry_list_nodes`.",
            "x": "Position sur la toile. Mise en page uniquement, sans effet sur la simulation.",
            "y": "Position sur la toile. Mise en page uniquement, sans effet sur la simulation."
        }
    },
    "graph_connect": {
        "description": "Relie un port de sortie à un port d'entrée. Le type de lien se déduit des deux types de ports et ne se fournit jamais. Un refus signifie que les types sont incompatibles, pas que l'appel était mal formé.",
        "properties": {
            "from": "Source, sous la forme { nodeId, port }, désignant un port de sortie.",
            "to": "Destination, sous la forme { nodeId, port }, désignant un port d'entrée."
        }
    },
    "graph_configure": {
        "description": "Applique des propriétés sur plusieurs nœuds en un appel, entièrement validées avant toute écriture. À utiliser pour une cellule d'expérience : écrire la gravité puis l'orientation séparément rend observable un état intermédiaire qui ne correspond à aucune condition voulue.",
        "properties": {
            "nodes": "Une entrée par nœud : { nodeId, properties: { clé: valeur } }."
        }
    },
    "node_describe": {
        "description": "Les propriétés d'un nœud avec leurs valeurs, types et modifiabilité. Le champ `propertySource` indique si elles ont été déclarées par le nœud ou reflétées depuis ses champs publics ; les propriétés reflétées restent modifiables, mais leur type et leur modifiabilité sont déduits et non choisis, donc à prendre comme une indication.",
        "properties": {
            "nodeId": "Identifiant issu de `graph_describe`. Les libellés ne sont jamais acceptés : ils ne sont pas uniques."
        }
    },
    "node_thing_description": {
        "description": "Thing Description W3C WoT 1.1 d'un noeud vivant : chaque propriete declaree devient une affordance portant son type JSON Schema, son unite UCUM, son genre de grandeur QUDT, ses bornes et son caractere lisible seul. A utiliser pour transmettre l'interface d'un noeud a un outil qui parle WoT plutot que ce protocole.",
        "properties": {
            "nodeId": "Identifiant de noeud tel que `graph_describe` le rapporte."
        }
    },
    "node_set_property": {
        "description": "Écrit une propriété. C'est ainsi que se règlent la gravité, l'orientation et la sévérité d'un défaut : ce sont des propriétés de nœuds, pas des commandes dédiées. Un refus rapporte l'explication du nœud lui-même sur la raison de la lecture seule.",
        "properties": {
            "nodeId": "Identifiant issu de `graph_describe`.",
            "key": "Clé de propriété issue de `node_describe`.",
            "value": "Nouvelle valeur, conforme au type déclaré de la propriété."
        }
    },
    "sim_run": {
        "description": "Avance la session d'un nombre explicite de pas, en échantillonnant au passage toutes les captures armées. Ne rien lire avant l'extinction des transitoires : une boucle d'asservissement demande son temps d'établissement et un filtre passe-bas plusieurs de ses constantes de temps. Une fenêtre prise trop tôt mesure le transitoire et non le régime établi. Le runner est mis en pause s'il jouait, pour qu'un seul moteur avance le temps.",
        "properties": {
            "steps": "Nombre de pas. Multiplié par dt, il donne la durée couverte.",
            "dt": "Secondes par pas. À accorder au pas de temps du graphe : un dt trop grossier change le résultat au lieu de simplement le grossir."
        }
    },
    "sim_reset": {
        "description": "Arrête le runner et revient à l'état initial. Détruit la session, si bien qu'un `sim_run` suivant n'a plus rien à avancer tant que le runner n'est pas relancé. Les captures armées survivent."
    },
    "sim_status": {
        "description": "État du runner, existence d'une session vivante, temps courant, index de pas et cadence. Un `hasSession` faux est normal à l'arrêt, ce n'est pas une erreur."
    },
    "capture_arm": {
        "description": "Enregistre des propriétés de nœuds à chaque pas suivant. Un port ne détient sa valeur qu'au pas courant : toute lecture sur fenêtre passe donc par là, armer puis avancer puis relire. Pour une grandeur périodique, prévoir une durée couvrant un nombre entier de périodes, une période partielle biaisant toute estimation à fréquence unique. Armer réinitialise une capture existante au lieu de l'allonger, ce qui souderait deux intervalles de temps sans rapport en une série faussement continue.",
        "properties": {
            "captureId": "Nom de la capture. Par défaut « default ».",
            "signals": "Signaux à enregistrer, sous la forme { nodeId, property }."
        }
    },
    "capture_read": {
        "description": "Restitue la fenêtre enregistrée : le temps de simulation de chaque échantillon et une série de valeurs par signal, alignées par index. Un échantillon manquant ou non numérique vaut NaN plutôt que d'être absent, pour que les séries ne se désalignent jamais de leurs horodatages.",
        "properties": {
            "captureId": "Nom de la capture. Par défaut « default »."
        }
    },
    "sweep_run": {
        "description": "Exécute une grille de configurations et rend une fenêtre enregistrée par cellule. Chaque cellule est configurée, stabilisée sans enregistrement, puis capturée, de sorte qu'une fenêtre ne chevauche jamais le transitoire et le régime établi. À préférer à une boucle manuelle : une grille scène par orientation par défaut compte des dizaines de cellules, et trois allers-retours par cellule transforment une mesure en après-midi.",
        "properties": {
            "cells": "Une entrée par cellule : { label?, nodes: [{ nodeId, properties }] }. Le libellé est restitué tel quel, c'est ce qui rend un grand résultat lisible.",
            "signals": "Signaux enregistrés dans chaque cellule, sous la forme { nodeId, property }.",
            "dt": "Secondes par pas.",
            "settleSteps": "Pas exécutés avant le début de l'enregistrement, pour laisser les transitoires s'éteindre. Non enregistrés.",
            "captureSteps": "Pas enregistrés. Pour une lecture périodique, couvrir un nombre entier de périodes."
        }
    }
} as const;
