"use strict";
var SpkPluginHarness = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key2 of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key2) && key2 !== except)
          __defProp(to, key2, { get: () => from[key2], enumerable: !(desc = __getOwnPropDesc(from, key2)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // studio:core
  var require_core = __commonJS({
    "studio:core"(exports, module) {
      if (!globalThis.SpikypandaCore) throw new Error("Load spikypanda-core.js before SpkPluginHarness.js");
      module.exports = globalThis.SpikypandaCore;
    }
  });

  // node_modules/ajv/dist/compile/codegen/code.js
  var require_code = __commonJS({
    "node_modules/ajv/dist/compile/codegen/code.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.regexpCode = exports.getEsmExportName = exports.getProperty = exports.safeStringify = exports.stringify = exports.strConcat = exports.addCodeArg = exports.str = exports._ = exports.nil = exports._Code = exports.Name = exports.IDENTIFIER = exports._CodeOrName = void 0;
      var _CodeOrName = class {
      };
      exports._CodeOrName = _CodeOrName;
      exports.IDENTIFIER = /^[a-z$_][a-z$_0-9]*$/i;
      var Name = class extends _CodeOrName {
        constructor(s) {
          super();
          if (!exports.IDENTIFIER.test(s))
            throw new Error("CodeGen: name must be a valid identifier");
          this.str = s;
        }
        toString() {
          return this.str;
        }
        emptyStr() {
          return false;
        }
        get names() {
          return { [this.str]: 1 };
        }
      };
      exports.Name = Name;
      var _Code = class extends _CodeOrName {
        constructor(code) {
          super();
          this._items = typeof code === "string" ? [code] : code;
        }
        toString() {
          return this.str;
        }
        emptyStr() {
          if (this._items.length > 1)
            return false;
          const item = this._items[0];
          return item === "" || item === '""';
        }
        get str() {
          var _a;
          return (_a = this._str) !== null && _a !== void 0 ? _a : this._str = this._items.reduce((s, c) => `${s}${c}`, "");
        }
        get names() {
          var _a;
          return (_a = this._names) !== null && _a !== void 0 ? _a : this._names = this._items.reduce((names, c) => {
            if (c instanceof Name)
              names[c.str] = (names[c.str] || 0) + 1;
            return names;
          }, {});
        }
      };
      exports._Code = _Code;
      exports.nil = new _Code("");
      function _(strs, ...args) {
        const code = [strs[0]];
        let i = 0;
        while (i < args.length) {
          addCodeArg(code, args[i]);
          code.push(strs[++i]);
        }
        return new _Code(code);
      }
      exports._ = _;
      var plus = new _Code("+");
      function str(strs, ...args) {
        const expr = [safeStringify(strs[0])];
        let i = 0;
        while (i < args.length) {
          expr.push(plus);
          addCodeArg(expr, args[i]);
          expr.push(plus, safeStringify(strs[++i]));
        }
        optimize(expr);
        return new _Code(expr);
      }
      exports.str = str;
      function addCodeArg(code, arg) {
        if (arg instanceof _Code)
          code.push(...arg._items);
        else if (arg instanceof Name)
          code.push(arg);
        else
          code.push(interpolate(arg));
      }
      exports.addCodeArg = addCodeArg;
      function optimize(expr) {
        let i = 1;
        while (i < expr.length - 1) {
          if (expr[i] === plus) {
            const res = mergeExprItems(expr[i - 1], expr[i + 1]);
            if (res !== void 0) {
              expr.splice(i - 1, 3, res);
              continue;
            }
            expr[i++] = "+";
          }
          i++;
        }
      }
      function mergeExprItems(a, b) {
        if (b === '""')
          return a;
        if (a === '""')
          return b;
        if (typeof a == "string") {
          if (b instanceof Name || a[a.length - 1] !== '"')
            return;
          if (typeof b != "string")
            return `${a.slice(0, -1)}${b}"`;
          if (b[0] === '"')
            return a.slice(0, -1) + b.slice(1);
          return;
        }
        if (typeof b == "string" && b[0] === '"' && !(a instanceof Name))
          return `"${a}${b.slice(1)}`;
        return;
      }
      function strConcat(c1, c2) {
        return c2.emptyStr() ? c1 : c1.emptyStr() ? c2 : str`${c1}${c2}`;
      }
      exports.strConcat = strConcat;
      function interpolate(x) {
        return typeof x == "number" || typeof x == "boolean" || x === null ? x : safeStringify(Array.isArray(x) ? x.join(",") : x);
      }
      function stringify(x) {
        return new _Code(safeStringify(x));
      }
      exports.stringify = stringify;
      function safeStringify(x) {
        return JSON.stringify(x).replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
      }
      exports.safeStringify = safeStringify;
      function getProperty(key2) {
        return typeof key2 == "string" && exports.IDENTIFIER.test(key2) ? new _Code(`.${key2}`) : _`[${key2}]`;
      }
      exports.getProperty = getProperty;
      function getEsmExportName(key2) {
        if (typeof key2 == "string" && exports.IDENTIFIER.test(key2)) {
          return new _Code(`${key2}`);
        }
        throw new Error(`CodeGen: invalid export name: ${key2}, use explicit $id name mapping`);
      }
      exports.getEsmExportName = getEsmExportName;
      function regexpCode(rx) {
        return new _Code(rx.toString());
      }
      exports.regexpCode = regexpCode;
    }
  });

  // node_modules/ajv/dist/compile/codegen/scope.js
  var require_scope = __commonJS({
    "node_modules/ajv/dist/compile/codegen/scope.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.ValueScope = exports.ValueScopeName = exports.Scope = exports.varKinds = exports.UsedValueState = void 0;
      var code_1 = require_code();
      var ValueError = class extends Error {
        constructor(name) {
          super(`CodeGen: "code" for ${name} not defined`);
          this.value = name.value;
        }
      };
      var UsedValueState;
      (function(UsedValueState2) {
        UsedValueState2[UsedValueState2["Started"] = 0] = "Started";
        UsedValueState2[UsedValueState2["Completed"] = 1] = "Completed";
      })(UsedValueState || (exports.UsedValueState = UsedValueState = {}));
      exports.varKinds = {
        const: new code_1.Name("const"),
        let: new code_1.Name("let"),
        var: new code_1.Name("var")
      };
      var Scope = class {
        constructor({ prefixes, parent } = {}) {
          this._names = {};
          this._prefixes = prefixes;
          this._parent = parent;
        }
        toName(nameOrPrefix) {
          return nameOrPrefix instanceof code_1.Name ? nameOrPrefix : this.name(nameOrPrefix);
        }
        name(prefix) {
          return new code_1.Name(this._newName(prefix));
        }
        _newName(prefix) {
          const ng = this._names[prefix] || this._nameGroup(prefix);
          return `${prefix}${ng.index++}`;
        }
        _nameGroup(prefix) {
          var _a, _b;
          if (((_b = (_a = this._parent) === null || _a === void 0 ? void 0 : _a._prefixes) === null || _b === void 0 ? void 0 : _b.has(prefix)) || this._prefixes && !this._prefixes.has(prefix)) {
            throw new Error(`CodeGen: prefix "${prefix}" is not allowed in this scope`);
          }
          return this._names[prefix] = { prefix, index: 0 };
        }
      };
      exports.Scope = Scope;
      var ValueScopeName = class extends code_1.Name {
        constructor(prefix, nameStr) {
          super(nameStr);
          this.prefix = prefix;
        }
        setValue(value, { property, itemIndex }) {
          this.value = value;
          this.scopePath = (0, code_1._)`.${new code_1.Name(property)}[${itemIndex}]`;
        }
      };
      exports.ValueScopeName = ValueScopeName;
      var line = (0, code_1._)`\n`;
      var ValueScope = class extends Scope {
        constructor(opts) {
          super(opts);
          this._values = {};
          this._scope = opts.scope;
          this.opts = { ...opts, _n: opts.lines ? line : code_1.nil };
        }
        get() {
          return this._scope;
        }
        name(prefix) {
          return new ValueScopeName(prefix, this._newName(prefix));
        }
        value(nameOrPrefix, value) {
          var _a;
          if (value.ref === void 0)
            throw new Error("CodeGen: ref must be passed in value");
          const name = this.toName(nameOrPrefix);
          const { prefix } = name;
          const valueKey = (_a = value.key) !== null && _a !== void 0 ? _a : value.ref;
          let vs = this._values[prefix];
          if (vs) {
            const _name = vs.get(valueKey);
            if (_name)
              return _name;
          } else {
            vs = this._values[prefix] = /* @__PURE__ */ new Map();
          }
          vs.set(valueKey, name);
          const s = this._scope[prefix] || (this._scope[prefix] = []);
          const itemIndex = s.length;
          s[itemIndex] = value.ref;
          name.setValue(value, { property: prefix, itemIndex });
          return name;
        }
        getValue(prefix, keyOrRef) {
          const vs = this._values[prefix];
          if (!vs)
            return;
          return vs.get(keyOrRef);
        }
        scopeRefs(scopeName, values = this._values) {
          return this._reduceValues(values, (name) => {
            if (name.scopePath === void 0)
              throw new Error(`CodeGen: name "${name}" has no value`);
            return (0, code_1._)`${scopeName}${name.scopePath}`;
          });
        }
        scopeCode(values = this._values, usedValues, getCode) {
          return this._reduceValues(values, (name) => {
            if (name.value === void 0)
              throw new Error(`CodeGen: name "${name}" has no value`);
            return name.value.code;
          }, usedValues, getCode);
        }
        _reduceValues(values, valueCode, usedValues = {}, getCode) {
          let code = code_1.nil;
          for (const prefix in values) {
            const vs = values[prefix];
            if (!vs)
              continue;
            const nameSet = usedValues[prefix] = usedValues[prefix] || /* @__PURE__ */ new Map();
            vs.forEach((name) => {
              if (nameSet.has(name))
                return;
              nameSet.set(name, UsedValueState.Started);
              let c = valueCode(name);
              if (c) {
                const def = this.opts.es5 ? exports.varKinds.var : exports.varKinds.const;
                code = (0, code_1._)`${code}${def} ${name} = ${c};${this.opts._n}`;
              } else if (c = getCode === null || getCode === void 0 ? void 0 : getCode(name)) {
                code = (0, code_1._)`${code}${c}${this.opts._n}`;
              } else {
                throw new ValueError(name);
              }
              nameSet.set(name, UsedValueState.Completed);
            });
          }
          return code;
        }
      };
      exports.ValueScope = ValueScope;
    }
  });

  // node_modules/ajv/dist/compile/codegen/index.js
  var require_codegen = __commonJS({
    "node_modules/ajv/dist/compile/codegen/index.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.or = exports.and = exports.not = exports.CodeGen = exports.operators = exports.varKinds = exports.ValueScopeName = exports.ValueScope = exports.Scope = exports.Name = exports.regexpCode = exports.stringify = exports.getProperty = exports.nil = exports.strConcat = exports.str = exports._ = void 0;
      var code_1 = require_code();
      var scope_1 = require_scope();
      var code_2 = require_code();
      Object.defineProperty(exports, "_", { enumerable: true, get: function() {
        return code_2._;
      } });
      Object.defineProperty(exports, "str", { enumerable: true, get: function() {
        return code_2.str;
      } });
      Object.defineProperty(exports, "strConcat", { enumerable: true, get: function() {
        return code_2.strConcat;
      } });
      Object.defineProperty(exports, "nil", { enumerable: true, get: function() {
        return code_2.nil;
      } });
      Object.defineProperty(exports, "getProperty", { enumerable: true, get: function() {
        return code_2.getProperty;
      } });
      Object.defineProperty(exports, "stringify", { enumerable: true, get: function() {
        return code_2.stringify;
      } });
      Object.defineProperty(exports, "regexpCode", { enumerable: true, get: function() {
        return code_2.regexpCode;
      } });
      Object.defineProperty(exports, "Name", { enumerable: true, get: function() {
        return code_2.Name;
      } });
      var scope_2 = require_scope();
      Object.defineProperty(exports, "Scope", { enumerable: true, get: function() {
        return scope_2.Scope;
      } });
      Object.defineProperty(exports, "ValueScope", { enumerable: true, get: function() {
        return scope_2.ValueScope;
      } });
      Object.defineProperty(exports, "ValueScopeName", { enumerable: true, get: function() {
        return scope_2.ValueScopeName;
      } });
      Object.defineProperty(exports, "varKinds", { enumerable: true, get: function() {
        return scope_2.varKinds;
      } });
      exports.operators = {
        GT: new code_1._Code(">"),
        GTE: new code_1._Code(">="),
        LT: new code_1._Code("<"),
        LTE: new code_1._Code("<="),
        EQ: new code_1._Code("==="),
        NEQ: new code_1._Code("!=="),
        NOT: new code_1._Code("!"),
        OR: new code_1._Code("||"),
        AND: new code_1._Code("&&"),
        ADD: new code_1._Code("+")
      };
      var Node = class {
        optimizeNodes() {
          return this;
        }
        optimizeNames(_names, _constants) {
          return this;
        }
      };
      var Def = class extends Node {
        constructor(varKind, name, rhs) {
          super();
          this.varKind = varKind;
          this.name = name;
          this.rhs = rhs;
        }
        render({ es5, _n }) {
          const varKind = es5 ? scope_1.varKinds.var : this.varKind;
          const rhs = this.rhs === void 0 ? "" : ` = ${this.rhs}`;
          return `${varKind} ${this.name}${rhs};` + _n;
        }
        optimizeNames(names, constants) {
          if (!names[this.name.str])
            return;
          if (this.rhs)
            this.rhs = optimizeExpr(this.rhs, names, constants);
          return this;
        }
        get names() {
          return this.rhs instanceof code_1._CodeOrName ? this.rhs.names : {};
        }
      };
      var Assign = class extends Node {
        constructor(lhs, rhs, sideEffects) {
          super();
          this.lhs = lhs;
          this.rhs = rhs;
          this.sideEffects = sideEffects;
        }
        render({ _n }) {
          return `${this.lhs} = ${this.rhs};` + _n;
        }
        optimizeNames(names, constants) {
          if (this.lhs instanceof code_1.Name && !names[this.lhs.str] && !this.sideEffects)
            return;
          this.rhs = optimizeExpr(this.rhs, names, constants);
          return this;
        }
        get names() {
          const names = this.lhs instanceof code_1.Name ? {} : { ...this.lhs.names };
          return addExprNames(names, this.rhs);
        }
      };
      var AssignOp = class extends Assign {
        constructor(lhs, op, rhs, sideEffects) {
          super(lhs, rhs, sideEffects);
          this.op = op;
        }
        render({ _n }) {
          return `${this.lhs} ${this.op}= ${this.rhs};` + _n;
        }
      };
      var Label = class extends Node {
        constructor(label) {
          super();
          this.label = label;
          this.names = {};
        }
        render({ _n }) {
          return `${this.label}:` + _n;
        }
      };
      var Break = class extends Node {
        constructor(label) {
          super();
          this.label = label;
          this.names = {};
        }
        render({ _n }) {
          const label = this.label ? ` ${this.label}` : "";
          return `break${label};` + _n;
        }
      };
      var Throw = class extends Node {
        constructor(error) {
          super();
          this.error = error;
        }
        render({ _n }) {
          return `throw ${this.error};` + _n;
        }
        get names() {
          return this.error.names;
        }
      };
      var AnyCode = class extends Node {
        constructor(code) {
          super();
          this.code = code;
        }
        render({ _n }) {
          return `${this.code};` + _n;
        }
        optimizeNodes() {
          return `${this.code}` ? this : void 0;
        }
        optimizeNames(names, constants) {
          this.code = optimizeExpr(this.code, names, constants);
          return this;
        }
        get names() {
          return this.code instanceof code_1._CodeOrName ? this.code.names : {};
        }
      };
      var ParentNode = class extends Node {
        constructor(nodes = []) {
          super();
          this.nodes = nodes;
        }
        render(opts) {
          return this.nodes.reduce((code, n) => code + n.render(opts), "");
        }
        optimizeNodes() {
          const { nodes } = this;
          let i = nodes.length;
          while (i--) {
            const n = nodes[i].optimizeNodes();
            if (Array.isArray(n))
              nodes.splice(i, 1, ...n);
            else if (n)
              nodes[i] = n;
            else
              nodes.splice(i, 1);
          }
          return nodes.length > 0 ? this : void 0;
        }
        optimizeNames(names, constants) {
          const { nodes } = this;
          let i = nodes.length;
          while (i--) {
            const n = nodes[i];
            if (n.optimizeNames(names, constants))
              continue;
            subtractNames(names, n.names);
            nodes.splice(i, 1);
          }
          return nodes.length > 0 ? this : void 0;
        }
        get names() {
          return this.nodes.reduce((names, n) => addNames(names, n.names), {});
        }
      };
      var BlockNode = class extends ParentNode {
        render(opts) {
          return "{" + opts._n + super.render(opts) + "}" + opts._n;
        }
      };
      var Root = class extends ParentNode {
      };
      var Else = class extends BlockNode {
      };
      Else.kind = "else";
      var If = class _If extends BlockNode {
        constructor(condition, nodes) {
          super(nodes);
          this.condition = condition;
        }
        render(opts) {
          let code = `if(${this.condition})` + super.render(opts);
          if (this.else)
            code += "else " + this.else.render(opts);
          return code;
        }
        optimizeNodes() {
          super.optimizeNodes();
          const cond = this.condition;
          if (cond === true)
            return this.nodes;
          let e = this.else;
          if (e) {
            const ns = e.optimizeNodes();
            e = this.else = Array.isArray(ns) ? new Else(ns) : ns;
          }
          if (e) {
            if (cond === false)
              return e instanceof _If ? e : e.nodes;
            if (this.nodes.length)
              return this;
            return new _If(not(cond), e instanceof _If ? [e] : e.nodes);
          }
          if (cond === false || !this.nodes.length)
            return void 0;
          return this;
        }
        optimizeNames(names, constants) {
          var _a;
          this.else = (_a = this.else) === null || _a === void 0 ? void 0 : _a.optimizeNames(names, constants);
          if (!(super.optimizeNames(names, constants) || this.else))
            return;
          this.condition = optimizeExpr(this.condition, names, constants);
          return this;
        }
        get names() {
          const names = super.names;
          addExprNames(names, this.condition);
          if (this.else)
            addNames(names, this.else.names);
          return names;
        }
      };
      If.kind = "if";
      var For = class extends BlockNode {
      };
      For.kind = "for";
      var ForLoop = class extends For {
        constructor(iteration) {
          super();
          this.iteration = iteration;
        }
        render(opts) {
          return `for(${this.iteration})` + super.render(opts);
        }
        optimizeNames(names, constants) {
          if (!super.optimizeNames(names, constants))
            return;
          this.iteration = optimizeExpr(this.iteration, names, constants);
          return this;
        }
        get names() {
          return addNames(super.names, this.iteration.names);
        }
      };
      var ForRange = class extends For {
        constructor(varKind, name, from, to) {
          super();
          this.varKind = varKind;
          this.name = name;
          this.from = from;
          this.to = to;
        }
        render(opts) {
          const varKind = opts.es5 ? scope_1.varKinds.var : this.varKind;
          const { name, from, to } = this;
          return `for(${varKind} ${name}=${from}; ${name}<${to}; ${name}++)` + super.render(opts);
        }
        get names() {
          const names = addExprNames(super.names, this.from);
          return addExprNames(names, this.to);
        }
      };
      var ForIter = class extends For {
        constructor(loop, varKind, name, iterable) {
          super();
          this.loop = loop;
          this.varKind = varKind;
          this.name = name;
          this.iterable = iterable;
        }
        render(opts) {
          return `for(${this.varKind} ${this.name} ${this.loop} ${this.iterable})` + super.render(opts);
        }
        optimizeNames(names, constants) {
          if (!super.optimizeNames(names, constants))
            return;
          this.iterable = optimizeExpr(this.iterable, names, constants);
          return this;
        }
        get names() {
          return addNames(super.names, this.iterable.names);
        }
      };
      var Func = class extends BlockNode {
        constructor(name, args, async) {
          super();
          this.name = name;
          this.args = args;
          this.async = async;
        }
        render(opts) {
          const _async = this.async ? "async " : "";
          return `${_async}function ${this.name}(${this.args})` + super.render(opts);
        }
      };
      Func.kind = "func";
      var Return = class extends ParentNode {
        render(opts) {
          return "return " + super.render(opts);
        }
      };
      Return.kind = "return";
      var Try = class extends BlockNode {
        render(opts) {
          let code = "try" + super.render(opts);
          if (this.catch)
            code += this.catch.render(opts);
          if (this.finally)
            code += this.finally.render(opts);
          return code;
        }
        optimizeNodes() {
          var _a, _b;
          super.optimizeNodes();
          (_a = this.catch) === null || _a === void 0 ? void 0 : _a.optimizeNodes();
          (_b = this.finally) === null || _b === void 0 ? void 0 : _b.optimizeNodes();
          return this;
        }
        optimizeNames(names, constants) {
          var _a, _b;
          super.optimizeNames(names, constants);
          (_a = this.catch) === null || _a === void 0 ? void 0 : _a.optimizeNames(names, constants);
          (_b = this.finally) === null || _b === void 0 ? void 0 : _b.optimizeNames(names, constants);
          return this;
        }
        get names() {
          const names = super.names;
          if (this.catch)
            addNames(names, this.catch.names);
          if (this.finally)
            addNames(names, this.finally.names);
          return names;
        }
      };
      var Catch = class extends BlockNode {
        constructor(error) {
          super();
          this.error = error;
        }
        render(opts) {
          return `catch(${this.error})` + super.render(opts);
        }
      };
      Catch.kind = "catch";
      var Finally = class extends BlockNode {
        render(opts) {
          return "finally" + super.render(opts);
        }
      };
      Finally.kind = "finally";
      var CodeGen = class {
        constructor(extScope, opts = {}) {
          this._values = {};
          this._blockStarts = [];
          this._constants = {};
          this.opts = { ...opts, _n: opts.lines ? "\n" : "" };
          this._extScope = extScope;
          this._scope = new scope_1.Scope({ parent: extScope });
          this._nodes = [new Root()];
        }
        toString() {
          return this._root.render(this.opts);
        }
        // returns unique name in the internal scope
        name(prefix) {
          return this._scope.name(prefix);
        }
        // reserves unique name in the external scope
        scopeName(prefix) {
          return this._extScope.name(prefix);
        }
        // reserves unique name in the external scope and assigns value to it
        scopeValue(prefixOrName, value) {
          const name = this._extScope.value(prefixOrName, value);
          const vs = this._values[name.prefix] || (this._values[name.prefix] = /* @__PURE__ */ new Set());
          vs.add(name);
          return name;
        }
        getScopeValue(prefix, keyOrRef) {
          return this._extScope.getValue(prefix, keyOrRef);
        }
        // return code that assigns values in the external scope to the names that are used internally
        // (same names that were returned by gen.scopeName or gen.scopeValue)
        scopeRefs(scopeName) {
          return this._extScope.scopeRefs(scopeName, this._values);
        }
        scopeCode() {
          return this._extScope.scopeCode(this._values);
        }
        _def(varKind, nameOrPrefix, rhs, constant) {
          const name = this._scope.toName(nameOrPrefix);
          if (rhs !== void 0 && constant)
            this._constants[name.str] = rhs;
          this._leafNode(new Def(varKind, name, rhs));
          return name;
        }
        // `const` declaration (`var` in es5 mode)
        const(nameOrPrefix, rhs, _constant) {
          return this._def(scope_1.varKinds.const, nameOrPrefix, rhs, _constant);
        }
        // `let` declaration with optional assignment (`var` in es5 mode)
        let(nameOrPrefix, rhs, _constant) {
          return this._def(scope_1.varKinds.let, nameOrPrefix, rhs, _constant);
        }
        // `var` declaration with optional assignment
        var(nameOrPrefix, rhs, _constant) {
          return this._def(scope_1.varKinds.var, nameOrPrefix, rhs, _constant);
        }
        // assignment code
        assign(lhs, rhs, sideEffects) {
          return this._leafNode(new Assign(lhs, rhs, sideEffects));
        }
        // `+=` code
        add(lhs, rhs) {
          return this._leafNode(new AssignOp(lhs, exports.operators.ADD, rhs));
        }
        // appends passed SafeExpr to code or executes Block
        code(c) {
          if (typeof c == "function")
            c();
          else if (c !== code_1.nil)
            this._leafNode(new AnyCode(c));
          return this;
        }
        // returns code for object literal for the passed argument list of key-value pairs
        object(...keyValues) {
          const code = ["{"];
          for (const [key2, value] of keyValues) {
            if (code.length > 1)
              code.push(",");
            code.push(key2);
            if (key2 !== value || this.opts.es5) {
              code.push(":");
              (0, code_1.addCodeArg)(code, value);
            }
          }
          code.push("}");
          return new code_1._Code(code);
        }
        // `if` clause (or statement if `thenBody` and, optionally, `elseBody` are passed)
        if(condition, thenBody, elseBody) {
          this._blockNode(new If(condition));
          if (thenBody && elseBody) {
            this.code(thenBody).else().code(elseBody).endIf();
          } else if (thenBody) {
            this.code(thenBody).endIf();
          } else if (elseBody) {
            throw new Error('CodeGen: "else" body without "then" body');
          }
          return this;
        }
        // `else if` clause - invalid without `if` or after `else` clauses
        elseIf(condition) {
          return this._elseNode(new If(condition));
        }
        // `else` clause - only valid after `if` or `else if` clauses
        else() {
          return this._elseNode(new Else());
        }
        // end `if` statement (needed if gen.if was used only with condition)
        endIf() {
          return this._endBlockNode(If, Else);
        }
        _for(node, forBody) {
          this._blockNode(node);
          if (forBody)
            this.code(forBody).endFor();
          return this;
        }
        // a generic `for` clause (or statement if `forBody` is passed)
        for(iteration, forBody) {
          return this._for(new ForLoop(iteration), forBody);
        }
        // `for` statement for a range of values
        forRange(nameOrPrefix, from, to, forBody, varKind = this.opts.es5 ? scope_1.varKinds.var : scope_1.varKinds.let) {
          const name = this._scope.toName(nameOrPrefix);
          return this._for(new ForRange(varKind, name, from, to), () => forBody(name));
        }
        // `for-of` statement (in es5 mode replace with a normal for loop)
        forOf(nameOrPrefix, iterable, forBody, varKind = scope_1.varKinds.const) {
          const name = this._scope.toName(nameOrPrefix);
          if (this.opts.es5) {
            const arr = iterable instanceof code_1.Name ? iterable : this.var("_arr", iterable);
            return this.forRange("_i", 0, (0, code_1._)`${arr}.length`, (i) => {
              this.var(name, (0, code_1._)`${arr}[${i}]`);
              forBody(name);
            });
          }
          return this._for(new ForIter("of", varKind, name, iterable), () => forBody(name));
        }
        // `for-in` statement.
        // With option `ownProperties` replaced with a `for-of` loop for object keys
        forIn(nameOrPrefix, obj, forBody, varKind = this.opts.es5 ? scope_1.varKinds.var : scope_1.varKinds.const) {
          if (this.opts.ownProperties) {
            return this.forOf(nameOrPrefix, (0, code_1._)`Object.keys(${obj})`, forBody);
          }
          const name = this._scope.toName(nameOrPrefix);
          return this._for(new ForIter("in", varKind, name, obj), () => forBody(name));
        }
        // end `for` loop
        endFor() {
          return this._endBlockNode(For);
        }
        // `label` statement
        label(label) {
          return this._leafNode(new Label(label));
        }
        // `break` statement
        break(label) {
          return this._leafNode(new Break(label));
        }
        // `return` statement
        return(value) {
          const node = new Return();
          this._blockNode(node);
          this.code(value);
          if (node.nodes.length !== 1)
            throw new Error('CodeGen: "return" should have one node');
          return this._endBlockNode(Return);
        }
        // `try` statement
        try(tryBody, catchCode, finallyCode) {
          if (!catchCode && !finallyCode)
            throw new Error('CodeGen: "try" without "catch" and "finally"');
          const node = new Try();
          this._blockNode(node);
          this.code(tryBody);
          if (catchCode) {
            const error = this.name("e");
            this._currNode = node.catch = new Catch(error);
            catchCode(error);
          }
          if (finallyCode) {
            this._currNode = node.finally = new Finally();
            this.code(finallyCode);
          }
          return this._endBlockNode(Catch, Finally);
        }
        // `throw` statement
        throw(error) {
          return this._leafNode(new Throw(error));
        }
        // start self-balancing block
        block(body, nodeCount) {
          this._blockStarts.push(this._nodes.length);
          if (body)
            this.code(body).endBlock(nodeCount);
          return this;
        }
        // end the current self-balancing block
        endBlock(nodeCount) {
          const len = this._blockStarts.pop();
          if (len === void 0)
            throw new Error("CodeGen: not in self-balancing block");
          const toClose = this._nodes.length - len;
          if (toClose < 0 || nodeCount !== void 0 && toClose !== nodeCount) {
            throw new Error(`CodeGen: wrong number of nodes: ${toClose} vs ${nodeCount} expected`);
          }
          this._nodes.length = len;
          return this;
        }
        // `function` heading (or definition if funcBody is passed)
        func(name, args = code_1.nil, async, funcBody) {
          this._blockNode(new Func(name, args, async));
          if (funcBody)
            this.code(funcBody).endFunc();
          return this;
        }
        // end function definition
        endFunc() {
          return this._endBlockNode(Func);
        }
        optimize(n = 1) {
          while (n-- > 0) {
            this._root.optimizeNodes();
            this._root.optimizeNames(this._root.names, this._constants);
          }
        }
        _leafNode(node) {
          this._currNode.nodes.push(node);
          return this;
        }
        _blockNode(node) {
          this._currNode.nodes.push(node);
          this._nodes.push(node);
        }
        _endBlockNode(N1, N2) {
          const n = this._currNode;
          if (n instanceof N1 || N2 && n instanceof N2) {
            this._nodes.pop();
            return this;
          }
          throw new Error(`CodeGen: not in block "${N2 ? `${N1.kind}/${N2.kind}` : N1.kind}"`);
        }
        _elseNode(node) {
          const n = this._currNode;
          if (!(n instanceof If)) {
            throw new Error('CodeGen: "else" without "if"');
          }
          this._currNode = n.else = node;
          return this;
        }
        get _root() {
          return this._nodes[0];
        }
        get _currNode() {
          const ns = this._nodes;
          return ns[ns.length - 1];
        }
        set _currNode(node) {
          const ns = this._nodes;
          ns[ns.length - 1] = node;
        }
      };
      exports.CodeGen = CodeGen;
      function addNames(names, from) {
        for (const n in from)
          names[n] = (names[n] || 0) + (from[n] || 0);
        return names;
      }
      function addExprNames(names, from) {
        return from instanceof code_1._CodeOrName ? addNames(names, from.names) : names;
      }
      function optimizeExpr(expr, names, constants) {
        if (expr instanceof code_1.Name)
          return replaceName(expr);
        if (!canOptimize(expr))
          return expr;
        return new code_1._Code(expr._items.reduce((items, c) => {
          if (c instanceof code_1.Name)
            c = replaceName(c);
          if (c instanceof code_1._Code)
            items.push(...c._items);
          else
            items.push(c);
          return items;
        }, []));
        function replaceName(n) {
          const c = constants[n.str];
          if (c === void 0 || names[n.str] !== 1)
            return n;
          delete names[n.str];
          return c;
        }
        function canOptimize(e) {
          return e instanceof code_1._Code && e._items.some((c) => c instanceof code_1.Name && names[c.str] === 1 && constants[c.str] !== void 0);
        }
      }
      function subtractNames(names, from) {
        for (const n in from)
          names[n] = (names[n] || 0) - (from[n] || 0);
      }
      function not(x) {
        return typeof x == "boolean" || typeof x == "number" || x === null ? !x : (0, code_1._)`!${par(x)}`;
      }
      exports.not = not;
      var andCode = mappend(exports.operators.AND);
      function and(...args) {
        return args.reduce(andCode);
      }
      exports.and = and;
      var orCode = mappend(exports.operators.OR);
      function or(...args) {
        return args.reduce(orCode);
      }
      exports.or = or;
      function mappend(op) {
        return (x, y) => x === code_1.nil ? y : y === code_1.nil ? x : (0, code_1._)`${par(x)} ${op} ${par(y)}`;
      }
      function par(x) {
        return x instanceof code_1.Name ? x : (0, code_1._)`(${x})`;
      }
    }
  });

  // node_modules/ajv/dist/compile/util.js
  var require_util = __commonJS({
    "node_modules/ajv/dist/compile/util.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.checkStrictMode = exports.getErrorPath = exports.Type = exports.useFunc = exports.setEvaluated = exports.evaluatedPropsToName = exports.mergeEvaluated = exports.eachItem = exports.unescapeJsonPointer = exports.escapeJsonPointer = exports.escapeFragment = exports.unescapeFragment = exports.schemaRefOrVal = exports.schemaHasRulesButRef = exports.schemaHasRules = exports.checkUnknownRules = exports.alwaysValidSchema = exports.toHash = void 0;
      var codegen_1 = require_codegen();
      var code_1 = require_code();
      function toHash(arr) {
        const hash = {};
        for (const item of arr)
          hash[item] = true;
        return hash;
      }
      exports.toHash = toHash;
      function alwaysValidSchema(it, schema) {
        if (typeof schema == "boolean")
          return schema;
        if (Object.keys(schema).length === 0)
          return true;
        checkUnknownRules(it, schema);
        return !schemaHasRules(schema, it.self.RULES.all);
      }
      exports.alwaysValidSchema = alwaysValidSchema;
      function checkUnknownRules(it, schema = it.schema) {
        const { opts, self } = it;
        if (!opts.strictSchema)
          return;
        if (typeof schema === "boolean")
          return;
        const rules = self.RULES.keywords;
        for (const key2 in schema) {
          if (!rules[key2])
            checkStrictMode(it, `unknown keyword: "${key2}"`);
        }
      }
      exports.checkUnknownRules = checkUnknownRules;
      function schemaHasRules(schema, rules) {
        if (typeof schema == "boolean")
          return !schema;
        for (const key2 in schema)
          if (rules[key2])
            return true;
        return false;
      }
      exports.schemaHasRules = schemaHasRules;
      function schemaHasRulesButRef(schema, RULES) {
        if (typeof schema == "boolean")
          return !schema;
        for (const key2 in schema)
          if (key2 !== "$ref" && RULES.all[key2])
            return true;
        return false;
      }
      exports.schemaHasRulesButRef = schemaHasRulesButRef;
      function schemaRefOrVal({ topSchemaRef, schemaPath }, schema, keyword, $data) {
        if (!$data) {
          if (typeof schema == "number" || typeof schema == "boolean")
            return schema;
          if (typeof schema == "string")
            return (0, codegen_1._)`${schema}`;
        }
        return (0, codegen_1._)`${topSchemaRef}${schemaPath}${(0, codegen_1.getProperty)(keyword)}`;
      }
      exports.schemaRefOrVal = schemaRefOrVal;
      function unescapeFragment(str) {
        return unescapeJsonPointer(decodeURIComponent(str));
      }
      exports.unescapeFragment = unescapeFragment;
      function escapeFragment(str) {
        return encodeURIComponent(escapeJsonPointer(str));
      }
      exports.escapeFragment = escapeFragment;
      function escapeJsonPointer(str) {
        if (typeof str == "number")
          return `${str}`;
        return str.replace(/~/g, "~0").replace(/\//g, "~1");
      }
      exports.escapeJsonPointer = escapeJsonPointer;
      function unescapeJsonPointer(str) {
        return str.replace(/~1/g, "/").replace(/~0/g, "~");
      }
      exports.unescapeJsonPointer = unescapeJsonPointer;
      function eachItem(xs, f) {
        if (Array.isArray(xs)) {
          for (const x of xs)
            f(x);
        } else {
          f(xs);
        }
      }
      exports.eachItem = eachItem;
      function makeMergeEvaluated({ mergeNames, mergeToName, mergeValues, resultToName }) {
        return (gen, from, to, toName) => {
          const res = to === void 0 ? from : to instanceof codegen_1.Name ? (from instanceof codegen_1.Name ? mergeNames(gen, from, to) : mergeToName(gen, from, to), to) : from instanceof codegen_1.Name ? (mergeToName(gen, to, from), from) : mergeValues(from, to);
          return toName === codegen_1.Name && !(res instanceof codegen_1.Name) ? resultToName(gen, res) : res;
        };
      }
      exports.mergeEvaluated = {
        props: makeMergeEvaluated({
          mergeNames: (gen, from, to) => gen.if((0, codegen_1._)`${to} !== true && ${from} !== undefined`, () => {
            gen.if((0, codegen_1._)`${from} === true`, () => gen.assign(to, true), () => gen.assign(to, (0, codegen_1._)`${to} || {}`).code((0, codegen_1._)`Object.assign(${to}, ${from})`));
          }),
          mergeToName: (gen, from, to) => gen.if((0, codegen_1._)`${to} !== true`, () => {
            if (from === true) {
              gen.assign(to, true);
            } else {
              gen.assign(to, (0, codegen_1._)`${to} || {}`);
              setEvaluated(gen, to, from);
            }
          }),
          mergeValues: (from, to) => from === true ? true : { ...from, ...to },
          resultToName: evaluatedPropsToName
        }),
        items: makeMergeEvaluated({
          mergeNames: (gen, from, to) => gen.if((0, codegen_1._)`${to} !== true && ${from} !== undefined`, () => gen.assign(to, (0, codegen_1._)`${from} === true ? true : ${to} > ${from} ? ${to} : ${from}`)),
          mergeToName: (gen, from, to) => gen.if((0, codegen_1._)`${to} !== true`, () => gen.assign(to, from === true ? true : (0, codegen_1._)`${to} > ${from} ? ${to} : ${from}`)),
          mergeValues: (from, to) => from === true ? true : Math.max(from, to),
          resultToName: (gen, items) => gen.var("items", items)
        })
      };
      function evaluatedPropsToName(gen, ps) {
        if (ps === true)
          return gen.var("props", true);
        const props = gen.var("props", (0, codegen_1._)`{}`);
        if (ps !== void 0)
          setEvaluated(gen, props, ps);
        return props;
      }
      exports.evaluatedPropsToName = evaluatedPropsToName;
      function setEvaluated(gen, props, ps) {
        Object.keys(ps).forEach((p) => gen.assign((0, codegen_1._)`${props}${(0, codegen_1.getProperty)(p)}`, true));
      }
      exports.setEvaluated = setEvaluated;
      var snippets = {};
      function useFunc(gen, f) {
        return gen.scopeValue("func", {
          ref: f,
          code: snippets[f.code] || (snippets[f.code] = new code_1._Code(f.code))
        });
      }
      exports.useFunc = useFunc;
      var Type;
      (function(Type2) {
        Type2[Type2["Num"] = 0] = "Num";
        Type2[Type2["Str"] = 1] = "Str";
      })(Type || (exports.Type = Type = {}));
      function getErrorPath(dataProp, dataPropType, jsPropertySyntax) {
        if (dataProp instanceof codegen_1.Name) {
          const isNumber = dataPropType === Type.Num;
          return jsPropertySyntax ? isNumber ? (0, codegen_1._)`"[" + ${dataProp} + "]"` : (0, codegen_1._)`"['" + ${dataProp} + "']"` : isNumber ? (0, codegen_1._)`"/" + ${dataProp}` : (0, codegen_1._)`"/" + ${dataProp}.replace(/~/g, "~0").replace(/\\//g, "~1")`;
        }
        return jsPropertySyntax ? (0, codegen_1.getProperty)(dataProp).toString() : "/" + escapeJsonPointer(dataProp);
      }
      exports.getErrorPath = getErrorPath;
      function checkStrictMode(it, msg, mode = it.opts.strictSchema) {
        if (!mode)
          return;
        msg = `strict mode: ${msg}`;
        if (mode === true)
          throw new Error(msg);
        it.self.logger.warn(msg);
      }
      exports.checkStrictMode = checkStrictMode;
    }
  });

  // node_modules/ajv/dist/compile/names.js
  var require_names = __commonJS({
    "node_modules/ajv/dist/compile/names.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var codegen_1 = require_codegen();
      var names = {
        // validation function arguments
        data: new codegen_1.Name("data"),
        // data passed to validation function
        // args passed from referencing schema
        valCxt: new codegen_1.Name("valCxt"),
        // validation/data context - should not be used directly, it is destructured to the names below
        instancePath: new codegen_1.Name("instancePath"),
        parentData: new codegen_1.Name("parentData"),
        parentDataProperty: new codegen_1.Name("parentDataProperty"),
        rootData: new codegen_1.Name("rootData"),
        // root data - same as the data passed to the first/top validation function
        dynamicAnchors: new codegen_1.Name("dynamicAnchors"),
        // used to support recursiveRef and dynamicRef
        // function scoped variables
        vErrors: new codegen_1.Name("vErrors"),
        // null or array of validation errors
        errors: new codegen_1.Name("errors"),
        // counter of validation errors
        this: new codegen_1.Name("this"),
        // "globals"
        self: new codegen_1.Name("self"),
        scope: new codegen_1.Name("scope"),
        // JTD serialize/parse name for JSON string and position
        json: new codegen_1.Name("json"),
        jsonPos: new codegen_1.Name("jsonPos"),
        jsonLen: new codegen_1.Name("jsonLen"),
        jsonPart: new codegen_1.Name("jsonPart")
      };
      exports.default = names;
    }
  });

  // node_modules/ajv/dist/compile/errors.js
  var require_errors = __commonJS({
    "node_modules/ajv/dist/compile/errors.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.extendErrors = exports.resetErrorsCount = exports.reportExtraError = exports.reportError = exports.keyword$DataError = exports.keywordError = void 0;
      var codegen_1 = require_codegen();
      var util_1 = require_util();
      var names_1 = require_names();
      exports.keywordError = {
        message: ({ keyword }) => (0, codegen_1.str)`must pass "${keyword}" keyword validation`
      };
      exports.keyword$DataError = {
        message: ({ keyword, schemaType }) => schemaType ? (0, codegen_1.str)`"${keyword}" keyword must be ${schemaType} ($data)` : (0, codegen_1.str)`"${keyword}" keyword is invalid ($data)`
      };
      function reportError(cxt, error = exports.keywordError, errorPaths, overrideAllErrors) {
        const { it } = cxt;
        const { gen, compositeRule, allErrors } = it;
        const errObj = errorObjectCode(cxt, error, errorPaths);
        if (overrideAllErrors !== null && overrideAllErrors !== void 0 ? overrideAllErrors : compositeRule || allErrors) {
          addError(gen, errObj);
        } else {
          returnErrors(it, (0, codegen_1._)`[${errObj}]`);
        }
      }
      exports.reportError = reportError;
      function reportExtraError(cxt, error = exports.keywordError, errorPaths) {
        const { it } = cxt;
        const { gen, compositeRule, allErrors } = it;
        const errObj = errorObjectCode(cxt, error, errorPaths);
        addError(gen, errObj);
        if (!(compositeRule || allErrors)) {
          returnErrors(it, names_1.default.vErrors);
        }
      }
      exports.reportExtraError = reportExtraError;
      function resetErrorsCount(gen, errsCount) {
        gen.assign(names_1.default.errors, errsCount);
        gen.if((0, codegen_1._)`${names_1.default.vErrors} !== null`, () => gen.if(errsCount, () => gen.assign((0, codegen_1._)`${names_1.default.vErrors}.length`, errsCount), () => gen.assign(names_1.default.vErrors, null)));
      }
      exports.resetErrorsCount = resetErrorsCount;
      function extendErrors({ gen, keyword, schemaValue, data, errsCount, it }) {
        if (errsCount === void 0)
          throw new Error("ajv implementation error");
        const err = gen.name("err");
        gen.forRange("i", errsCount, names_1.default.errors, (i) => {
          gen.const(err, (0, codegen_1._)`${names_1.default.vErrors}[${i}]`);
          gen.if((0, codegen_1._)`${err}.instancePath === undefined`, () => gen.assign((0, codegen_1._)`${err}.instancePath`, (0, codegen_1.strConcat)(names_1.default.instancePath, it.errorPath)));
          gen.assign((0, codegen_1._)`${err}.schemaPath`, (0, codegen_1.str)`${it.errSchemaPath}/${keyword}`);
          if (it.opts.verbose) {
            gen.assign((0, codegen_1._)`${err}.schema`, schemaValue);
            gen.assign((0, codegen_1._)`${err}.data`, data);
          }
        });
      }
      exports.extendErrors = extendErrors;
      function addError(gen, errObj) {
        const err = gen.const("err", errObj);
        gen.if((0, codegen_1._)`${names_1.default.vErrors} === null`, () => gen.assign(names_1.default.vErrors, (0, codegen_1._)`[${err}]`), (0, codegen_1._)`${names_1.default.vErrors}.push(${err})`);
        gen.code((0, codegen_1._)`${names_1.default.errors}++`);
      }
      function returnErrors(it, errs) {
        const { gen, validateName, schemaEnv } = it;
        if (schemaEnv.$async) {
          gen.throw((0, codegen_1._)`new ${it.ValidationError}(${errs})`);
        } else {
          gen.assign((0, codegen_1._)`${validateName}.errors`, errs);
          gen.return(false);
        }
      }
      var E = {
        keyword: new codegen_1.Name("keyword"),
        schemaPath: new codegen_1.Name("schemaPath"),
        // also used in JTD errors
        params: new codegen_1.Name("params"),
        propertyName: new codegen_1.Name("propertyName"),
        message: new codegen_1.Name("message"),
        schema: new codegen_1.Name("schema"),
        parentSchema: new codegen_1.Name("parentSchema")
      };
      function errorObjectCode(cxt, error, errorPaths) {
        const { createErrors } = cxt.it;
        if (createErrors === false)
          return (0, codegen_1._)`{}`;
        return errorObject(cxt, error, errorPaths);
      }
      function errorObject(cxt, error, errorPaths = {}) {
        const { gen, it } = cxt;
        const keyValues = [
          errorInstancePath(it, errorPaths),
          errorSchemaPath(cxt, errorPaths)
        ];
        extraErrorProps(cxt, error, keyValues);
        return gen.object(...keyValues);
      }
      function errorInstancePath({ errorPath }, { instancePath }) {
        const instPath = instancePath ? (0, codegen_1.str)`${errorPath}${(0, util_1.getErrorPath)(instancePath, util_1.Type.Str)}` : errorPath;
        return [names_1.default.instancePath, (0, codegen_1.strConcat)(names_1.default.instancePath, instPath)];
      }
      function errorSchemaPath({ keyword, it: { errSchemaPath } }, { schemaPath, parentSchema }) {
        let schPath = parentSchema ? errSchemaPath : (0, codegen_1.str)`${errSchemaPath}/${keyword}`;
        if (schemaPath) {
          schPath = (0, codegen_1.str)`${schPath}${(0, util_1.getErrorPath)(schemaPath, util_1.Type.Str)}`;
        }
        return [E.schemaPath, schPath];
      }
      function extraErrorProps(cxt, { params, message }, keyValues) {
        const { keyword, data, schemaValue, it } = cxt;
        const { opts, propertyName, topSchemaRef, schemaPath } = it;
        keyValues.push([E.keyword, keyword], [E.params, typeof params == "function" ? params(cxt) : params || (0, codegen_1._)`{}`]);
        if (opts.messages) {
          keyValues.push([E.message, typeof message == "function" ? message(cxt) : message]);
        }
        if (opts.verbose) {
          keyValues.push([E.schema, schemaValue], [E.parentSchema, (0, codegen_1._)`${topSchemaRef}${schemaPath}`], [names_1.default.data, data]);
        }
        if (propertyName)
          keyValues.push([E.propertyName, propertyName]);
      }
    }
  });

  // node_modules/ajv/dist/compile/validate/boolSchema.js
  var require_boolSchema = __commonJS({
    "node_modules/ajv/dist/compile/validate/boolSchema.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.boolOrEmptySchema = exports.topBoolOrEmptySchema = void 0;
      var errors_1 = require_errors();
      var codegen_1 = require_codegen();
      var names_1 = require_names();
      var boolError = {
        message: "boolean schema is false"
      };
      function topBoolOrEmptySchema(it) {
        const { gen, schema, validateName } = it;
        if (schema === false) {
          falseSchemaError(it, false);
        } else if (typeof schema == "object" && schema.$async === true) {
          gen.return(names_1.default.data);
        } else {
          gen.assign((0, codegen_1._)`${validateName}.errors`, null);
          gen.return(true);
        }
      }
      exports.topBoolOrEmptySchema = topBoolOrEmptySchema;
      function boolOrEmptySchema(it, valid) {
        const { gen, schema } = it;
        if (schema === false) {
          gen.var(valid, false);
          falseSchemaError(it);
        } else {
          gen.var(valid, true);
        }
      }
      exports.boolOrEmptySchema = boolOrEmptySchema;
      function falseSchemaError(it, overrideAllErrors) {
        const { gen, data } = it;
        const cxt = {
          gen,
          keyword: "false schema",
          data,
          schema: false,
          schemaCode: false,
          schemaValue: false,
          params: {},
          it
        };
        (0, errors_1.reportError)(cxt, boolError, void 0, overrideAllErrors);
      }
    }
  });

  // node_modules/ajv/dist/compile/rules.js
  var require_rules = __commonJS({
    "node_modules/ajv/dist/compile/rules.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.getRules = exports.isJSONType = void 0;
      var _jsonTypes = ["string", "number", "integer", "boolean", "null", "object", "array"];
      var jsonTypes = new Set(_jsonTypes);
      function isJSONType(x) {
        return typeof x == "string" && jsonTypes.has(x);
      }
      exports.isJSONType = isJSONType;
      function getRules() {
        const groups = {
          number: { type: "number", rules: [] },
          string: { type: "string", rules: [] },
          array: { type: "array", rules: [] },
          object: { type: "object", rules: [] }
        };
        return {
          types: { ...groups, integer: true, boolean: true, null: true },
          rules: [{ rules: [] }, groups.number, groups.string, groups.array, groups.object],
          post: { rules: [] },
          all: {},
          keywords: {}
        };
      }
      exports.getRules = getRules;
    }
  });

  // node_modules/ajv/dist/compile/validate/applicability.js
  var require_applicability = __commonJS({
    "node_modules/ajv/dist/compile/validate/applicability.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.shouldUseRule = exports.shouldUseGroup = exports.schemaHasRulesForType = void 0;
      function schemaHasRulesForType({ schema, self }, type) {
        const group = self.RULES.types[type];
        return group && group !== true && shouldUseGroup(schema, group);
      }
      exports.schemaHasRulesForType = schemaHasRulesForType;
      function shouldUseGroup(schema, group) {
        return group.rules.some((rule) => shouldUseRule(schema, rule));
      }
      exports.shouldUseGroup = shouldUseGroup;
      function shouldUseRule(schema, rule) {
        var _a;
        return schema[rule.keyword] !== void 0 || ((_a = rule.definition.implements) === null || _a === void 0 ? void 0 : _a.some((kwd) => schema[kwd] !== void 0));
      }
      exports.shouldUseRule = shouldUseRule;
    }
  });

  // node_modules/ajv/dist/compile/validate/dataType.js
  var require_dataType = __commonJS({
    "node_modules/ajv/dist/compile/validate/dataType.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.reportTypeError = exports.checkDataTypes = exports.checkDataType = exports.coerceAndCheckDataType = exports.getJSONTypes = exports.getSchemaTypes = exports.DataType = void 0;
      var rules_1 = require_rules();
      var applicability_1 = require_applicability();
      var errors_1 = require_errors();
      var codegen_1 = require_codegen();
      var util_1 = require_util();
      var DataType;
      (function(DataType2) {
        DataType2[DataType2["Correct"] = 0] = "Correct";
        DataType2[DataType2["Wrong"] = 1] = "Wrong";
      })(DataType || (exports.DataType = DataType = {}));
      function getSchemaTypes(schema) {
        const types = getJSONTypes(schema.type);
        const hasNull = types.includes("null");
        if (hasNull) {
          if (schema.nullable === false)
            throw new Error("type: null contradicts nullable: false");
        } else {
          if (!types.length && schema.nullable !== void 0) {
            throw new Error('"nullable" cannot be used without "type"');
          }
          if (schema.nullable === true)
            types.push("null");
        }
        return types;
      }
      exports.getSchemaTypes = getSchemaTypes;
      function getJSONTypes(ts) {
        const types = Array.isArray(ts) ? ts : ts ? [ts] : [];
        if (types.every(rules_1.isJSONType))
          return types;
        throw new Error("type must be JSONType or JSONType[]: " + types.join(","));
      }
      exports.getJSONTypes = getJSONTypes;
      function coerceAndCheckDataType(it, types) {
        const { gen, data, opts } = it;
        const coerceTo = coerceToTypes(types, opts.coerceTypes);
        const checkTypes = types.length > 0 && !(coerceTo.length === 0 && types.length === 1 && (0, applicability_1.schemaHasRulesForType)(it, types[0]));
        if (checkTypes) {
          const wrongType = checkDataTypes(types, data, opts.strictNumbers, DataType.Wrong);
          gen.if(wrongType, () => {
            if (coerceTo.length)
              coerceData(it, types, coerceTo);
            else
              reportTypeError(it);
          });
        }
        return checkTypes;
      }
      exports.coerceAndCheckDataType = coerceAndCheckDataType;
      var COERCIBLE = /* @__PURE__ */ new Set(["string", "number", "integer", "boolean", "null"]);
      function coerceToTypes(types, coerceTypes) {
        return coerceTypes ? types.filter((t) => COERCIBLE.has(t) || coerceTypes === "array" && t === "array") : [];
      }
      function coerceData(it, types, coerceTo) {
        const { gen, data, opts } = it;
        const dataType = gen.let("dataType", (0, codegen_1._)`typeof ${data}`);
        const coerced = gen.let("coerced", (0, codegen_1._)`undefined`);
        if (opts.coerceTypes === "array") {
          gen.if((0, codegen_1._)`${dataType} == 'object' && Array.isArray(${data}) && ${data}.length == 1`, () => gen.assign(data, (0, codegen_1._)`${data}[0]`).assign(dataType, (0, codegen_1._)`typeof ${data}`).if(checkDataTypes(types, data, opts.strictNumbers), () => gen.assign(coerced, data)));
        }
        gen.if((0, codegen_1._)`${coerced} !== undefined`);
        for (const t of coerceTo) {
          if (COERCIBLE.has(t) || t === "array" && opts.coerceTypes === "array") {
            coerceSpecificType(t);
          }
        }
        gen.else();
        reportTypeError(it);
        gen.endIf();
        gen.if((0, codegen_1._)`${coerced} !== undefined`, () => {
          gen.assign(data, coerced);
          assignParentData(it, coerced);
        });
        function coerceSpecificType(t) {
          switch (t) {
            case "string":
              gen.elseIf((0, codegen_1._)`${dataType} == "number" || ${dataType} == "boolean"`).assign(coerced, (0, codegen_1._)`"" + ${data}`).elseIf((0, codegen_1._)`${data} === null`).assign(coerced, (0, codegen_1._)`""`);
              return;
            case "number":
              gen.elseIf((0, codegen_1._)`${dataType} == "boolean" || ${data} === null
              || (${dataType} == "string" && ${data} && ${data} == +${data})`).assign(coerced, (0, codegen_1._)`+${data}`);
              return;
            case "integer":
              gen.elseIf((0, codegen_1._)`${dataType} === "boolean" || ${data} === null
              || (${dataType} === "string" && ${data} && ${data} == +${data} && !(${data} % 1))`).assign(coerced, (0, codegen_1._)`+${data}`);
              return;
            case "boolean":
              gen.elseIf((0, codegen_1._)`${data} === "false" || ${data} === 0 || ${data} === null`).assign(coerced, false).elseIf((0, codegen_1._)`${data} === "true" || ${data} === 1`).assign(coerced, true);
              return;
            case "null":
              gen.elseIf((0, codegen_1._)`${data} === "" || ${data} === 0 || ${data} === false`);
              gen.assign(coerced, null);
              return;
            case "array":
              gen.elseIf((0, codegen_1._)`${dataType} === "string" || ${dataType} === "number"
              || ${dataType} === "boolean" || ${data} === null`).assign(coerced, (0, codegen_1._)`[${data}]`);
          }
        }
      }
      function assignParentData({ gen, parentData, parentDataProperty }, expr) {
        gen.if((0, codegen_1._)`${parentData} !== undefined`, () => gen.assign((0, codegen_1._)`${parentData}[${parentDataProperty}]`, expr));
      }
      function checkDataType(dataType, data, strictNums, correct = DataType.Correct) {
        const EQ = correct === DataType.Correct ? codegen_1.operators.EQ : codegen_1.operators.NEQ;
        let cond;
        switch (dataType) {
          case "null":
            return (0, codegen_1._)`${data} ${EQ} null`;
          case "array":
            cond = (0, codegen_1._)`Array.isArray(${data})`;
            break;
          case "object":
            cond = (0, codegen_1._)`${data} && typeof ${data} == "object" && !Array.isArray(${data})`;
            break;
          case "integer":
            cond = numCond((0, codegen_1._)`!(${data} % 1) && !isNaN(${data})`);
            break;
          case "number":
            cond = numCond();
            break;
          default:
            return (0, codegen_1._)`typeof ${data} ${EQ} ${dataType}`;
        }
        return correct === DataType.Correct ? cond : (0, codegen_1.not)(cond);
        function numCond(_cond = codegen_1.nil) {
          return (0, codegen_1.and)((0, codegen_1._)`typeof ${data} == "number"`, _cond, strictNums ? (0, codegen_1._)`isFinite(${data})` : codegen_1.nil);
        }
      }
      exports.checkDataType = checkDataType;
      function checkDataTypes(dataTypes, data, strictNums, correct) {
        if (dataTypes.length === 1) {
          return checkDataType(dataTypes[0], data, strictNums, correct);
        }
        let cond;
        const types = (0, util_1.toHash)(dataTypes);
        if (types.array && types.object) {
          const notObj = (0, codegen_1._)`typeof ${data} != "object"`;
          cond = types.null ? notObj : (0, codegen_1._)`!${data} || ${notObj}`;
          delete types.null;
          delete types.array;
          delete types.object;
        } else {
          cond = codegen_1.nil;
        }
        if (types.number)
          delete types.integer;
        for (const t in types)
          cond = (0, codegen_1.and)(cond, checkDataType(t, data, strictNums, correct));
        return cond;
      }
      exports.checkDataTypes = checkDataTypes;
      var typeError = {
        message: ({ schema }) => `must be ${schema}`,
        params: ({ schema, schemaValue }) => typeof schema == "string" ? (0, codegen_1._)`{type: ${schema}}` : (0, codegen_1._)`{type: ${schemaValue}}`
      };
      function reportTypeError(it) {
        const cxt = getTypeErrorContext(it);
        (0, errors_1.reportError)(cxt, typeError);
      }
      exports.reportTypeError = reportTypeError;
      function getTypeErrorContext(it) {
        const { gen, data, schema } = it;
        const schemaCode = (0, util_1.schemaRefOrVal)(it, schema, "type");
        return {
          gen,
          keyword: "type",
          data,
          schema: schema.type,
          schemaCode,
          schemaValue: schemaCode,
          parentSchema: schema,
          params: {},
          it
        };
      }
    }
  });

  // node_modules/ajv/dist/compile/validate/defaults.js
  var require_defaults = __commonJS({
    "node_modules/ajv/dist/compile/validate/defaults.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.assignDefaults = void 0;
      var codegen_1 = require_codegen();
      var util_1 = require_util();
      function assignDefaults(it, ty) {
        const { properties, items } = it.schema;
        if (ty === "object" && properties) {
          for (const key2 in properties) {
            assignDefault(it, key2, properties[key2].default);
          }
        } else if (ty === "array" && Array.isArray(items)) {
          items.forEach((sch, i) => assignDefault(it, i, sch.default));
        }
      }
      exports.assignDefaults = assignDefaults;
      function assignDefault(it, prop, defaultValue) {
        const { gen, compositeRule, data, opts } = it;
        if (defaultValue === void 0)
          return;
        const childData = (0, codegen_1._)`${data}${(0, codegen_1.getProperty)(prop)}`;
        if (compositeRule) {
          (0, util_1.checkStrictMode)(it, `default is ignored for: ${childData}`);
          return;
        }
        let condition = (0, codegen_1._)`${childData} === undefined`;
        if (opts.useDefaults === "empty") {
          condition = (0, codegen_1._)`${condition} || ${childData} === null || ${childData} === ""`;
        }
        gen.if(condition, (0, codegen_1._)`${childData} = ${(0, codegen_1.stringify)(defaultValue)}`);
      }
    }
  });

  // node_modules/ajv/dist/vocabularies/code.js
  var require_code2 = __commonJS({
    "node_modules/ajv/dist/vocabularies/code.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.validateUnion = exports.validateArray = exports.usePattern = exports.callValidateCode = exports.schemaProperties = exports.allSchemaProperties = exports.noPropertyInData = exports.propertyInData = exports.isOwnProperty = exports.hasPropFunc = exports.reportMissingProp = exports.checkMissingProp = exports.checkReportMissingProp = void 0;
      var codegen_1 = require_codegen();
      var util_1 = require_util();
      var names_1 = require_names();
      var util_2 = require_util();
      function checkReportMissingProp(cxt, prop) {
        const { gen, data, it } = cxt;
        gen.if(noPropertyInData(gen, data, prop, it.opts.ownProperties), () => {
          cxt.setParams({ missingProperty: (0, codegen_1._)`${prop}` }, true);
          cxt.error();
        });
      }
      exports.checkReportMissingProp = checkReportMissingProp;
      function checkMissingProp({ gen, data, it: { opts } }, properties, missing) {
        return (0, codegen_1.or)(...properties.map((prop) => (0, codegen_1.and)(noPropertyInData(gen, data, prop, opts.ownProperties), (0, codegen_1._)`${missing} = ${prop}`)));
      }
      exports.checkMissingProp = checkMissingProp;
      function reportMissingProp(cxt, missing) {
        cxt.setParams({ missingProperty: missing }, true);
        cxt.error();
      }
      exports.reportMissingProp = reportMissingProp;
      function hasPropFunc(gen) {
        return gen.scopeValue("func", {
          // eslint-disable-next-line @typescript-eslint/unbound-method
          ref: Object.prototype.hasOwnProperty,
          code: (0, codegen_1._)`Object.prototype.hasOwnProperty`
        });
      }
      exports.hasPropFunc = hasPropFunc;
      function isOwnProperty(gen, data, property) {
        return (0, codegen_1._)`${hasPropFunc(gen)}.call(${data}, ${property})`;
      }
      exports.isOwnProperty = isOwnProperty;
      function propertyInData(gen, data, property, ownProperties) {
        const cond = (0, codegen_1._)`${data}${(0, codegen_1.getProperty)(property)} !== undefined`;
        return ownProperties ? (0, codegen_1._)`${cond} && ${isOwnProperty(gen, data, property)}` : cond;
      }
      exports.propertyInData = propertyInData;
      function noPropertyInData(gen, data, property, ownProperties) {
        const cond = (0, codegen_1._)`${data}${(0, codegen_1.getProperty)(property)} === undefined`;
        return ownProperties ? (0, codegen_1.or)(cond, (0, codegen_1.not)(isOwnProperty(gen, data, property))) : cond;
      }
      exports.noPropertyInData = noPropertyInData;
      function allSchemaProperties(schemaMap) {
        return schemaMap ? Object.keys(schemaMap).filter((p) => p !== "__proto__") : [];
      }
      exports.allSchemaProperties = allSchemaProperties;
      function schemaProperties(it, schemaMap) {
        return allSchemaProperties(schemaMap).filter((p) => !(0, util_1.alwaysValidSchema)(it, schemaMap[p]));
      }
      exports.schemaProperties = schemaProperties;
      function callValidateCode({ schemaCode, data, it: { gen, topSchemaRef, schemaPath, errorPath }, it }, func, context, passSchema) {
        const dataAndSchema = passSchema ? (0, codegen_1._)`${schemaCode}, ${data}, ${topSchemaRef}${schemaPath}` : data;
        const valCxt = [
          [names_1.default.instancePath, (0, codegen_1.strConcat)(names_1.default.instancePath, errorPath)],
          [names_1.default.parentData, it.parentData],
          [names_1.default.parentDataProperty, it.parentDataProperty],
          [names_1.default.rootData, names_1.default.rootData]
        ];
        if (it.opts.dynamicRef)
          valCxt.push([names_1.default.dynamicAnchors, names_1.default.dynamicAnchors]);
        const args = (0, codegen_1._)`${dataAndSchema}, ${gen.object(...valCxt)}`;
        return context !== codegen_1.nil ? (0, codegen_1._)`${func}.call(${context}, ${args})` : (0, codegen_1._)`${func}(${args})`;
      }
      exports.callValidateCode = callValidateCode;
      var newRegExp = (0, codegen_1._)`new RegExp`;
      function usePattern({ gen, it: { opts } }, pattern) {
        const u = opts.unicodeRegExp ? "u" : "";
        const { regExp } = opts.code;
        const rx = regExp(pattern, u);
        return gen.scopeValue("pattern", {
          key: rx.toString(),
          ref: rx,
          code: (0, codegen_1._)`${regExp.code === "new RegExp" ? newRegExp : (0, util_2.useFunc)(gen, regExp)}(${pattern}, ${u})`
        });
      }
      exports.usePattern = usePattern;
      function validateArray(cxt) {
        const { gen, data, keyword, it } = cxt;
        const valid = gen.name("valid");
        if (it.allErrors) {
          const validArr = gen.let("valid", true);
          validateItems(() => gen.assign(validArr, false));
          return validArr;
        }
        gen.var(valid, true);
        validateItems(() => gen.break());
        return valid;
        function validateItems(notValid) {
          const len = gen.const("len", (0, codegen_1._)`${data}.length`);
          gen.forRange("i", 0, len, (i) => {
            cxt.subschema({
              keyword,
              dataProp: i,
              dataPropType: util_1.Type.Num
            }, valid);
            gen.if((0, codegen_1.not)(valid), notValid);
          });
        }
      }
      exports.validateArray = validateArray;
      function validateUnion(cxt) {
        const { gen, schema, keyword, it } = cxt;
        if (!Array.isArray(schema))
          throw new Error("ajv implementation error");
        const alwaysValid = schema.some((sch) => (0, util_1.alwaysValidSchema)(it, sch));
        if (alwaysValid && !it.opts.unevaluated)
          return;
        const valid = gen.let("valid", false);
        const schValid = gen.name("_valid");
        gen.block(() => schema.forEach((_sch, i) => {
          const schCxt = cxt.subschema({
            keyword,
            schemaProp: i,
            compositeRule: true
          }, schValid);
          gen.assign(valid, (0, codegen_1._)`${valid} || ${schValid}`);
          const merged = cxt.mergeValidEvaluated(schCxt, schValid);
          if (!merged)
            gen.if((0, codegen_1.not)(valid));
        }));
        cxt.result(valid, () => cxt.reset(), () => cxt.error(true));
      }
      exports.validateUnion = validateUnion;
    }
  });

  // node_modules/ajv/dist/compile/validate/keyword.js
  var require_keyword = __commonJS({
    "node_modules/ajv/dist/compile/validate/keyword.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.validateKeywordUsage = exports.validSchemaType = exports.funcKeywordCode = exports.macroKeywordCode = void 0;
      var codegen_1 = require_codegen();
      var names_1 = require_names();
      var code_1 = require_code2();
      var errors_1 = require_errors();
      function macroKeywordCode(cxt, def) {
        const { gen, keyword, schema, parentSchema, it } = cxt;
        const macroSchema = def.macro.call(it.self, schema, parentSchema, it);
        const schemaRef = useKeyword(gen, keyword, macroSchema);
        if (it.opts.validateSchema !== false)
          it.self.validateSchema(macroSchema, true);
        const valid = gen.name("valid");
        cxt.subschema({
          schema: macroSchema,
          schemaPath: codegen_1.nil,
          errSchemaPath: `${it.errSchemaPath}/${keyword}`,
          topSchemaRef: schemaRef,
          compositeRule: true
        }, valid);
        cxt.pass(valid, () => cxt.error(true));
      }
      exports.macroKeywordCode = macroKeywordCode;
      function funcKeywordCode(cxt, def) {
        var _a;
        const { gen, keyword, schema, parentSchema, $data, it } = cxt;
        checkAsyncKeyword(it, def);
        const validate = !$data && def.compile ? def.compile.call(it.self, schema, parentSchema, it) : def.validate;
        const validateRef = useKeyword(gen, keyword, validate);
        const valid = gen.let("valid");
        cxt.block$data(valid, validateKeyword);
        cxt.ok((_a = def.valid) !== null && _a !== void 0 ? _a : valid);
        function validateKeyword() {
          if (def.errors === false) {
            assignValid();
            if (def.modifying)
              modifyData(cxt);
            reportErrs(() => cxt.error());
          } else {
            const ruleErrs = def.async ? validateAsync() : validateSync();
            if (def.modifying)
              modifyData(cxt);
            reportErrs(() => addErrs(cxt, ruleErrs));
          }
        }
        function validateAsync() {
          const ruleErrs = gen.let("ruleErrs", null);
          gen.try(() => assignValid((0, codegen_1._)`await `), (e) => gen.assign(valid, false).if((0, codegen_1._)`${e} instanceof ${it.ValidationError}`, () => gen.assign(ruleErrs, (0, codegen_1._)`${e}.errors`), () => gen.throw(e)));
          return ruleErrs;
        }
        function validateSync() {
          const validateErrs = (0, codegen_1._)`${validateRef}.errors`;
          gen.assign(validateErrs, null);
          assignValid(codegen_1.nil);
          return validateErrs;
        }
        function assignValid(_await = def.async ? (0, codegen_1._)`await ` : codegen_1.nil) {
          const passCxt = it.opts.passContext ? names_1.default.this : names_1.default.self;
          const passSchema = !("compile" in def && !$data || def.schema === false);
          gen.assign(valid, (0, codegen_1._)`${_await}${(0, code_1.callValidateCode)(cxt, validateRef, passCxt, passSchema)}`, def.modifying);
        }
        function reportErrs(errors) {
          var _a2;
          gen.if((0, codegen_1.not)((_a2 = def.valid) !== null && _a2 !== void 0 ? _a2 : valid), errors);
        }
      }
      exports.funcKeywordCode = funcKeywordCode;
      function modifyData(cxt) {
        const { gen, data, it } = cxt;
        gen.if(it.parentData, () => gen.assign(data, (0, codegen_1._)`${it.parentData}[${it.parentDataProperty}]`));
      }
      function addErrs(cxt, errs) {
        const { gen } = cxt;
        gen.if((0, codegen_1._)`Array.isArray(${errs})`, () => {
          gen.assign(names_1.default.vErrors, (0, codegen_1._)`${names_1.default.vErrors} === null ? ${errs} : ${names_1.default.vErrors}.concat(${errs})`).assign(names_1.default.errors, (0, codegen_1._)`${names_1.default.vErrors}.length`);
          (0, errors_1.extendErrors)(cxt);
        }, () => cxt.error());
      }
      function checkAsyncKeyword({ schemaEnv }, def) {
        if (def.async && !schemaEnv.$async)
          throw new Error("async keyword in sync schema");
      }
      function useKeyword(gen, keyword, result) {
        if (result === void 0)
          throw new Error(`keyword "${keyword}" failed to compile`);
        return gen.scopeValue("keyword", typeof result == "function" ? { ref: result } : { ref: result, code: (0, codegen_1.stringify)(result) });
      }
      function validSchemaType(schema, schemaType, allowUndefined = false) {
        return !schemaType.length || schemaType.some((st) => st === "array" ? Array.isArray(schema) : st === "object" ? schema && typeof schema == "object" && !Array.isArray(schema) : typeof schema == st || allowUndefined && typeof schema == "undefined");
      }
      exports.validSchemaType = validSchemaType;
      function validateKeywordUsage({ schema, opts, self, errSchemaPath }, def, keyword) {
        if (Array.isArray(def.keyword) ? !def.keyword.includes(keyword) : def.keyword !== keyword) {
          throw new Error("ajv implementation error");
        }
        const deps = def.dependencies;
        if (deps === null || deps === void 0 ? void 0 : deps.some((kwd) => !Object.prototype.hasOwnProperty.call(schema, kwd))) {
          throw new Error(`parent schema must have dependencies of ${keyword}: ${deps.join(",")}`);
        }
        if (def.validateSchema) {
          const valid = def.validateSchema(schema[keyword]);
          if (!valid) {
            const msg = `keyword "${keyword}" value is invalid at path "${errSchemaPath}": ` + self.errorsText(def.validateSchema.errors);
            if (opts.validateSchema === "log")
              self.logger.error(msg);
            else
              throw new Error(msg);
          }
        }
      }
      exports.validateKeywordUsage = validateKeywordUsage;
    }
  });

  // node_modules/ajv/dist/compile/validate/subschema.js
  var require_subschema = __commonJS({
    "node_modules/ajv/dist/compile/validate/subschema.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.extendSubschemaMode = exports.extendSubschemaData = exports.getSubschema = void 0;
      var codegen_1 = require_codegen();
      var util_1 = require_util();
      function getSubschema(it, { keyword, schemaProp, schema, schemaPath, errSchemaPath, topSchemaRef }) {
        if (keyword !== void 0 && schema !== void 0) {
          throw new Error('both "keyword" and "schema" passed, only one allowed');
        }
        if (keyword !== void 0) {
          const sch = it.schema[keyword];
          return schemaProp === void 0 ? {
            schema: sch,
            schemaPath: (0, codegen_1._)`${it.schemaPath}${(0, codegen_1.getProperty)(keyword)}`,
            errSchemaPath: `${it.errSchemaPath}/${keyword}`
          } : {
            schema: sch[schemaProp],
            schemaPath: (0, codegen_1._)`${it.schemaPath}${(0, codegen_1.getProperty)(keyword)}${(0, codegen_1.getProperty)(schemaProp)}`,
            errSchemaPath: `${it.errSchemaPath}/${keyword}/${(0, util_1.escapeFragment)(schemaProp)}`
          };
        }
        if (schema !== void 0) {
          if (schemaPath === void 0 || errSchemaPath === void 0 || topSchemaRef === void 0) {
            throw new Error('"schemaPath", "errSchemaPath" and "topSchemaRef" are required with "schema"');
          }
          return {
            schema,
            schemaPath,
            topSchemaRef,
            errSchemaPath
          };
        }
        throw new Error('either "keyword" or "schema" must be passed');
      }
      exports.getSubschema = getSubschema;
      function extendSubschemaData(subschema, it, { dataProp, dataPropType: dpType, data, dataTypes, propertyName }) {
        if (data !== void 0 && dataProp !== void 0) {
          throw new Error('both "data" and "dataProp" passed, only one allowed');
        }
        const { gen } = it;
        if (dataProp !== void 0) {
          const { errorPath, dataPathArr, opts } = it;
          const nextData = gen.let("data", (0, codegen_1._)`${it.data}${(0, codegen_1.getProperty)(dataProp)}`, true);
          dataContextProps(nextData);
          subschema.errorPath = (0, codegen_1.str)`${errorPath}${(0, util_1.getErrorPath)(dataProp, dpType, opts.jsPropertySyntax)}`;
          subschema.parentDataProperty = (0, codegen_1._)`${dataProp}`;
          subschema.dataPathArr = [...dataPathArr, subschema.parentDataProperty];
        }
        if (data !== void 0) {
          const nextData = data instanceof codegen_1.Name ? data : gen.let("data", data, true);
          dataContextProps(nextData);
          if (propertyName !== void 0)
            subschema.propertyName = propertyName;
        }
        if (dataTypes)
          subschema.dataTypes = dataTypes;
        function dataContextProps(_nextData) {
          subschema.data = _nextData;
          subschema.dataLevel = it.dataLevel + 1;
          subschema.dataTypes = [];
          it.definedProperties = /* @__PURE__ */ new Set();
          subschema.parentData = it.data;
          subschema.dataNames = [...it.dataNames, _nextData];
        }
      }
      exports.extendSubschemaData = extendSubschemaData;
      function extendSubschemaMode(subschema, { jtdDiscriminator, jtdMetadata, compositeRule, createErrors, allErrors }) {
        if (compositeRule !== void 0)
          subschema.compositeRule = compositeRule;
        if (createErrors !== void 0)
          subschema.createErrors = createErrors;
        if (allErrors !== void 0)
          subschema.allErrors = allErrors;
        subschema.jtdDiscriminator = jtdDiscriminator;
        subschema.jtdMetadata = jtdMetadata;
      }
      exports.extendSubschemaMode = extendSubschemaMode;
    }
  });

  // node_modules/fast-deep-equal/index.js
  var require_fast_deep_equal = __commonJS({
    "node_modules/fast-deep-equal/index.js"(exports, module) {
      "use strict";
      module.exports = function equal(a, b) {
        if (a === b) return true;
        if (a && b && typeof a == "object" && typeof b == "object") {
          if (a.constructor !== b.constructor) return false;
          var length, i, keys;
          if (Array.isArray(a)) {
            length = a.length;
            if (length != b.length) return false;
            for (i = length; i-- !== 0; )
              if (!equal(a[i], b[i])) return false;
            return true;
          }
          if (a.constructor === RegExp) return a.source === b.source && a.flags === b.flags;
          if (a.valueOf !== Object.prototype.valueOf) return a.valueOf() === b.valueOf();
          if (a.toString !== Object.prototype.toString) return a.toString() === b.toString();
          keys = Object.keys(a);
          length = keys.length;
          if (length !== Object.keys(b).length) return false;
          for (i = length; i-- !== 0; )
            if (!Object.prototype.hasOwnProperty.call(b, keys[i])) return false;
          for (i = length; i-- !== 0; ) {
            var key2 = keys[i];
            if (!equal(a[key2], b[key2])) return false;
          }
          return true;
        }
        return a !== a && b !== b;
      };
    }
  });

  // node_modules/json-schema-traverse/index.js
  var require_json_schema_traverse = __commonJS({
    "node_modules/json-schema-traverse/index.js"(exports, module) {
      "use strict";
      var traverse = module.exports = function(schema, opts, cb) {
        if (typeof opts == "function") {
          cb = opts;
          opts = {};
        }
        cb = opts.cb || cb;
        var pre = typeof cb == "function" ? cb : cb.pre || function() {
        };
        var post = cb.post || function() {
        };
        _traverse(opts, pre, post, schema, "", schema);
      };
      traverse.keywords = {
        additionalItems: true,
        items: true,
        contains: true,
        additionalProperties: true,
        propertyNames: true,
        not: true,
        if: true,
        then: true,
        else: true
      };
      traverse.arrayKeywords = {
        items: true,
        allOf: true,
        anyOf: true,
        oneOf: true
      };
      traverse.propsKeywords = {
        $defs: true,
        definitions: true,
        properties: true,
        patternProperties: true,
        dependencies: true
      };
      traverse.skipKeywords = {
        default: true,
        enum: true,
        const: true,
        required: true,
        maximum: true,
        minimum: true,
        exclusiveMaximum: true,
        exclusiveMinimum: true,
        multipleOf: true,
        maxLength: true,
        minLength: true,
        pattern: true,
        format: true,
        maxItems: true,
        minItems: true,
        uniqueItems: true,
        maxProperties: true,
        minProperties: true
      };
      function _traverse(opts, pre, post, schema, jsonPtr, rootSchema, parentJsonPtr, parentKeyword, parentSchema, keyIndex) {
        if (schema && typeof schema == "object" && !Array.isArray(schema)) {
          pre(schema, jsonPtr, rootSchema, parentJsonPtr, parentKeyword, parentSchema, keyIndex);
          for (var key2 in schema) {
            var sch = schema[key2];
            if (Array.isArray(sch)) {
              if (key2 in traverse.arrayKeywords) {
                for (var i = 0; i < sch.length; i++)
                  _traverse(opts, pre, post, sch[i], jsonPtr + "/" + key2 + "/" + i, rootSchema, jsonPtr, key2, schema, i);
              }
            } else if (key2 in traverse.propsKeywords) {
              if (sch && typeof sch == "object") {
                for (var prop in sch)
                  _traverse(opts, pre, post, sch[prop], jsonPtr + "/" + key2 + "/" + escapeJsonPtr(prop), rootSchema, jsonPtr, key2, schema, prop);
              }
            } else if (key2 in traverse.keywords || opts.allKeys && !(key2 in traverse.skipKeywords)) {
              _traverse(opts, pre, post, sch, jsonPtr + "/" + key2, rootSchema, jsonPtr, key2, schema);
            }
          }
          post(schema, jsonPtr, rootSchema, parentJsonPtr, parentKeyword, parentSchema, keyIndex);
        }
      }
      function escapeJsonPtr(str) {
        return str.replace(/~/g, "~0").replace(/\//g, "~1");
      }
    }
  });

  // node_modules/ajv/dist/compile/resolve.js
  var require_resolve = __commonJS({
    "node_modules/ajv/dist/compile/resolve.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.getSchemaRefs = exports.resolveUrl = exports.normalizeId = exports._getFullPath = exports.getFullPath = exports.inlineRef = void 0;
      var util_1 = require_util();
      var equal = require_fast_deep_equal();
      var traverse = require_json_schema_traverse();
      var SIMPLE_INLINED = /* @__PURE__ */ new Set([
        "type",
        "format",
        "pattern",
        "maxLength",
        "minLength",
        "maxProperties",
        "minProperties",
        "maxItems",
        "minItems",
        "maximum",
        "minimum",
        "uniqueItems",
        "multipleOf",
        "required",
        "enum",
        "const"
      ]);
      function inlineRef(schema, limit = true) {
        if (typeof schema == "boolean")
          return true;
        if (limit === true)
          return !hasRef(schema);
        if (!limit)
          return false;
        return countKeys(schema) <= limit;
      }
      exports.inlineRef = inlineRef;
      var REF_KEYWORDS = /* @__PURE__ */ new Set([
        "$ref",
        "$recursiveRef",
        "$recursiveAnchor",
        "$dynamicRef",
        "$dynamicAnchor"
      ]);
      function hasRef(schema) {
        for (const key2 in schema) {
          if (REF_KEYWORDS.has(key2))
            return true;
          const sch = schema[key2];
          if (Array.isArray(sch) && sch.some(hasRef))
            return true;
          if (typeof sch == "object" && hasRef(sch))
            return true;
        }
        return false;
      }
      function countKeys(schema) {
        let count = 0;
        for (const key2 in schema) {
          if (key2 === "$ref")
            return Infinity;
          count++;
          if (SIMPLE_INLINED.has(key2))
            continue;
          if (typeof schema[key2] == "object") {
            (0, util_1.eachItem)(schema[key2], (sch) => count += countKeys(sch));
          }
          if (count === Infinity)
            return Infinity;
        }
        return count;
      }
      function getFullPath(resolver, id = "", normalize) {
        if (normalize !== false)
          id = normalizeId(id);
        const p = resolver.parse(id);
        return _getFullPath(resolver, p);
      }
      exports.getFullPath = getFullPath;
      function _getFullPath(resolver, p) {
        const serialized = resolver.serialize(p);
        return serialized.split("#")[0] + "#";
      }
      exports._getFullPath = _getFullPath;
      var TRAILING_SLASH_HASH = /#\/?$/;
      function normalizeId(id) {
        return id ? id.replace(TRAILING_SLASH_HASH, "") : "";
      }
      exports.normalizeId = normalizeId;
      function resolveUrl(resolver, baseId, id) {
        id = normalizeId(id);
        return resolver.resolve(baseId, id);
      }
      exports.resolveUrl = resolveUrl;
      var ANCHOR = /^[a-z_][-a-z0-9._]*$/i;
      function getSchemaRefs(schema, baseId) {
        if (typeof schema == "boolean")
          return {};
        const { schemaId, uriResolver } = this.opts;
        const schId = normalizeId(schema[schemaId] || baseId);
        const baseIds = { "": schId };
        const pathPrefix = getFullPath(uriResolver, schId, false);
        const localRefs = {};
        const schemaRefs = /* @__PURE__ */ new Set();
        traverse(schema, { allKeys: true }, (sch, jsonPtr, _, parentJsonPtr) => {
          if (parentJsonPtr === void 0)
            return;
          const fullPath = pathPrefix + jsonPtr;
          let innerBaseId = baseIds[parentJsonPtr];
          if (typeof sch[schemaId] == "string")
            innerBaseId = addRef.call(this, sch[schemaId]);
          addAnchor.call(this, sch.$anchor);
          addAnchor.call(this, sch.$dynamicAnchor);
          baseIds[jsonPtr] = innerBaseId;
          function addRef(ref) {
            const _resolve = this.opts.uriResolver.resolve;
            ref = normalizeId(innerBaseId ? _resolve(innerBaseId, ref) : ref);
            if (schemaRefs.has(ref))
              throw ambiguos(ref);
            schemaRefs.add(ref);
            let schOrRef = this.refs[ref];
            if (typeof schOrRef == "string")
              schOrRef = this.refs[schOrRef];
            if (typeof schOrRef == "object") {
              checkAmbiguosRef(sch, schOrRef.schema, ref);
            } else if (ref !== normalizeId(fullPath)) {
              if (ref[0] === "#") {
                checkAmbiguosRef(sch, localRefs[ref], ref);
                localRefs[ref] = sch;
              } else {
                this.refs[ref] = fullPath;
              }
            }
            return ref;
          }
          function addAnchor(anchor) {
            if (typeof anchor == "string") {
              if (!ANCHOR.test(anchor))
                throw new Error(`invalid anchor "${anchor}"`);
              addRef.call(this, `#${anchor}`);
            }
          }
        });
        return localRefs;
        function checkAmbiguosRef(sch1, sch2, ref) {
          if (sch2 !== void 0 && !equal(sch1, sch2))
            throw ambiguos(ref);
        }
        function ambiguos(ref) {
          return new Error(`reference "${ref}" resolves to more than one schema`);
        }
      }
      exports.getSchemaRefs = getSchemaRefs;
    }
  });

  // node_modules/ajv/dist/compile/validate/index.js
  var require_validate = __commonJS({
    "node_modules/ajv/dist/compile/validate/index.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.getData = exports.KeywordCxt = exports.validateFunctionCode = void 0;
      var boolSchema_1 = require_boolSchema();
      var dataType_1 = require_dataType();
      var applicability_1 = require_applicability();
      var dataType_2 = require_dataType();
      var defaults_1 = require_defaults();
      var keyword_1 = require_keyword();
      var subschema_1 = require_subschema();
      var codegen_1 = require_codegen();
      var names_1 = require_names();
      var resolve_1 = require_resolve();
      var util_1 = require_util();
      var errors_1 = require_errors();
      function validateFunctionCode(it) {
        if (isSchemaObj(it)) {
          checkKeywords(it);
          if (schemaCxtHasRules(it)) {
            topSchemaObjCode(it);
            return;
          }
        }
        validateFunction(it, () => (0, boolSchema_1.topBoolOrEmptySchema)(it));
      }
      exports.validateFunctionCode = validateFunctionCode;
      function validateFunction({ gen, validateName, schema, schemaEnv, opts }, body) {
        if (opts.code.es5) {
          gen.func(validateName, (0, codegen_1._)`${names_1.default.data}, ${names_1.default.valCxt}`, schemaEnv.$async, () => {
            gen.code((0, codegen_1._)`"use strict"; ${funcSourceUrl(schema, opts)}`);
            destructureValCxtES5(gen, opts);
            gen.code(body);
          });
        } else {
          gen.func(validateName, (0, codegen_1._)`${names_1.default.data}, ${destructureValCxt(opts)}`, schemaEnv.$async, () => gen.code(funcSourceUrl(schema, opts)).code(body));
        }
      }
      function destructureValCxt(opts) {
        return (0, codegen_1._)`{${names_1.default.instancePath}="", ${names_1.default.parentData}, ${names_1.default.parentDataProperty}, ${names_1.default.rootData}=${names_1.default.data}${opts.dynamicRef ? (0, codegen_1._)`, ${names_1.default.dynamicAnchors}={}` : codegen_1.nil}}={}`;
      }
      function destructureValCxtES5(gen, opts) {
        gen.if(names_1.default.valCxt, () => {
          gen.var(names_1.default.instancePath, (0, codegen_1._)`${names_1.default.valCxt}.${names_1.default.instancePath}`);
          gen.var(names_1.default.parentData, (0, codegen_1._)`${names_1.default.valCxt}.${names_1.default.parentData}`);
          gen.var(names_1.default.parentDataProperty, (0, codegen_1._)`${names_1.default.valCxt}.${names_1.default.parentDataProperty}`);
          gen.var(names_1.default.rootData, (0, codegen_1._)`${names_1.default.valCxt}.${names_1.default.rootData}`);
          if (opts.dynamicRef)
            gen.var(names_1.default.dynamicAnchors, (0, codegen_1._)`${names_1.default.valCxt}.${names_1.default.dynamicAnchors}`);
        }, () => {
          gen.var(names_1.default.instancePath, (0, codegen_1._)`""`);
          gen.var(names_1.default.parentData, (0, codegen_1._)`undefined`);
          gen.var(names_1.default.parentDataProperty, (0, codegen_1._)`undefined`);
          gen.var(names_1.default.rootData, names_1.default.data);
          if (opts.dynamicRef)
            gen.var(names_1.default.dynamicAnchors, (0, codegen_1._)`{}`);
        });
      }
      function topSchemaObjCode(it) {
        const { schema, opts, gen } = it;
        validateFunction(it, () => {
          if (opts.$comment && schema.$comment)
            commentKeyword(it);
          checkNoDefault(it);
          gen.let(names_1.default.vErrors, null);
          gen.let(names_1.default.errors, 0);
          if (opts.unevaluated)
            resetEvaluated(it);
          typeAndKeywords(it);
          returnResults(it);
        });
        return;
      }
      function resetEvaluated(it) {
        const { gen, validateName } = it;
        it.evaluated = gen.const("evaluated", (0, codegen_1._)`${validateName}.evaluated`);
        gen.if((0, codegen_1._)`${it.evaluated}.dynamicProps`, () => gen.assign((0, codegen_1._)`${it.evaluated}.props`, (0, codegen_1._)`undefined`));
        gen.if((0, codegen_1._)`${it.evaluated}.dynamicItems`, () => gen.assign((0, codegen_1._)`${it.evaluated}.items`, (0, codegen_1._)`undefined`));
      }
      function funcSourceUrl(schema, opts) {
        const schId = typeof schema == "object" && schema[opts.schemaId];
        return schId && (opts.code.source || opts.code.process) ? (0, codegen_1._)`/*# sourceURL=${schId} */` : codegen_1.nil;
      }
      function subschemaCode(it, valid) {
        if (isSchemaObj(it)) {
          checkKeywords(it);
          if (schemaCxtHasRules(it)) {
            subSchemaObjCode(it, valid);
            return;
          }
        }
        (0, boolSchema_1.boolOrEmptySchema)(it, valid);
      }
      function schemaCxtHasRules({ schema, self }) {
        if (typeof schema == "boolean")
          return !schema;
        for (const key2 in schema)
          if (self.RULES.all[key2])
            return true;
        return false;
      }
      function isSchemaObj(it) {
        return typeof it.schema != "boolean";
      }
      function subSchemaObjCode(it, valid) {
        const { schema, gen, opts } = it;
        if (opts.$comment && schema.$comment)
          commentKeyword(it);
        updateContext(it);
        checkAsyncSchema(it);
        const errsCount = gen.const("_errs", names_1.default.errors);
        typeAndKeywords(it, errsCount);
        gen.var(valid, (0, codegen_1._)`${errsCount} === ${names_1.default.errors}`);
      }
      function checkKeywords(it) {
        (0, util_1.checkUnknownRules)(it);
        checkRefsAndKeywords(it);
      }
      function typeAndKeywords(it, errsCount) {
        if (it.opts.jtd)
          return schemaKeywords(it, [], false, errsCount);
        const types = (0, dataType_1.getSchemaTypes)(it.schema);
        const checkedTypes = (0, dataType_1.coerceAndCheckDataType)(it, types);
        schemaKeywords(it, types, !checkedTypes, errsCount);
      }
      function checkRefsAndKeywords(it) {
        const { schema, errSchemaPath, opts, self } = it;
        if (schema.$ref && opts.ignoreKeywordsWithRef && (0, util_1.schemaHasRulesButRef)(schema, self.RULES)) {
          self.logger.warn(`$ref: keywords ignored in schema at path "${errSchemaPath}"`);
        }
      }
      function checkNoDefault(it) {
        const { schema, opts } = it;
        if (schema.default !== void 0 && opts.useDefaults && opts.strictSchema) {
          (0, util_1.checkStrictMode)(it, "default is ignored in the schema root");
        }
      }
      function updateContext(it) {
        const schId = it.schema[it.opts.schemaId];
        if (schId)
          it.baseId = (0, resolve_1.resolveUrl)(it.opts.uriResolver, it.baseId, schId);
      }
      function checkAsyncSchema(it) {
        if (it.schema.$async && !it.schemaEnv.$async)
          throw new Error("async schema in sync schema");
      }
      function commentKeyword({ gen, schemaEnv, schema, errSchemaPath, opts }) {
        const msg = schema.$comment;
        if (opts.$comment === true) {
          gen.code((0, codegen_1._)`${names_1.default.self}.logger.log(${msg})`);
        } else if (typeof opts.$comment == "function") {
          const schemaPath = (0, codegen_1.str)`${errSchemaPath}/$comment`;
          const rootName = gen.scopeValue("root", { ref: schemaEnv.root });
          gen.code((0, codegen_1._)`${names_1.default.self}.opts.$comment(${msg}, ${schemaPath}, ${rootName}.schema)`);
        }
      }
      function returnResults(it) {
        const { gen, schemaEnv, validateName, ValidationError, opts } = it;
        if (schemaEnv.$async) {
          gen.if((0, codegen_1._)`${names_1.default.errors} === 0`, () => gen.return(names_1.default.data), () => gen.throw((0, codegen_1._)`new ${ValidationError}(${names_1.default.vErrors})`));
        } else {
          gen.assign((0, codegen_1._)`${validateName}.errors`, names_1.default.vErrors);
          if (opts.unevaluated)
            assignEvaluated(it);
          gen.return((0, codegen_1._)`${names_1.default.errors} === 0`);
        }
      }
      function assignEvaluated({ gen, evaluated, props, items }) {
        if (props instanceof codegen_1.Name)
          gen.assign((0, codegen_1._)`${evaluated}.props`, props);
        if (items instanceof codegen_1.Name)
          gen.assign((0, codegen_1._)`${evaluated}.items`, items);
      }
      function schemaKeywords(it, types, typeErrors, errsCount) {
        const { gen, schema, data, allErrors, opts, self } = it;
        const { RULES } = self;
        if (schema.$ref && (opts.ignoreKeywordsWithRef || !(0, util_1.schemaHasRulesButRef)(schema, RULES))) {
          gen.block(() => keywordCode(it, "$ref", RULES.all.$ref.definition));
          return;
        }
        if (!opts.jtd)
          checkStrictTypes(it, types);
        gen.block(() => {
          for (const group of RULES.rules)
            groupKeywords(group);
          groupKeywords(RULES.post);
        });
        function groupKeywords(group) {
          if (!(0, applicability_1.shouldUseGroup)(schema, group))
            return;
          if (group.type) {
            gen.if((0, dataType_2.checkDataType)(group.type, data, opts.strictNumbers));
            iterateKeywords(it, group);
            if (types.length === 1 && types[0] === group.type && typeErrors) {
              gen.else();
              (0, dataType_2.reportTypeError)(it);
            }
            gen.endIf();
          } else {
            iterateKeywords(it, group);
          }
          if (!allErrors)
            gen.if((0, codegen_1._)`${names_1.default.errors} === ${errsCount || 0}`);
        }
      }
      function iterateKeywords(it, group) {
        const { gen, schema, opts: { useDefaults } } = it;
        if (useDefaults)
          (0, defaults_1.assignDefaults)(it, group.type);
        gen.block(() => {
          for (const rule of group.rules) {
            if ((0, applicability_1.shouldUseRule)(schema, rule)) {
              keywordCode(it, rule.keyword, rule.definition, group.type);
            }
          }
        });
      }
      function checkStrictTypes(it, types) {
        if (it.schemaEnv.meta || !it.opts.strictTypes)
          return;
        checkContextTypes(it, types);
        if (!it.opts.allowUnionTypes)
          checkMultipleTypes(it, types);
        checkKeywordTypes(it, it.dataTypes);
      }
      function checkContextTypes(it, types) {
        if (!types.length)
          return;
        if (!it.dataTypes.length) {
          it.dataTypes = types;
          return;
        }
        types.forEach((t) => {
          if (!includesType(it.dataTypes, t)) {
            strictTypesError(it, `type "${t}" not allowed by context "${it.dataTypes.join(",")}"`);
          }
        });
        narrowSchemaTypes(it, types);
      }
      function checkMultipleTypes(it, ts) {
        if (ts.length > 1 && !(ts.length === 2 && ts.includes("null"))) {
          strictTypesError(it, "use allowUnionTypes to allow union type keyword");
        }
      }
      function checkKeywordTypes(it, ts) {
        const rules = it.self.RULES.all;
        for (const keyword in rules) {
          const rule = rules[keyword];
          if (typeof rule == "object" && (0, applicability_1.shouldUseRule)(it.schema, rule)) {
            const { type } = rule.definition;
            if (type.length && !type.some((t) => hasApplicableType(ts, t))) {
              strictTypesError(it, `missing type "${type.join(",")}" for keyword "${keyword}"`);
            }
          }
        }
      }
      function hasApplicableType(schTs, kwdT) {
        return schTs.includes(kwdT) || kwdT === "number" && schTs.includes("integer");
      }
      function includesType(ts, t) {
        return ts.includes(t) || t === "integer" && ts.includes("number");
      }
      function narrowSchemaTypes(it, withTypes) {
        const ts = [];
        for (const t of it.dataTypes) {
          if (includesType(withTypes, t))
            ts.push(t);
          else if (withTypes.includes("integer") && t === "number")
            ts.push("integer");
        }
        it.dataTypes = ts;
      }
      function strictTypesError(it, msg) {
        const schemaPath = it.schemaEnv.baseId + it.errSchemaPath;
        msg += ` at "${schemaPath}" (strictTypes)`;
        (0, util_1.checkStrictMode)(it, msg, it.opts.strictTypes);
      }
      var KeywordCxt = class {
        constructor(it, def, keyword) {
          (0, keyword_1.validateKeywordUsage)(it, def, keyword);
          this.gen = it.gen;
          this.allErrors = it.allErrors;
          this.keyword = keyword;
          this.data = it.data;
          this.schema = it.schema[keyword];
          this.$data = def.$data && it.opts.$data && this.schema && this.schema.$data;
          this.schemaValue = (0, util_1.schemaRefOrVal)(it, this.schema, keyword, this.$data);
          this.schemaType = def.schemaType;
          this.parentSchema = it.schema;
          this.params = {};
          this.it = it;
          this.def = def;
          if (this.$data) {
            this.schemaCode = it.gen.const("vSchema", getData(this.$data, it));
          } else {
            this.schemaCode = this.schemaValue;
            if (!(0, keyword_1.validSchemaType)(this.schema, def.schemaType, def.allowUndefined)) {
              throw new Error(`${keyword} value must be ${JSON.stringify(def.schemaType)}`);
            }
          }
          if ("code" in def ? def.trackErrors : def.errors !== false) {
            this.errsCount = it.gen.const("_errs", names_1.default.errors);
          }
        }
        result(condition, successAction, failAction) {
          this.failResult((0, codegen_1.not)(condition), successAction, failAction);
        }
        failResult(condition, successAction, failAction) {
          this.gen.if(condition);
          if (failAction)
            failAction();
          else
            this.error();
          if (successAction) {
            this.gen.else();
            successAction();
            if (this.allErrors)
              this.gen.endIf();
          } else {
            if (this.allErrors)
              this.gen.endIf();
            else
              this.gen.else();
          }
        }
        pass(condition, failAction) {
          this.failResult((0, codegen_1.not)(condition), void 0, failAction);
        }
        fail(condition) {
          if (condition === void 0) {
            this.error();
            if (!this.allErrors)
              this.gen.if(false);
            return;
          }
          this.gen.if(condition);
          this.error();
          if (this.allErrors)
            this.gen.endIf();
          else
            this.gen.else();
        }
        fail$data(condition) {
          if (!this.$data)
            return this.fail(condition);
          const { schemaCode } = this;
          this.fail((0, codegen_1._)`${schemaCode} !== undefined && (${(0, codegen_1.or)(this.invalid$data(), condition)})`);
        }
        error(append, errorParams, errorPaths) {
          if (errorParams) {
            this.setParams(errorParams);
            this._error(append, errorPaths);
            this.setParams({});
            return;
          }
          this._error(append, errorPaths);
        }
        _error(append, errorPaths) {
          ;
          (append ? errors_1.reportExtraError : errors_1.reportError)(this, this.def.error, errorPaths);
        }
        $dataError() {
          (0, errors_1.reportError)(this, this.def.$dataError || errors_1.keyword$DataError);
        }
        reset() {
          if (this.errsCount === void 0)
            throw new Error('add "trackErrors" to keyword definition');
          (0, errors_1.resetErrorsCount)(this.gen, this.errsCount);
        }
        ok(cond) {
          if (!this.allErrors)
            this.gen.if(cond);
        }
        setParams(obj, assign) {
          if (assign)
            Object.assign(this.params, obj);
          else
            this.params = obj;
        }
        block$data(valid, codeBlock, $dataValid = codegen_1.nil) {
          this.gen.block(() => {
            this.check$data(valid, $dataValid);
            codeBlock();
          });
        }
        check$data(valid = codegen_1.nil, $dataValid = codegen_1.nil) {
          if (!this.$data)
            return;
          const { gen, schemaCode, schemaType, def } = this;
          gen.if((0, codegen_1.or)((0, codegen_1._)`${schemaCode} === undefined`, $dataValid));
          if (valid !== codegen_1.nil)
            gen.assign(valid, true);
          if (schemaType.length || def.validateSchema) {
            gen.elseIf(this.invalid$data());
            this.$dataError();
            if (valid !== codegen_1.nil)
              gen.assign(valid, false);
          }
          gen.else();
        }
        invalid$data() {
          const { gen, schemaCode, schemaType, def, it } = this;
          return (0, codegen_1.or)(wrong$DataType(), invalid$DataSchema());
          function wrong$DataType() {
            if (schemaType.length) {
              if (!(schemaCode instanceof codegen_1.Name))
                throw new Error("ajv implementation error");
              const st = Array.isArray(schemaType) ? schemaType : [schemaType];
              return (0, codegen_1._)`${(0, dataType_2.checkDataTypes)(st, schemaCode, it.opts.strictNumbers, dataType_2.DataType.Wrong)}`;
            }
            return codegen_1.nil;
          }
          function invalid$DataSchema() {
            if (def.validateSchema) {
              const validateSchemaRef = gen.scopeValue("validate$data", { ref: def.validateSchema });
              return (0, codegen_1._)`!${validateSchemaRef}(${schemaCode})`;
            }
            return codegen_1.nil;
          }
        }
        subschema(appl, valid) {
          const subschema = (0, subschema_1.getSubschema)(this.it, appl);
          (0, subschema_1.extendSubschemaData)(subschema, this.it, appl);
          (0, subschema_1.extendSubschemaMode)(subschema, appl);
          const nextContext = { ...this.it, ...subschema, items: void 0, props: void 0 };
          subschemaCode(nextContext, valid);
          return nextContext;
        }
        mergeEvaluated(schemaCxt, toName) {
          const { it, gen } = this;
          if (!it.opts.unevaluated)
            return;
          if (it.props !== true && schemaCxt.props !== void 0) {
            it.props = util_1.mergeEvaluated.props(gen, schemaCxt.props, it.props, toName);
          }
          if (it.items !== true && schemaCxt.items !== void 0) {
            it.items = util_1.mergeEvaluated.items(gen, schemaCxt.items, it.items, toName);
          }
        }
        mergeValidEvaluated(schemaCxt, valid) {
          const { it, gen } = this;
          if (it.opts.unevaluated && (it.props !== true || it.items !== true)) {
            gen.if(valid, () => this.mergeEvaluated(schemaCxt, codegen_1.Name));
            return true;
          }
        }
      };
      exports.KeywordCxt = KeywordCxt;
      function keywordCode(it, keyword, def, ruleType) {
        const cxt = new KeywordCxt(it, def, keyword);
        if ("code" in def) {
          def.code(cxt, ruleType);
        } else if (cxt.$data && def.validate) {
          (0, keyword_1.funcKeywordCode)(cxt, def);
        } else if ("macro" in def) {
          (0, keyword_1.macroKeywordCode)(cxt, def);
        } else if (def.compile || def.validate) {
          (0, keyword_1.funcKeywordCode)(cxt, def);
        }
      }
      var JSON_POINTER = /^\/(?:[^~]|~0|~1)*$/;
      var RELATIVE_JSON_POINTER = /^([0-9]+)(#|\/(?:[^~]|~0|~1)*)?$/;
      function getData($data, { dataLevel, dataNames, dataPathArr }) {
        let jsonPointer;
        let data;
        if ($data === "")
          return names_1.default.rootData;
        if ($data[0] === "/") {
          if (!JSON_POINTER.test($data))
            throw new Error(`Invalid JSON-pointer: ${$data}`);
          jsonPointer = $data;
          data = names_1.default.rootData;
        } else {
          const matches = RELATIVE_JSON_POINTER.exec($data);
          if (!matches)
            throw new Error(`Invalid JSON-pointer: ${$data}`);
          const up = +matches[1];
          jsonPointer = matches[2];
          if (jsonPointer === "#") {
            if (up >= dataLevel)
              throw new Error(errorMsg("property/index", up));
            return dataPathArr[dataLevel - up];
          }
          if (up > dataLevel)
            throw new Error(errorMsg("data", up));
          data = dataNames[dataLevel - up];
          if (!jsonPointer)
            return data;
        }
        let expr = data;
        const segments = jsonPointer.split("/");
        for (const segment of segments) {
          if (segment) {
            data = (0, codegen_1._)`${data}${(0, codegen_1.getProperty)((0, util_1.unescapeJsonPointer)(segment))}`;
            expr = (0, codegen_1._)`${expr} && ${data}`;
          }
        }
        return expr;
        function errorMsg(pointerType, up) {
          return `Cannot access ${pointerType} ${up} levels up, current level is ${dataLevel}`;
        }
      }
      exports.getData = getData;
    }
  });

  // node_modules/ajv/dist/runtime/validation_error.js
  var require_validation_error = __commonJS({
    "node_modules/ajv/dist/runtime/validation_error.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var ValidationError = class extends Error {
        constructor(errors) {
          super("validation failed");
          this.errors = errors;
          this.ajv = this.validation = true;
        }
      };
      exports.default = ValidationError;
    }
  });

  // node_modules/ajv/dist/compile/ref_error.js
  var require_ref_error = __commonJS({
    "node_modules/ajv/dist/compile/ref_error.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var resolve_1 = require_resolve();
      var MissingRefError = class extends Error {
        constructor(resolver, baseId, ref, msg) {
          super(msg || `can't resolve reference ${ref} from id ${baseId}`);
          this.missingRef = (0, resolve_1.resolveUrl)(resolver, baseId, ref);
          this.missingSchema = (0, resolve_1.normalizeId)((0, resolve_1.getFullPath)(resolver, this.missingRef));
        }
      };
      exports.default = MissingRefError;
    }
  });

  // node_modules/ajv/dist/compile/index.js
  var require_compile = __commonJS({
    "node_modules/ajv/dist/compile/index.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.resolveSchema = exports.getCompilingSchema = exports.resolveRef = exports.compileSchema = exports.SchemaEnv = void 0;
      var codegen_1 = require_codegen();
      var validation_error_1 = require_validation_error();
      var names_1 = require_names();
      var resolve_1 = require_resolve();
      var util_1 = require_util();
      var validate_1 = require_validate();
      var SchemaEnv = class {
        constructor(env) {
          var _a;
          this.refs = {};
          this.dynamicAnchors = {};
          let schema;
          if (typeof env.schema == "object")
            schema = env.schema;
          this.schema = env.schema;
          this.schemaId = env.schemaId;
          this.root = env.root || this;
          this.baseId = (_a = env.baseId) !== null && _a !== void 0 ? _a : (0, resolve_1.normalizeId)(schema === null || schema === void 0 ? void 0 : schema[env.schemaId || "$id"]);
          this.schemaPath = env.schemaPath;
          this.localRefs = env.localRefs;
          this.meta = env.meta;
          this.$async = schema === null || schema === void 0 ? void 0 : schema.$async;
          this.refs = {};
        }
      };
      exports.SchemaEnv = SchemaEnv;
      function compileSchema(sch) {
        const _sch = getCompilingSchema.call(this, sch);
        if (_sch)
          return _sch;
        const rootId = (0, resolve_1.getFullPath)(this.opts.uriResolver, sch.root.baseId);
        const { es5, lines } = this.opts.code;
        const { ownProperties } = this.opts;
        const gen = new codegen_1.CodeGen(this.scope, { es5, lines, ownProperties });
        let _ValidationError;
        if (sch.$async) {
          _ValidationError = gen.scopeValue("Error", {
            ref: validation_error_1.default,
            code: (0, codegen_1._)`require("ajv/dist/runtime/validation_error").default`
          });
        }
        const validateName = gen.scopeName("validate");
        sch.validateName = validateName;
        const schemaCxt = {
          gen,
          allErrors: this.opts.allErrors,
          data: names_1.default.data,
          parentData: names_1.default.parentData,
          parentDataProperty: names_1.default.parentDataProperty,
          dataNames: [names_1.default.data],
          dataPathArr: [codegen_1.nil],
          // TODO can its length be used as dataLevel if nil is removed?
          dataLevel: 0,
          dataTypes: [],
          definedProperties: /* @__PURE__ */ new Set(),
          topSchemaRef: gen.scopeValue("schema", this.opts.code.source === true ? { ref: sch.schema, code: (0, codegen_1.stringify)(sch.schema) } : { ref: sch.schema }),
          validateName,
          ValidationError: _ValidationError,
          schema: sch.schema,
          schemaEnv: sch,
          rootId,
          baseId: sch.baseId || rootId,
          schemaPath: codegen_1.nil,
          errSchemaPath: sch.schemaPath || (this.opts.jtd ? "" : "#"),
          errorPath: (0, codegen_1._)`""`,
          opts: this.opts,
          self: this
        };
        let sourceCode;
        try {
          this._compilations.add(sch);
          (0, validate_1.validateFunctionCode)(schemaCxt);
          gen.optimize(this.opts.code.optimize);
          const validateCode = gen.toString();
          sourceCode = `${gen.scopeRefs(names_1.default.scope)}return ${validateCode}`;
          if (this.opts.code.process)
            sourceCode = this.opts.code.process(sourceCode, sch);
          const makeValidate = new Function(`${names_1.default.self}`, `${names_1.default.scope}`, sourceCode);
          const validate = makeValidate(this, this.scope.get());
          this.scope.value(validateName, { ref: validate });
          validate.errors = null;
          validate.schema = sch.schema;
          validate.schemaEnv = sch;
          if (sch.$async)
            validate.$async = true;
          if (this.opts.code.source === true) {
            validate.source = { validateName, validateCode, scopeValues: gen._values };
          }
          if (this.opts.unevaluated) {
            const { props, items } = schemaCxt;
            validate.evaluated = {
              props: props instanceof codegen_1.Name ? void 0 : props,
              items: items instanceof codegen_1.Name ? void 0 : items,
              dynamicProps: props instanceof codegen_1.Name,
              dynamicItems: items instanceof codegen_1.Name
            };
            if (validate.source)
              validate.source.evaluated = (0, codegen_1.stringify)(validate.evaluated);
          }
          sch.validate = validate;
          return sch;
        } catch (e) {
          delete sch.validate;
          delete sch.validateName;
          if (sourceCode)
            this.logger.error("Error compiling schema, function code:", sourceCode);
          throw e;
        } finally {
          this._compilations.delete(sch);
        }
      }
      exports.compileSchema = compileSchema;
      function resolveRef(root, baseId, ref) {
        var _a;
        ref = (0, resolve_1.resolveUrl)(this.opts.uriResolver, baseId, ref);
        const schOrFunc = root.refs[ref];
        if (schOrFunc)
          return schOrFunc;
        let _sch = resolve.call(this, root, ref);
        if (_sch === void 0) {
          const schema = (_a = root.localRefs) === null || _a === void 0 ? void 0 : _a[ref];
          const { schemaId } = this.opts;
          if (schema)
            _sch = new SchemaEnv({ schema, schemaId, root, baseId });
        }
        if (_sch === void 0)
          return;
        return root.refs[ref] = inlineOrCompile.call(this, _sch);
      }
      exports.resolveRef = resolveRef;
      function inlineOrCompile(sch) {
        if ((0, resolve_1.inlineRef)(sch.schema, this.opts.inlineRefs))
          return sch.schema;
        return sch.validate ? sch : compileSchema.call(this, sch);
      }
      function getCompilingSchema(schEnv) {
        for (const sch of this._compilations) {
          if (sameSchemaEnv(sch, schEnv))
            return sch;
        }
      }
      exports.getCompilingSchema = getCompilingSchema;
      function sameSchemaEnv(s1, s2) {
        return s1.schema === s2.schema && s1.root === s2.root && s1.baseId === s2.baseId;
      }
      function resolve(root, ref) {
        let sch;
        while (typeof (sch = this.refs[ref]) == "string")
          ref = sch;
        return sch || this.schemas[ref] || resolveSchema.call(this, root, ref);
      }
      function resolveSchema(root, ref) {
        const p = this.opts.uriResolver.parse(ref);
        const refPath = (0, resolve_1._getFullPath)(this.opts.uriResolver, p);
        let baseId = (0, resolve_1.getFullPath)(this.opts.uriResolver, root.baseId, void 0);
        if (Object.keys(root.schema).length > 0 && refPath === baseId) {
          return getJsonPointer.call(this, p, root);
        }
        const id = (0, resolve_1.normalizeId)(refPath);
        const schOrRef = this.refs[id] || this.schemas[id];
        if (typeof schOrRef == "string") {
          const sch = resolveSchema.call(this, root, schOrRef);
          if (typeof (sch === null || sch === void 0 ? void 0 : sch.schema) !== "object")
            return;
          return getJsonPointer.call(this, p, sch);
        }
        if (typeof (schOrRef === null || schOrRef === void 0 ? void 0 : schOrRef.schema) !== "object")
          return;
        if (!schOrRef.validate)
          compileSchema.call(this, schOrRef);
        if (id === (0, resolve_1.normalizeId)(ref)) {
          const { schema } = schOrRef;
          const { schemaId } = this.opts;
          const schId = schema[schemaId];
          if (schId)
            baseId = (0, resolve_1.resolveUrl)(this.opts.uriResolver, baseId, schId);
          return new SchemaEnv({ schema, schemaId, root, baseId });
        }
        return getJsonPointer.call(this, p, schOrRef);
      }
      exports.resolveSchema = resolveSchema;
      var PREVENT_SCOPE_CHANGE = /* @__PURE__ */ new Set([
        "properties",
        "patternProperties",
        "enum",
        "dependencies",
        "definitions"
      ]);
      function getJsonPointer(parsedRef, { baseId, schema, root }) {
        var _a;
        if (((_a = parsedRef.fragment) === null || _a === void 0 ? void 0 : _a[0]) !== "/")
          return;
        for (const part of parsedRef.fragment.slice(1).split("/")) {
          if (typeof schema === "boolean")
            return;
          const partSchema = schema[(0, util_1.unescapeFragment)(part)];
          if (partSchema === void 0)
            return;
          schema = partSchema;
          const schId = typeof schema === "object" && schema[this.opts.schemaId];
          if (!PREVENT_SCOPE_CHANGE.has(part) && schId) {
            baseId = (0, resolve_1.resolveUrl)(this.opts.uriResolver, baseId, schId);
          }
        }
        let env;
        if (typeof schema != "boolean" && schema.$ref && !(0, util_1.schemaHasRulesButRef)(schema, this.RULES)) {
          const $ref = (0, resolve_1.resolveUrl)(this.opts.uriResolver, baseId, schema.$ref);
          env = resolveSchema.call(this, root, $ref);
        }
        const { schemaId } = this.opts;
        env = env || new SchemaEnv({ schema, schemaId, root, baseId });
        if (env.schema !== env.root.schema)
          return env;
        return void 0;
      }
    }
  });

  // node_modules/ajv/dist/refs/data.json
  var require_data = __commonJS({
    "node_modules/ajv/dist/refs/data.json"(exports, module) {
      module.exports = {
        $id: "https://raw.githubusercontent.com/ajv-validator/ajv/master/lib/refs/data.json#",
        description: "Meta-schema for $data reference (JSON AnySchema extension proposal)",
        type: "object",
        required: ["$data"],
        properties: {
          $data: {
            type: "string",
            anyOf: [{ format: "relative-json-pointer" }, { format: "json-pointer" }]
          }
        },
        additionalProperties: false
      };
    }
  });

  // node_modules/fast-uri/lib/utils.js
  var require_utils = __commonJS({
    "node_modules/fast-uri/lib/utils.js"(exports, module) {
      "use strict";
      var isUUID = RegExp.prototype.test.bind(/^[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12}$/iu);
      var isIPv4 = RegExp.prototype.test.bind(/^(?:(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|\d)$/u);
      var isPort = RegExp.prototype.test.bind(/^\d*$/u);
      var isHexPair = RegExp.prototype.test.bind(/^[\da-f]{2}$/iu);
      var isUnreserved = RegExp.prototype.test.bind(/^[\da-z\-._~]$/iu);
      var isPathCharacter = RegExp.prototype.test.bind(/^[A-Za-z0-9\-._~!$&'()*+,;=:@/]$/u);
      var isQueryFragmentCharacter = RegExp.prototype.test.bind(/^[A-Za-z0-9\-._~!$&'()*+,;=:@/?]$/u);
      var isUserinfoCharacter = RegExp.prototype.test.bind(/^[A-Za-z0-9\-._~!$&'()*+,;=:]$/u);
      var BYTE_HEX = new Array(256);
      {
        const HEX_DIGITS = "0123456789ABCDEF";
        for (let i = 0; i < 256; i++) {
          BYTE_HEX[i] = "%" + HEX_DIGITS[i >> 4] + HEX_DIGITS[i & 15];
        }
      }
      function percentEncodeNonAscii(cp) {
        if (cp < 2048) {
          return BYTE_HEX[192 | cp >> 6] + BYTE_HEX[128 | cp & 63];
        }
        if (cp < 65536) {
          return BYTE_HEX[224 | cp >> 12] + BYTE_HEX[128 | cp >> 6 & 63] + BYTE_HEX[128 | cp & 63];
        }
        return BYTE_HEX[240 | cp >> 18] + BYTE_HEX[128 | cp >> 12 & 63] + BYTE_HEX[128 | cp >> 6 & 63] + BYTE_HEX[128 | cp & 63];
      }
      function stringArrayToHexStripped(input) {
        let acc = "";
        let code = 0;
        let i = 0;
        for (i = 0; i < input.length; i++) {
          code = input[i].charCodeAt(0);
          if (code === 48) {
            continue;
          }
          if (!(code >= 48 && code <= 57 || code >= 65 && code <= 70 || code >= 97 && code <= 102)) {
            return "";
          }
          acc += input[i];
          break;
        }
        for (i += 1; i < input.length; i++) {
          code = input[i].charCodeAt(0);
          if (!(code >= 48 && code <= 57 || code >= 65 && code <= 70 || code >= 97 && code <= 102)) {
            return "";
          }
          acc += input[i];
        }
        return acc;
      }
      var isHextet = RegExp.prototype.test.bind(/^[\dA-Fa-f]{1,4}$/);
      var isIPvFuture = RegExp.prototype.test.bind(/^[vV][\dA-Fa-f]+\.[A-Za-z\d\-._~!$&'()*+,;=:]+$/);
      var isZoneCharacter = RegExp.prototype.test.bind(/^[A-Za-z\d\-._~]$/);
      var nonSimpleDomain = RegExp.prototype.test.bind(/[^!"$&'()*+,\-.;=_`a-z{}~]/u);
      function isZoneIdentifier(zone) {
        if (zone.length === 0) return false;
        for (let i = 0; i < zone.length; i++) {
          if (isZoneCharacter(zone[i])) continue;
          if (zone[i] === "%" && i + 2 < zone.length && isHexPair(zone.slice(i + 1, i + 3))) {
            i += 2;
            continue;
          }
          return false;
        }
        return true;
      }
      function compressIPv6ZeroRun(hextets) {
        let bestStart = -1;
        let bestLength = 0;
        let runStart = -1;
        let runLength = 0;
        for (let i = 0; i < hextets.length; i++) {
          if (hextets[i] === "0") {
            if (runStart === -1) runStart = i;
            runLength++;
            if (runLength > bestLength) {
              bestLength = runLength;
              bestStart = runStart;
            }
          } else {
            runStart = -1;
            runLength = 0;
          }
        }
        if (bestLength < 2) return hextets.join(":");
        const head = hextets.slice(0, bestStart).join(":");
        const tail = hextets.slice(bestStart + bestLength).join(":");
        return head + "::" + tail;
      }
      function normalizeIPv6Address(input) {
        const compression = input.indexOf("::");
        if (compression !== -1 && input.indexOf("::", compression + 1) !== -1) return void 0;
        const left = compression === -1 ? input.split(":") : input.slice(0, compression).split(":");
        const right = compression === -1 ? [] : input.slice(compression + 2).split(":");
        if (compression !== -1) {
          if (left.length === 1 && left[0] === "") left.length = 0;
          if (right.length === 1 && right[0] === "") right.length = 0;
        }
        const parts = left.concat(right);
        let hextetCount = 0;
        for (let i = 0; i < parts.length; i++) {
          const part = parts[i];
          if (part === "") return void 0;
          if (part.indexOf(".") !== -1) {
            if (i !== parts.length - 1 || compression !== -1 && right.length === 0 || !isIPv4(part)) return void 0;
            hextetCount += 2;
            continue;
          }
          if (!isHextet(part)) return void 0;
          parts[i] = parseInt(part, 16).toString(16);
          hextetCount++;
        }
        if (compression === -1) {
          if (hextetCount !== 8) return void 0;
          return compressIPv6ZeroRun(parts);
        }
        if (hextetCount >= 8) return void 0;
        const expanded = parts.slice(0, left.length);
        for (let i = hextetCount; i < 8; i++) expanded.push("0");
        for (let i = left.length; i < parts.length; i++) expanded.push(parts[i]);
        return compressIPv6ZeroRun(expanded);
      }
      function normalizeIPv6(host) {
        const bracketed = host[0] === "[" && host[host.length - 1] === "]";
        const hasBracket = host[0] === "[" || host[host.length - 1] === "]";
        if (hasBracket && !bracketed) return { host, isIPV6: false, error: true };
        let input = bracketed ? host.slice(1, -1) : host;
        if (bracketed && isIPvFuture(input)) {
          input = input.toLowerCase();
          return { host: `[${input}]`, escapedHost: input, isIPV6: false, isIPVFuture: true };
        }
        if (findToken(input, ":") < 2) {
          return { host, isIPV6: false, error: bracketed };
        }
        let zoneIdentifier = "";
        const zoneSeparator = input.indexOf("%");
        if (zoneSeparator !== -1) {
          const separatorLength = input.slice(zoneSeparator, zoneSeparator + 3).toLowerCase() === "%25" ? 3 : 1;
          zoneIdentifier = input.slice(zoneSeparator + separatorLength);
          if (!isZoneIdentifier(zoneIdentifier)) return { host, isIPV6: false, error: true };
          input = input.slice(0, zoneSeparator);
        }
        const address = normalizeIPv6Address(input);
        if (address === void 0) return { host, isIPV6: false, error: true };
        return {
          host: address + (zoneIdentifier ? "%" + zoneIdentifier : ""),
          escapedHost: address + (zoneIdentifier ? "%25" + zoneIdentifier : ""),
          isIPV6: true
        };
      }
      function findToken(str, token) {
        let ind = 0;
        for (let i = 0; i < str.length; i++) {
          if (str[i] === token) ind++;
        }
        return ind;
      }
      function removeDotSegments(path) {
        let input = path;
        const output = [];
        let nextSlash = -1;
        let len = 0;
        while (len = input.length) {
          if (len === 1) {
            if (input === ".") {
              break;
            } else if (input === "/") {
              output.push("/");
              break;
            } else {
              output.push(input);
              break;
            }
          } else if (len === 2) {
            if (input[0] === ".") {
              if (input[1] === ".") {
                break;
              } else if (input[1] === "/") {
                input = input.slice(2);
                continue;
              }
            } else if (input[0] === "/") {
              if (input[1] === "." || input[1] === "/") {
                output.push("/");
                break;
              }
            }
          } else if (len === 3) {
            if (input === "/..") {
              if (output.length !== 0) {
                output.pop();
              }
              output.push("/");
              break;
            }
          }
          if (input[0] === ".") {
            if (input[1] === ".") {
              if (input[2] === "/") {
                input = input.slice(3);
                continue;
              }
            } else if (input[1] === "/") {
              input = input.slice(2);
              continue;
            }
          } else if (input[0] === "/") {
            if (input[1] === ".") {
              if (input[2] === "/") {
                input = input.slice(2);
                continue;
              } else if (input[2] === ".") {
                if (input[3] === "/") {
                  input = input.slice(3);
                  if (output.length !== 0) {
                    output.pop();
                  }
                  continue;
                }
              }
            }
          }
          if ((nextSlash = input.indexOf("/", 1)) === -1) {
            output.push(input);
            break;
          } else {
            output.push(input.slice(0, nextSlash));
            input = input.slice(nextSlash);
          }
        }
        return output.join("");
      }
      var HOST_DELIMS = { "@": "%40", "/": "%2F", "?": "%3F", "#": "%23", ":": "%3A" };
      var HOST_DELIM_RE = /[@/?#:]/g;
      var HOST_DELIM_NO_COLON_RE = /[@/?#]/g;
      function reescapeHostDelimiters(host, isIP) {
        const re = isIP ? HOST_DELIM_NO_COLON_RE : HOST_DELIM_RE;
        re.lastIndex = 0;
        return host.replace(re, (ch) => HOST_DELIMS[ch]);
      }
      function normalizePercentEncoding(input, decodeUnreserved = false) {
        if (input.indexOf("%") === -1) {
          return input;
        }
        let output = "";
        for (let i = 0; i < input.length; i++) {
          if (input[i] === "%" && i + 2 < input.length) {
            const hex = input.slice(i + 1, i + 3);
            if (isHexPair(hex)) {
              const normalizedHex = hex.toUpperCase();
              const decoded = String.fromCharCode(parseInt(normalizedHex, 16));
              if (decodeUnreserved && isUnreserved(decoded)) {
                output += decoded;
              } else {
                output += "%" + normalizedHex;
              }
              i += 2;
              continue;
            }
          }
          output += input[i];
        }
        return output;
      }
      function normalizePathEncoding(input) {
        let output = "";
        for (let i = 0; i < input.length; i++) {
          const ch = input[i];
          if (ch === "%" && i + 2 < input.length) {
            const hex = input.slice(i + 1, i + 3);
            if (isHexPair(hex)) {
              const normalizedHex = hex.toUpperCase();
              const decoded = String.fromCharCode(parseInt(normalizedHex, 16));
              if (decoded !== "." && isUnreserved(decoded)) {
                output += decoded;
              } else {
                output += "%" + normalizedHex;
              }
              i += 2;
              continue;
            }
          }
          if (isPathCharacter(ch)) {
            output += ch;
          } else {
            const code = input.charCodeAt(i);
            if (code < 128) {
              output += isEscapeSafe(code) ? ch : BYTE_HEX[code];
            } else if (code < 55296 || code > 57343) {
              output += percentEncodeNonAscii(code);
            } else if (code <= 56319 && i + 1 < input.length) {
              const low = input.charCodeAt(i + 1);
              if (low >= 56320 && low <= 57343) {
                output += percentEncodeNonAscii(65536 + (code - 55296 << 10) + (low - 56320));
                i++;
              } else {
                output += percentEncodeNonAscii(65533);
              }
            } else {
              output += percentEncodeNonAscii(65533);
            }
          }
        }
        return output;
      }
      function serializePathEncoding(input, pathNoScheme = false) {
        let output = "";
        let firstSegment = pathNoScheme && input[0] !== "/";
        for (let i = 0; i < input.length; i++) {
          const ch = input[i];
          if (ch === "%" && i + 2 < input.length) {
            const hex = input.slice(i + 1, i + 3);
            if (isHexPair(hex)) {
              output += "%" + hex.toUpperCase();
              i += 2;
              continue;
            }
          }
          if (ch === "/") {
            firstSegment = false;
          }
          if (isPathCharacter(ch) && (ch !== ":" || !firstSegment)) {
            output += ch;
          } else {
            const code = input.charCodeAt(i);
            if (code < 128) {
              output += BYTE_HEX[code];
            } else if (code < 55296 || code > 57343) {
              output += percentEncodeNonAscii(code);
            } else if (code <= 56319 && i + 1 < input.length) {
              const low = input.charCodeAt(i + 1);
              if (low >= 56320 && low <= 57343) {
                output += percentEncodeNonAscii(65536 + (code - 55296 << 10) + (low - 56320));
                i++;
              } else {
                output += percentEncodeNonAscii(65533);
              }
            } else {
              output += percentEncodeNonAscii(65533);
            }
          }
        }
        return output;
      }
      function encodeComponent(input, isAllowed) {
        let output = "";
        for (let i = 0; i < input.length; i++) {
          const ch = input[i];
          if (ch === "%" && i + 2 < input.length) {
            const hex = input.slice(i + 1, i + 3);
            if (isHexPair(hex)) {
              output += "%" + hex.toUpperCase();
              i += 2;
              continue;
            }
          }
          if (isAllowed(ch)) {
            output += ch;
          } else {
            const code = input.charCodeAt(i);
            if (code < 128) {
              output += BYTE_HEX[code];
            } else if (code < 55296 || code > 57343) {
              output += percentEncodeNonAscii(code);
            } else if (code <= 56319 && i + 1 < input.length) {
              const low = input.charCodeAt(i + 1);
              if (low >= 56320 && low <= 57343) {
                output += percentEncodeNonAscii(65536 + (code - 55296 << 10) + (low - 56320));
                i++;
              } else {
                output += percentEncodeNonAscii(65533);
              }
            } else {
              output += percentEncodeNonAscii(65533);
            }
          }
        }
        return output;
      }
      function encodeUserinfo(input) {
        return encodeComponent(input, isUserinfoCharacter);
      }
      function encodeQuery(input) {
        return encodeComponent(input, isQueryFragmentCharacter);
      }
      function encodeFragment(input) {
        return encodeComponent(input, isQueryFragmentCharacter);
      }
      function isEscapeSafe(cp) {
        return cp >= 48 && cp <= 57 || cp >= 65 && cp <= 90 || cp >= 97 && cp <= 122 || cp === 42 || cp === 43 || cp === 45 || cp === 46 || cp === 47 || cp === 64 || cp === 95;
      }
      function normalizeQueryFragmentEncoding(input) {
        let output = "";
        for (let i = 0; i < input.length; i++) {
          const ch = input[i];
          if (ch === "%" && i + 2 < input.length) {
            const hex = input.slice(i + 1, i + 3);
            if (isHexPair(hex)) {
              const normalizedHex = hex.toUpperCase();
              const decoded = String.fromCharCode(parseInt(normalizedHex, 16));
              if (isUnreserved(decoded)) {
                output += decoded;
              } else {
                output += "%" + normalizedHex;
              }
              i += 2;
              continue;
            }
          }
          if (isQueryFragmentCharacter(ch)) {
            output += ch;
          } else {
            const code = input.charCodeAt(i);
            if (code < 128) {
              output += isEscapeSafe(code) ? ch : BYTE_HEX[code];
            } else if (code < 55296 || code > 57343) {
              output += percentEncodeNonAscii(code);
            } else if (code <= 56319 && i + 1 < input.length) {
              const low = input.charCodeAt(i + 1);
              if (low >= 56320 && low <= 57343) {
                output += percentEncodeNonAscii(65536 + (code - 55296 << 10) + (low - 56320));
                i++;
              } else {
                output += percentEncodeNonAscii(65533);
              }
            } else {
              output += percentEncodeNonAscii(65533);
            }
          }
        }
        return output;
      }
      function escapePreservingEscapes(input) {
        let output = "";
        for (let i = 0; i < input.length; i++) {
          if (input[i] === "%" && i + 2 < input.length) {
            const hex = input.slice(i + 1, i + 3);
            if (isHexPair(hex)) {
              output += "%" + hex.toUpperCase();
              i += 2;
              continue;
            }
          }
          output += escape(input[i]);
        }
        return output;
      }
      function recomposeAuthority(component) {
        const uriTokens = [];
        if (component.userinfo !== void 0) {
          uriTokens.push(encodeUserinfo(component.userinfo));
          uriTokens.push("@");
        }
        if (component.host !== void 0) {
          let host = component.host;
          if (!isIPv4(host)) {
            let ipV6res = normalizeIPv6(host);
            if (ipV6res.isIPV6 !== true && ipV6res.isIPVFuture !== true) {
              host = normalizePercentEncoding(host, true);
              ipV6res = normalizeIPv6(host);
            }
            if (ipV6res.isIPV6 === true || ipV6res.isIPVFuture === true) {
              host = `[${ipV6res.escapedHost}]`;
            } else {
              host = reescapeHostDelimiters(host, false);
            }
          }
          uriTokens.push(host);
        }
        if (typeof component.port === "number" || typeof component.port === "string") {
          const port4 = String(component.port);
          if (!isPort(port4)) {
            throw new TypeError("URI port is malformed.");
          }
          uriTokens.push(":");
          uriTokens.push(port4);
        }
        return uriTokens.length ? uriTokens.join("") : void 0;
      }
      module.exports = {
        nonSimpleDomain,
        recomposeAuthority,
        reescapeHostDelimiters,
        normalizePercentEncoding,
        normalizePathEncoding,
        serializePathEncoding,
        normalizeQueryFragmentEncoding,
        encodeUserinfo,
        encodeQuery,
        encodeFragment,
        escapePreservingEscapes,
        removeDotSegments,
        isIPv4,
        isUUID,
        normalizeIPv6,
        stringArrayToHexStripped
      };
    }
  });

  // node_modules/fast-uri/lib/schemes.js
  var require_schemes = __commonJS({
    "node_modules/fast-uri/lib/schemes.js"(exports, module) {
      "use strict";
      var { isUUID } = require_utils();
      var URN_REG = /^([\da-z][\d\-a-z]{0,31}):((?:[\w!$'()*+,\-./:;=@]|%[\da-f]{2})+)$/iu;
      var supportedSchemeNames = (
        /** @type {const} */
        [
          "http",
          "https",
          "ws",
          "wss",
          "urn",
          "urn:uuid"
        ]
      );
      function isValidSchemeName(name) {
        return supportedSchemeNames.indexOf(
          /** @type {*} */
          name
        ) !== -1;
      }
      function wsIsSecure(wsComponent) {
        if (wsComponent.secure === true) {
          return true;
        } else if (wsComponent.secure === false) {
          return false;
        } else if (wsComponent.scheme) {
          return wsComponent.scheme.length === 3 && (wsComponent.scheme[0] === "w" || wsComponent.scheme[0] === "W") && (wsComponent.scheme[1] === "s" || wsComponent.scheme[1] === "S") && (wsComponent.scheme[2] === "s" || wsComponent.scheme[2] === "S");
        } else {
          return false;
        }
      }
      function httpParse(component) {
        if (!component.host) {
          component.error = component.error || "HTTP URIs must have a host.";
        }
        return component;
      }
      function httpSerialize(component) {
        const secure = String(component.scheme).toLowerCase() === "https";
        if (component.port === (secure ? 443 : 80) || component.port === "") {
          component.port = void 0;
        }
        if (!component.path) {
          component.path = "/";
        }
        return component;
      }
      function wsParse(wsComponent) {
        wsComponent.secure = wsIsSecure(wsComponent);
        wsComponent.resourceName = (wsComponent.path || "/") + (wsComponent.query ? "?" + wsComponent.query : "");
        wsComponent.path = void 0;
        wsComponent.query = void 0;
        return wsComponent;
      }
      function wsSerialize(wsComponent) {
        if (wsComponent.port === (wsIsSecure(wsComponent) ? 443 : 80) || wsComponent.port === "") {
          wsComponent.port = void 0;
        }
        if (typeof wsComponent.secure === "boolean") {
          wsComponent.scheme = wsComponent.secure ? "wss" : "ws";
          wsComponent.secure = void 0;
        }
        if (wsComponent.resourceName) {
          const queryIndex = wsComponent.resourceName.indexOf("?");
          const path = queryIndex === -1 ? wsComponent.resourceName : wsComponent.resourceName.slice(0, queryIndex);
          wsComponent.path = path && path !== "/" ? path : void 0;
          wsComponent.query = queryIndex === -1 ? void 0 : wsComponent.resourceName.slice(queryIndex + 1);
          wsComponent.resourceName = void 0;
        }
        wsComponent.fragment = void 0;
        return wsComponent;
      }
      function urnParse(urnComponent, options) {
        if (!urnComponent.path) {
          urnComponent.error = "URN can not be parsed";
          return urnComponent;
        }
        const matches = urnComponent.path.match(URN_REG);
        if (matches && matches[0] === urnComponent.path) {
          const scheme = options.scheme || urnComponent.scheme || "urn";
          urnComponent.nid = matches[1].toLowerCase();
          urnComponent.nss = matches[2];
          const urnScheme = `${scheme}:${options.nid || urnComponent.nid}`;
          const schemeHandler = getSchemeHandler(urnScheme);
          urnComponent.path = void 0;
          if (schemeHandler) {
            urnComponent = schemeHandler.parse(urnComponent, options);
          }
        } else {
          urnComponent.error = urnComponent.error || "URN can not be parsed.";
        }
        return urnComponent;
      }
      function urnSerialize(urnComponent, options) {
        if (urnComponent.nid === void 0) {
          throw new Error("URN without nid cannot be serialized");
        }
        const scheme = options.scheme || urnComponent.scheme || "urn";
        const nid = urnComponent.nid.toLowerCase();
        const urnScheme = `${scheme}:${options.nid || nid}`;
        const schemeHandler = getSchemeHandler(urnScheme);
        if (schemeHandler) {
          urnComponent = schemeHandler.serialize(urnComponent, options);
        }
        const uriComponent = urnComponent;
        const nss = urnComponent.nss;
        uriComponent.path = `${nid || options.nid}:${nss}`;
        options.skipEscape = true;
        return uriComponent;
      }
      function urnuuidParse(urnComponent, options) {
        const uuidComponent = urnComponent;
        uuidComponent.uuid = uuidComponent.nss;
        uuidComponent.nss = void 0;
        if (!options.tolerant && (!uuidComponent.uuid || !isUUID(uuidComponent.uuid))) {
          uuidComponent.error = uuidComponent.error || "UUID is not valid.";
        }
        return uuidComponent;
      }
      function urnuuidSerialize(uuidComponent) {
        const urnComponent = uuidComponent;
        urnComponent.nss = (uuidComponent.uuid || "").toLowerCase();
        return urnComponent;
      }
      var http = (
        /** @type {SchemeHandler} */
        {
          scheme: "http",
          domainHost: true,
          parse: httpParse,
          serialize: httpSerialize
        }
      );
      var https = (
        /** @type {SchemeHandler} */
        {
          scheme: "https",
          domainHost: http.domainHost,
          parse: httpParse,
          serialize: httpSerialize
        }
      );
      var ws = (
        /** @type {SchemeHandler} */
        {
          scheme: "ws",
          domainHost: true,
          parse: wsParse,
          serialize: wsSerialize
        }
      );
      var wss = (
        /** @type {SchemeHandler} */
        {
          scheme: "wss",
          domainHost: ws.domainHost,
          parse: ws.parse,
          serialize: ws.serialize
        }
      );
      var urn = (
        /** @type {SchemeHandler} */
        {
          scheme: "urn",
          parse: urnParse,
          serialize: urnSerialize,
          skipNormalize: true
        }
      );
      var urnuuid = (
        /** @type {SchemeHandler} */
        {
          scheme: "urn:uuid",
          parse: urnuuidParse,
          serialize: urnuuidSerialize,
          skipNormalize: true
        }
      );
      var SCHEMES = (
        /** @type {Record<SchemeName, SchemeHandler>} */
        {
          http,
          https,
          ws,
          wss,
          urn,
          "urn:uuid": urnuuid
        }
      );
      Object.setPrototypeOf(SCHEMES, null);
      function getSchemeHandler(scheme) {
        return scheme && (SCHEMES[
          /** @type {SchemeName} */
          scheme
        ] || SCHEMES[
          /** @type {SchemeName} */
          scheme.toLowerCase()
        ]) || void 0;
      }
      module.exports = {
        wsIsSecure,
        SCHEMES,
        isValidSchemeName,
        getSchemeHandler
      };
    }
  });

  // node_modules/fast-uri/index.js
  var require_fast_uri = __commonJS({
    "node_modules/fast-uri/index.js"(exports, module) {
      "use strict";
      var { normalizeIPv6, removeDotSegments, recomposeAuthority, normalizePercentEncoding, normalizePathEncoding, serializePathEncoding, normalizeQueryFragmentEncoding, encodeQuery, encodeFragment, reescapeHostDelimiters, isIPv4, nonSimpleDomain } = require_utils();
      var { SCHEMES, getSchemeHandler } = require_schemes();
      var VALID_SCHEME = /^[A-Za-z][A-Za-z0-9+.-]*$/u;
      var MALFORMED_SCHEME_ERROR = "URI scheme is malformed.";
      function decodeValidScheme(scheme) {
        const decodedScheme = unescape(String(scheme));
        if (!VALID_SCHEME.test(decodedScheme)) {
          throw new TypeError(MALFORMED_SCHEME_ERROR);
        }
        return decodedScheme;
      }
      function normalize(uri, options) {
        if (typeof uri === "string") {
          uri = /** @type {T} */
          normalizeString(uri, options);
        } else if (typeof uri === "object") {
          uri = /** @type {T} */
          parse(serialize(uri, options), options);
        }
        return uri;
      }
      function resolve(baseURI, relativeURI, options) {
        const schemelessOptions = options ? Object.assign({ scheme: "null" }, options) : { scheme: "null" };
        const {
          parsed: baseParsed,
          malformedAuthorityOrPort: baseMalformed,
          malformedPercentEncoding: baseMalformedPercentEncoding,
          malformedSchemeSpecific: baseMalformedSchemeSpecific,
          malformedHost: baseMalformedHost,
          malformedScheme: baseMalformedScheme
        } = parseWithStatus(baseURI, schemelessOptions);
        const {
          parsed: relativeParsed,
          malformedAuthorityOrPort: relativeMalformed,
          malformedPercentEncoding: relativeMalformedPercentEncoding,
          malformedSchemeSpecific: relativeMalformedSchemeSpecific,
          malformedHost: relativeMalformedHost,
          malformedScheme: relativeMalformedScheme
        } = parseWithStatus(relativeURI, schemelessOptions);
        if (baseMalformed || relativeMalformed || baseMalformedPercentEncoding || relativeMalformedPercentEncoding || baseMalformedSchemeSpecific || relativeMalformedSchemeSpecific || baseMalformedHost || relativeMalformedHost || baseMalformedScheme || relativeMalformedScheme) {
          throw new Error(baseParsed.error || relativeParsed.error || "URI is malformed.");
        }
        const resolved = resolveComponent(baseParsed, relativeParsed, schemelessOptions, true);
        const resolvedSchemeHandler = getSchemeHandler(options && options.scheme || resolved.scheme);
        const resolvedHost = resolved.host;
        const resolvedHostIsIP = resolvedHost !== void 0 && resolvedHost !== "" && (isIPv4(resolvedHost) || normalizeIPv6(resolvedHost).isIPV6);
        canonicalizeHost(resolved, options || {}, resolvedSchemeHandler, resolvedHostIsIP);
        const encodedASCIIHost = resolvedHost && resolvedHost.indexOf("%") !== -1 && !/\P{ASCII}/u.test(resolvedHost);
        if (resolved.error && !encodedASCIIHost) {
          throw new Error(resolved.error);
        }
        schemelessOptions.skipEscape = true;
        return serialize(resolved, schemelessOptions);
      }
      function resolveComponent(base, relative, options, skipNormalization) {
        const target = {};
        if (!skipNormalization) {
          base = parse(serialize(base, options), options);
          relative = parse(serialize(relative, options), options);
        }
        options = options || {};
        if (!options.tolerant && relative.scheme) {
          target.scheme = relative.scheme;
          target.userinfo = relative.userinfo;
          target.host = relative.host;
          target.port = relative.port;
          target.path = removeDotSegments(relative.path || "");
          target.query = relative.query;
        } else {
          if (relative.userinfo !== void 0 || relative.host !== void 0 || relative.port !== void 0) {
            target.userinfo = relative.userinfo;
            target.host = relative.host;
            target.port = relative.port;
            target.path = removeDotSegments(relative.path || "");
            target.query = relative.query;
          } else {
            if (!relative.path) {
              target.path = base.path;
              if (relative.query !== void 0) {
                target.query = relative.query;
              } else {
                target.query = base.query;
              }
            } else {
              if (relative.path[0] === "/") {
                target.path = removeDotSegments(relative.path);
              } else {
                if ((base.userinfo !== void 0 || base.host !== void 0 || base.port !== void 0) && !base.path) {
                  target.path = "/" + relative.path;
                } else if (!base.path) {
                  target.path = relative.path;
                } else {
                  target.path = base.path.slice(0, base.path.lastIndexOf("/") + 1) + relative.path;
                }
                target.path = removeDotSegments(target.path);
              }
              target.query = relative.query;
            }
            target.userinfo = base.userinfo;
            target.host = base.host;
            target.port = base.port;
          }
          target.scheme = base.scheme;
        }
        target.fragment = relative.fragment;
        return target;
      }
      function equal(uriA, uriB, options) {
        const normalizedA = normalizeComparableURI(uriA, options);
        const normalizedB = normalizeComparableURI(uriB, options);
        return normalizedA !== void 0 && normalizedB !== void 0 && normalizedA === normalizedB;
      }
      function serialize(cmpts, opts) {
        const component = {
          host: cmpts.host,
          scheme: cmpts.scheme,
          userinfo: cmpts.userinfo,
          port: cmpts.port,
          path: cmpts.path,
          query: cmpts.query,
          nid: cmpts.nid,
          nss: cmpts.nss,
          uuid: cmpts.uuid,
          fragment: cmpts.fragment,
          reference: cmpts.reference,
          resourceName: cmpts.resourceName,
          secure: cmpts.secure,
          error: ""
        };
        const options = Object.assign({}, opts);
        const uriTokens = [];
        if (component.scheme) {
          component.scheme = decodeValidScheme(component.scheme);
        }
        const schemeHandler = getSchemeHandler(options.scheme || component.scheme);
        if (schemeHandler && schemeHandler.serialize) schemeHandler.serialize(component, options);
        const hasAuthority = component.userinfo !== void 0 || component.host !== void 0 || component.port !== void 0;
        const pathNoScheme = !options.skipEscape && component.scheme === void 0 && !hasAuthority;
        if (component.path !== void 0) {
          if (!options.skipEscape) {
            component.path = serializePathEncoding(component.path, pathNoScheme);
          } else {
            component.path = normalizePercentEncoding(component.path);
          }
        }
        if (options.reference !== "suffix" && component.scheme) {
          component.scheme = decodeValidScheme(component.scheme);
          uriTokens.push(component.scheme, ":");
        }
        const authority = recomposeAuthority(component);
        if (authority !== void 0) {
          if (options.reference !== "suffix") {
            uriTokens.push("//");
          }
          uriTokens.push(authority);
          if (component.path && component.path[0] !== "/") {
            uriTokens.push("/");
          }
        }
        if (component.path !== void 0) {
          let s = component.path;
          if (!options.absolutePath && (!schemeHandler || !schemeHandler.absolutePath)) {
            s = removeDotSegments(s);
          }
          if (pathNoScheme) {
            s = serializePathEncoding(s, true);
          }
          if (authority === void 0 && s[0] === "/" && s[1] === "/") {
            s = "/%2F" + s.slice(2);
          }
          uriTokens.push(s);
        }
        if (component.query !== void 0) {
          uriTokens.push("?", encodeQuery(component.query));
        }
        if (component.fragment !== void 0) {
          uriTokens.push("#", encodeFragment(component.fragment));
        }
        return uriTokens.join("");
      }
      var URI_PARSE = /^(?:([^#/:?]+):)?(?:\/\/((?:([^#/?@]*)@)?(\[[^#/?\]]+\]|[^#/:?]*)(?::(\d*))?))?([^#?]*)(?:\?([^#]*))?(?:#((?:.|[\n\r])*))?/u;
      var AUTHORITY_PREFIX = /^(?:[^#/:?]+:)?\/\/([^/?#]*)/;
      var AUTHORITY_INTRODUCER_REGION = /^(?:[^#/:?]+:)?([/\\\t\n\r]*)/;
      function getParseError(parsed, matches) {
        if (matches[2] !== void 0 && parsed.path && parsed.path[0] !== "/") {
          return 'URI path must start with "/" when authority is present.';
        }
        if (typeof parsed.port === "number" && (parsed.port < 0 || parsed.port > 65535)) {
          return "URI port is malformed.";
        }
        return void 0;
      }
      function hasMalformedPercentEncoding(component) {
        if (component === void 0) return false;
        let percent = component.indexOf("%");
        while (percent !== -1) {
          if (percent + 2 >= component.length || !/^[\da-f]{2}$/iu.test(component.slice(percent + 1, percent + 3))) {
            return true;
          }
          percent = component.indexOf("%", percent + 3);
        }
        return false;
      }
      function isIPLiteral(host) {
        return host[0] === "[" && host[host.length - 1] === "]";
      }
      function hasMalformedComponentPercentEncoding(matches) {
        const host = matches[4];
        return hasMalformedPercentEncoding(matches[3]) || host !== void 0 && !isIPLiteral(host) && hasMalformedPercentEncoding(host) || hasMalformedPercentEncoding(matches[6]) || hasMalformedPercentEncoding(matches[7]) || hasMalformedPercentEncoding(matches[8]);
      }
      function canonicalizeHost(parsed, options, schemeHandler, isIP) {
        if (!options.unicodeSupport && (!schemeHandler || !schemeHandler.unicodeSupport) && parsed.host && !isIPLiteral(parsed.host) && (options.domainHost || schemeHandler && schemeHandler.domainHost) && isIP === false && nonSimpleDomain(parsed.host)) {
          try {
            parsed.host = new URL("http://" + parsed.host).hostname;
          } catch (e) {
            parsed.error = parsed.error || "Host's domain name can not be converted to ASCII: " + e;
            return true;
          }
        }
        return false;
      }
      function parseWithStatus(uri, opts) {
        const options = Object.assign({}, opts);
        const parsed = {
          scheme: void 0,
          userinfo: void 0,
          host: "",
          port: void 0,
          path: "",
          query: void 0,
          fragment: void 0
        };
        let malformedAuthorityOrPort = false;
        let malformedPercentEncoding = false;
        let malformedSchemeSpecific = false;
        let malformedHost = false;
        let malformedIPLiteral = false;
        let malformedScheme = false;
        let isIP = false;
        if (options.reference === "suffix") {
          if (options.scheme) {
            uri = options.scheme + ":" + uri;
          } else {
            uri = "//" + uri;
          }
        }
        const authorityMatch = uri.match(AUTHORITY_PREFIX);
        if (authorityMatch !== null && authorityMatch[1].indexOf("\\") !== -1) {
          parsed.error = "URI authority must not contain a literal backslash.";
          malformedAuthorityOrPort = true;
        }
        const introducerMatch = uri.match(AUTHORITY_INTRODUCER_REGION);
        if (introducerMatch !== null) {
          const region = introducerMatch[1];
          const normalizedRegion = region.replace(/[\t\n\r]/g, "");
          if (normalizedRegion.length >= 2) {
            if (normalizedRegion.slice(0, 2) !== "//") {
              parsed.error = parsed.error || "URI authority must not contain a literal backslash.";
              malformedAuthorityOrPort = true;
            } else if (region.length !== normalizedRegion.length) {
              parsed.error = parsed.error || "URI authority introducer must not contain whitespace.";
              malformedAuthorityOrPort = true;
            }
          }
        }
        const matches = uri.match(URI_PARSE);
        if (matches) {
          parsed.scheme = matches[1];
          parsed.userinfo = matches[3];
          parsed.host = matches[4];
          parsed.port = parseInt(matches[5], 10);
          parsed.path = matches[6] || "";
          parsed.query = matches[7];
          parsed.fragment = matches[8];
          if (parsed.scheme !== void 0) {
            const decodedScheme = unescape(parsed.scheme);
            if (VALID_SCHEME.test(decodedScheme)) {
              parsed.scheme = decodedScheme.toLowerCase();
            } else {
              parsed.error = parsed.error || MALFORMED_SCHEME_ERROR;
              malformedScheme = true;
            }
          }
          malformedPercentEncoding = hasMalformedComponentPercentEncoding(matches);
          if (malformedPercentEncoding) {
            parsed.error = parsed.error || "URI contains malformed percent-encoding.";
          }
          if (isNaN(parsed.port)) {
            parsed.port = matches[5];
          }
          const parseError = getParseError(parsed, matches);
          if (parseError !== void 0) {
            parsed.error = parsed.error || parseError;
            malformedAuthorityOrPort = true;
          }
          if (parsed.host) {
            const ipv4result = isIPv4(parsed.host);
            if (ipv4result === false) {
              const bracketedIPLiteral = isIPLiteral(parsed.host);
              const hasIPLiteralBracket = parsed.host.indexOf("[") !== -1 || parsed.host.indexOf("]") !== -1;
              const ipv6result = normalizeIPv6(parsed.host);
              isIP = ipv6result.isIPV6 || ipv6result.isIPVFuture === true;
              malformedIPLiteral = hasIPLiteralBracket && (!bracketedIPLiteral || ipv6result.error === true);
              parsed.host = isIP ? ipv6result.host : ipv6result.host.toLowerCase();
              if (malformedIPLiteral) {
                parsed.error = parsed.error || "URI host is malformed.";
                malformedAuthorityOrPort = true;
              }
            } else {
              isIP = true;
            }
          }
          if (parsed.scheme === void 0 && parsed.userinfo === void 0 && parsed.host === void 0 && parsed.port === void 0 && parsed.query === void 0 && !parsed.path) {
            parsed.reference = "same-document";
          } else if (parsed.scheme === void 0) {
            parsed.reference = "relative";
          } else if (parsed.fragment === void 0) {
            parsed.reference = "absolute";
          } else {
            parsed.reference = "uri";
          }
          if (options.reference && options.reference !== "suffix" && options.reference !== parsed.reference) {
            parsed.error = parsed.error || "URI is not a " + options.reference + " reference.";
          }
          const schemeHandler = getSchemeHandler(options.scheme || parsed.scheme);
          if (!malformedIPLiteral) {
            malformedHost = canonicalizeHost(parsed, options, schemeHandler, isIP);
          }
          if (!schemeHandler || schemeHandler && !schemeHandler.skipNormalize) {
            if (uri.indexOf("%") !== -1) {
              if (parsed.host !== void 0 && !malformedIPLiteral) {
                const host = isIP ? parsed.host : normalizePercentEncoding(parsed.host, true);
                parsed.host = reescapeHostDelimiters(host, isIP);
              }
            }
            if (parsed.path) {
              parsed.path = normalizePathEncoding(parsed.path);
            }
            if (parsed.query) {
              parsed.query = normalizeQueryFragmentEncoding(parsed.query);
            }
            if (parsed.fragment) {
              parsed.fragment = normalizeQueryFragmentEncoding(parsed.fragment);
            }
          }
          if (schemeHandler && schemeHandler.parse) {
            schemeHandler.parse(parsed, options);
            if (schemeHandler === SCHEMES.urn && parsed.nid === void 0) {
              malformedSchemeSpecific = true;
            }
          }
        } else {
          parsed.error = parsed.error || "URI can not be parsed.";
        }
        return { parsed, malformedAuthorityOrPort, malformedPercentEncoding, malformedSchemeSpecific, malformedHost, malformedScheme };
      }
      function parse(uri, opts) {
        return parseWithStatus(uri, opts).parsed;
      }
      function normalizeString(uri, opts) {
        return normalizeStringWithStatus(uri, opts).normalized;
      }
      function normalizeStringWithStatus(uri, opts) {
        const { parsed, malformedAuthorityOrPort, malformedPercentEncoding, malformedSchemeSpecific, malformedHost, malformedScheme } = parseWithStatus(uri, opts);
        return {
          normalized: malformedAuthorityOrPort || malformedPercentEncoding || malformedSchemeSpecific || malformedHost || malformedScheme ? uri : serialize(parsed, opts),
          malformedAuthorityOrPort,
          malformedPercentEncoding,
          malformedSchemeSpecific,
          malformedHost,
          malformedScheme
        };
      }
      function normalizeComparableURI(uri, opts) {
        if (typeof uri !== "string" && typeof uri !== "object") {
          return void 0;
        }
        let value;
        try {
          value = typeof uri === "string" ? uri : serialize(uri, opts);
        } catch {
          return void 0;
        }
        const { normalized, malformedAuthorityOrPort, malformedPercentEncoding, malformedSchemeSpecific, malformedHost, malformedScheme } = normalizeStringWithStatus(value, opts);
        return malformedAuthorityOrPort || malformedPercentEncoding || malformedSchemeSpecific || malformedHost || malformedScheme ? void 0 : normalized;
      }
      var fastUri = {
        SCHEMES,
        normalize,
        resolve,
        resolveComponent,
        equal,
        serialize,
        parse
      };
      module.exports = fastUri;
      module.exports.default = fastUri;
      module.exports.fastUri = fastUri;
    }
  });

  // node_modules/ajv/dist/runtime/uri.js
  var require_uri = __commonJS({
    "node_modules/ajv/dist/runtime/uri.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var uri = require_fast_uri();
      uri.code = 'require("ajv/dist/runtime/uri").default';
      exports.default = uri;
    }
  });

  // node_modules/ajv/dist/core.js
  var require_core2 = __commonJS({
    "node_modules/ajv/dist/core.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.CodeGen = exports.Name = exports.nil = exports.stringify = exports.str = exports._ = exports.KeywordCxt = void 0;
      var validate_1 = require_validate();
      Object.defineProperty(exports, "KeywordCxt", { enumerable: true, get: function() {
        return validate_1.KeywordCxt;
      } });
      var codegen_1 = require_codegen();
      Object.defineProperty(exports, "_", { enumerable: true, get: function() {
        return codegen_1._;
      } });
      Object.defineProperty(exports, "str", { enumerable: true, get: function() {
        return codegen_1.str;
      } });
      Object.defineProperty(exports, "stringify", { enumerable: true, get: function() {
        return codegen_1.stringify;
      } });
      Object.defineProperty(exports, "nil", { enumerable: true, get: function() {
        return codegen_1.nil;
      } });
      Object.defineProperty(exports, "Name", { enumerable: true, get: function() {
        return codegen_1.Name;
      } });
      Object.defineProperty(exports, "CodeGen", { enumerable: true, get: function() {
        return codegen_1.CodeGen;
      } });
      var validation_error_1 = require_validation_error();
      var ref_error_1 = require_ref_error();
      var rules_1 = require_rules();
      var compile_1 = require_compile();
      var codegen_2 = require_codegen();
      var resolve_1 = require_resolve();
      var dataType_1 = require_dataType();
      var util_1 = require_util();
      var $dataRefSchema = require_data();
      var uri_1 = require_uri();
      var defaultRegExp = (str, flags) => new RegExp(str, flags);
      defaultRegExp.code = "new RegExp";
      var META_IGNORE_OPTIONS = ["removeAdditional", "useDefaults", "coerceTypes"];
      var EXT_SCOPE_NAMES = /* @__PURE__ */ new Set([
        "validate",
        "serialize",
        "parse",
        "wrapper",
        "root",
        "schema",
        "keyword",
        "pattern",
        "formats",
        "validate$data",
        "func",
        "obj",
        "Error"
      ]);
      var removedOptions = {
        errorDataPath: "",
        format: "`validateFormats: false` can be used instead.",
        nullable: '"nullable" keyword is supported by default.',
        jsonPointers: "Deprecated jsPropertySyntax can be used instead.",
        extendRefs: "Deprecated ignoreKeywordsWithRef can be used instead.",
        missingRefs: "Pass empty schema with $id that should be ignored to ajv.addSchema.",
        processCode: "Use option `code: {process: (code, schemaEnv: object) => string}`",
        sourceCode: "Use option `code: {source: true}`",
        strictDefaults: "It is default now, see option `strict`.",
        strictKeywords: "It is default now, see option `strict`.",
        uniqueItems: '"uniqueItems" keyword is always validated.',
        unknownFormats: "Disable strict mode or pass `true` to `ajv.addFormat` (or `formats` option).",
        cache: "Map is used as cache, schema object as key.",
        serialize: "Map is used as cache, schema object as key.",
        ajvErrors: "It is default now."
      };
      var deprecatedOptions = {
        ignoreKeywordsWithRef: "",
        jsPropertySyntax: "",
        unicode: '"minLength"/"maxLength" account for unicode characters by default.'
      };
      var MAX_EXPRESSION = 200;
      function requiredOptions(o) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0;
        const s = o.strict;
        const _optz = (_a = o.code) === null || _a === void 0 ? void 0 : _a.optimize;
        const optimize = _optz === true || _optz === void 0 ? 1 : _optz || 0;
        const regExp = (_c = (_b = o.code) === null || _b === void 0 ? void 0 : _b.regExp) !== null && _c !== void 0 ? _c : defaultRegExp;
        const uriResolver = (_d = o.uriResolver) !== null && _d !== void 0 ? _d : uri_1.default;
        return {
          strictSchema: (_f = (_e = o.strictSchema) !== null && _e !== void 0 ? _e : s) !== null && _f !== void 0 ? _f : true,
          strictNumbers: (_h = (_g = o.strictNumbers) !== null && _g !== void 0 ? _g : s) !== null && _h !== void 0 ? _h : true,
          strictTypes: (_k = (_j = o.strictTypes) !== null && _j !== void 0 ? _j : s) !== null && _k !== void 0 ? _k : "log",
          strictTuples: (_m = (_l = o.strictTuples) !== null && _l !== void 0 ? _l : s) !== null && _m !== void 0 ? _m : "log",
          strictRequired: (_p = (_o = o.strictRequired) !== null && _o !== void 0 ? _o : s) !== null && _p !== void 0 ? _p : false,
          code: o.code ? { ...o.code, optimize, regExp } : { optimize, regExp },
          loopRequired: (_q = o.loopRequired) !== null && _q !== void 0 ? _q : MAX_EXPRESSION,
          loopEnum: (_r = o.loopEnum) !== null && _r !== void 0 ? _r : MAX_EXPRESSION,
          meta: (_s = o.meta) !== null && _s !== void 0 ? _s : true,
          messages: (_t = o.messages) !== null && _t !== void 0 ? _t : true,
          inlineRefs: (_u = o.inlineRefs) !== null && _u !== void 0 ? _u : true,
          schemaId: (_v = o.schemaId) !== null && _v !== void 0 ? _v : "$id",
          addUsedSchema: (_w = o.addUsedSchema) !== null && _w !== void 0 ? _w : true,
          validateSchema: (_x = o.validateSchema) !== null && _x !== void 0 ? _x : true,
          validateFormats: (_y = o.validateFormats) !== null && _y !== void 0 ? _y : true,
          unicodeRegExp: (_z = o.unicodeRegExp) !== null && _z !== void 0 ? _z : true,
          int32range: (_0 = o.int32range) !== null && _0 !== void 0 ? _0 : true,
          uriResolver
        };
      }
      var Ajv2 = class {
        constructor(opts = {}) {
          this.schemas = {};
          this.refs = {};
          this.formats = /* @__PURE__ */ Object.create(null);
          this._compilations = /* @__PURE__ */ new Set();
          this._loading = {};
          this._cache = /* @__PURE__ */ new Map();
          opts = this.opts = { ...opts, ...requiredOptions(opts) };
          const { es5, lines } = this.opts.code;
          this.scope = new codegen_2.ValueScope({ scope: {}, prefixes: EXT_SCOPE_NAMES, es5, lines });
          this.logger = getLogger(opts.logger);
          const formatOpt = opts.validateFormats;
          opts.validateFormats = false;
          this.RULES = (0, rules_1.getRules)();
          checkOptions.call(this, removedOptions, opts, "NOT SUPPORTED");
          checkOptions.call(this, deprecatedOptions, opts, "DEPRECATED", "warn");
          this._metaOpts = getMetaSchemaOptions.call(this);
          if (opts.formats)
            addInitialFormats.call(this);
          this._addVocabularies();
          this._addDefaultMetaSchema();
          if (opts.keywords)
            addInitialKeywords.call(this, opts.keywords);
          if (typeof opts.meta == "object")
            this.addMetaSchema(opts.meta);
          addInitialSchemas.call(this);
          opts.validateFormats = formatOpt;
        }
        _addVocabularies() {
          this.addKeyword("$async");
        }
        _addDefaultMetaSchema() {
          const { $data, meta, schemaId } = this.opts;
          let _dataRefSchema = $dataRefSchema;
          if (schemaId === "id") {
            _dataRefSchema = { ...$dataRefSchema };
            _dataRefSchema.id = _dataRefSchema.$id;
            delete _dataRefSchema.$id;
          }
          if (meta && $data)
            this.addMetaSchema(_dataRefSchema, _dataRefSchema[schemaId], false);
        }
        defaultMeta() {
          const { meta, schemaId } = this.opts;
          return this.opts.defaultMeta = typeof meta == "object" ? meta[schemaId] || meta : void 0;
        }
        validate(schemaKeyRef, data) {
          let v;
          if (typeof schemaKeyRef == "string") {
            v = this.getSchema(schemaKeyRef);
            if (!v)
              throw new Error(`no schema with key or ref "${schemaKeyRef}"`);
          } else {
            v = this.compile(schemaKeyRef);
          }
          const valid = v(data);
          if (!("$async" in v))
            this.errors = v.errors;
          return valid;
        }
        compile(schema, _meta) {
          const sch = this._addSchema(schema, _meta);
          return sch.validate || this._compileSchemaEnv(sch);
        }
        compileAsync(schema, meta) {
          if (typeof this.opts.loadSchema != "function") {
            throw new Error("options.loadSchema should be a function");
          }
          const { loadSchema } = this.opts;
          return runCompileAsync.call(this, schema, meta);
          async function runCompileAsync(_schema, _meta) {
            await loadMetaSchema.call(this, _schema.$schema);
            const sch = this._addSchema(_schema, _meta);
            return sch.validate || _compileAsync.call(this, sch);
          }
          async function loadMetaSchema($ref) {
            if ($ref && !this.getSchema($ref)) {
              await runCompileAsync.call(this, { $ref }, true);
            }
          }
          async function _compileAsync(sch) {
            try {
              return this._compileSchemaEnv(sch);
            } catch (e) {
              if (!(e instanceof ref_error_1.default))
                throw e;
              checkLoaded.call(this, e);
              await loadMissingSchema.call(this, e.missingSchema);
              return _compileAsync.call(this, sch);
            }
          }
          function checkLoaded({ missingSchema: ref, missingRef }) {
            if (this.refs[ref]) {
              throw new Error(`AnySchema ${ref} is loaded but ${missingRef} cannot be resolved`);
            }
          }
          async function loadMissingSchema(ref) {
            const _schema = await _loadSchema.call(this, ref);
            if (!this.refs[ref])
              await loadMetaSchema.call(this, _schema.$schema);
            if (!this.refs[ref])
              this.addSchema(_schema, ref, meta);
          }
          async function _loadSchema(ref) {
            const p = this._loading[ref];
            if (p)
              return p;
            try {
              return await (this._loading[ref] = loadSchema(ref));
            } finally {
              delete this._loading[ref];
            }
          }
        }
        // Adds schema to the instance
        addSchema(schema, key2, _meta, _validateSchema = this.opts.validateSchema) {
          if (Array.isArray(schema)) {
            for (const sch of schema)
              this.addSchema(sch, void 0, _meta, _validateSchema);
            return this;
          }
          let id;
          if (typeof schema === "object") {
            const { schemaId } = this.opts;
            id = schema[schemaId];
            if (id !== void 0 && typeof id != "string") {
              throw new Error(`schema ${schemaId} must be string`);
            }
          }
          key2 = (0, resolve_1.normalizeId)(key2 || id);
          this._checkUnique(key2);
          this.schemas[key2] = this._addSchema(schema, _meta, key2, _validateSchema, true);
          return this;
        }
        // Add schema that will be used to validate other schemas
        // options in META_IGNORE_OPTIONS are alway set to false
        addMetaSchema(schema, key2, _validateSchema = this.opts.validateSchema) {
          this.addSchema(schema, key2, true, _validateSchema);
          return this;
        }
        //  Validate schema against its meta-schema
        validateSchema(schema, throwOrLogError) {
          if (typeof schema == "boolean")
            return true;
          let $schema;
          $schema = schema.$schema;
          if ($schema !== void 0 && typeof $schema != "string") {
            throw new Error("$schema must be a string");
          }
          $schema = $schema || this.opts.defaultMeta || this.defaultMeta();
          if (!$schema) {
            this.logger.warn("meta-schema not available");
            this.errors = null;
            return true;
          }
          const valid = this.validate($schema, schema);
          if (!valid && throwOrLogError) {
            const message = "schema is invalid: " + this.errorsText();
            if (this.opts.validateSchema === "log")
              this.logger.error(message);
            else
              throw new Error(message);
          }
          return valid;
        }
        // Get compiled schema by `key` or `ref`.
        // (`key` that was passed to `addSchema` or full schema reference - `schema.$id` or resolved id)
        getSchema(keyRef) {
          let sch;
          while (typeof (sch = getSchEnv.call(this, keyRef)) == "string")
            keyRef = sch;
          if (sch === void 0) {
            const { schemaId } = this.opts;
            const root = new compile_1.SchemaEnv({ schema: {}, schemaId });
            sch = compile_1.resolveSchema.call(this, root, keyRef);
            if (!sch)
              return;
            this.refs[keyRef] = sch;
          }
          return sch.validate || this._compileSchemaEnv(sch);
        }
        // Remove cached schema(s).
        // If no parameter is passed all schemas but meta-schemas are removed.
        // If RegExp is passed all schemas with key/id matching pattern but meta-schemas are removed.
        // Even if schema is referenced by other schemas it still can be removed as other schemas have local references.
        removeSchema(schemaKeyRef) {
          if (schemaKeyRef instanceof RegExp) {
            this._removeAllSchemas(this.schemas, schemaKeyRef);
            this._removeAllSchemas(this.refs, schemaKeyRef);
            return this;
          }
          switch (typeof schemaKeyRef) {
            case "undefined":
              this._removeAllSchemas(this.schemas);
              this._removeAllSchemas(this.refs);
              this._cache.clear();
              return this;
            case "string": {
              const sch = getSchEnv.call(this, schemaKeyRef);
              if (typeof sch == "object")
                this._cache.delete(sch.schema);
              delete this.schemas[schemaKeyRef];
              delete this.refs[schemaKeyRef];
              return this;
            }
            case "object": {
              const cacheKey = schemaKeyRef;
              this._cache.delete(cacheKey);
              let id = schemaKeyRef[this.opts.schemaId];
              if (id) {
                id = (0, resolve_1.normalizeId)(id);
                delete this.schemas[id];
                delete this.refs[id];
              }
              return this;
            }
            default:
              throw new Error("ajv.removeSchema: invalid parameter");
          }
        }
        // add "vocabulary" - a collection of keywords
        addVocabulary(definitions) {
          for (const def of definitions)
            this.addKeyword(def);
          return this;
        }
        addKeyword(kwdOrDef, def) {
          let keyword;
          if (typeof kwdOrDef == "string") {
            keyword = kwdOrDef;
            if (typeof def == "object") {
              this.logger.warn("these parameters are deprecated, see docs for addKeyword");
              def.keyword = keyword;
            }
          } else if (typeof kwdOrDef == "object" && def === void 0) {
            def = kwdOrDef;
            keyword = def.keyword;
            if (Array.isArray(keyword) && !keyword.length) {
              throw new Error("addKeywords: keyword must be string or non-empty array");
            }
          } else {
            throw new Error("invalid addKeywords parameters");
          }
          checkKeyword.call(this, keyword, def);
          if (!def) {
            (0, util_1.eachItem)(keyword, (kwd) => addRule.call(this, kwd));
            return this;
          }
          keywordMetaschema.call(this, def);
          const definition = {
            ...def,
            type: (0, dataType_1.getJSONTypes)(def.type),
            schemaType: (0, dataType_1.getJSONTypes)(def.schemaType)
          };
          (0, util_1.eachItem)(keyword, definition.type.length === 0 ? (k) => addRule.call(this, k, definition) : (k) => definition.type.forEach((t) => addRule.call(this, k, definition, t)));
          return this;
        }
        getKeyword(keyword) {
          const rule = this.RULES.all[keyword];
          return typeof rule == "object" ? rule.definition : !!rule;
        }
        // Remove keyword
        removeKeyword(keyword) {
          const { RULES } = this;
          delete RULES.keywords[keyword];
          delete RULES.all[keyword];
          for (const group of RULES.rules) {
            const i = group.rules.findIndex((rule) => rule.keyword === keyword);
            if (i >= 0)
              group.rules.splice(i, 1);
          }
          return this;
        }
        // Add format
        addFormat(name, format) {
          if (typeof format == "string")
            format = new RegExp(format);
          this.formats[name] = format;
          return this;
        }
        errorsText(errors = this.errors, { separator = ", ", dataVar = "data" } = {}) {
          if (!errors || errors.length === 0)
            return "No errors";
          return errors.map((e) => `${dataVar}${e.instancePath} ${e.message}`).reduce((text, msg) => text + separator + msg);
        }
        $dataMetaSchema(metaSchema, keywordsJsonPointers) {
          const rules = this.RULES.all;
          metaSchema = JSON.parse(JSON.stringify(metaSchema));
          for (const jsonPointer of keywordsJsonPointers) {
            const segments = jsonPointer.split("/").slice(1);
            let keywords = metaSchema;
            for (const seg of segments)
              keywords = keywords[seg];
            for (const key2 in rules) {
              const rule = rules[key2];
              if (typeof rule != "object")
                continue;
              const { $data } = rule.definition;
              const schema = keywords[key2];
              if ($data && schema)
                keywords[key2] = schemaOrData(schema);
            }
          }
          return metaSchema;
        }
        _removeAllSchemas(schemas, regex) {
          for (const keyRef in schemas) {
            const sch = schemas[keyRef];
            if (!regex || regex.test(keyRef)) {
              if (typeof sch == "string") {
                delete schemas[keyRef];
              } else if (sch && !sch.meta) {
                this._cache.delete(sch.schema);
                delete schemas[keyRef];
              }
            }
          }
        }
        _addSchema(schema, meta, baseId, validateSchema = this.opts.validateSchema, addSchema = this.opts.addUsedSchema) {
          let id;
          const { schemaId } = this.opts;
          if (typeof schema == "object") {
            id = schema[schemaId];
          } else {
            if (this.opts.jtd)
              throw new Error("schema must be object");
            else if (typeof schema != "boolean")
              throw new Error("schema must be object or boolean");
          }
          let sch = this._cache.get(schema);
          if (sch !== void 0)
            return sch;
          baseId = (0, resolve_1.normalizeId)(id || baseId);
          const localRefs = resolve_1.getSchemaRefs.call(this, schema, baseId);
          sch = new compile_1.SchemaEnv({ schema, schemaId, meta, baseId, localRefs });
          this._cache.set(sch.schema, sch);
          if (addSchema && !baseId.startsWith("#")) {
            if (baseId)
              this._checkUnique(baseId);
            this.refs[baseId] = sch;
          }
          if (validateSchema)
            this.validateSchema(schema, true);
          return sch;
        }
        _checkUnique(id) {
          if (this.schemas[id] || this.refs[id]) {
            throw new Error(`schema with key or id "${id}" already exists`);
          }
        }
        _compileSchemaEnv(sch) {
          if (sch.meta)
            this._compileMetaSchema(sch);
          else
            compile_1.compileSchema.call(this, sch);
          if (!sch.validate)
            throw new Error("ajv implementation error");
          return sch.validate;
        }
        _compileMetaSchema(sch) {
          const currentOpts = this.opts;
          this.opts = this._metaOpts;
          try {
            compile_1.compileSchema.call(this, sch);
          } finally {
            this.opts = currentOpts;
          }
        }
      };
      Ajv2.ValidationError = validation_error_1.default;
      Ajv2.MissingRefError = ref_error_1.default;
      exports.default = Ajv2;
      function checkOptions(checkOpts, options, msg, log = "error") {
        for (const key2 in checkOpts) {
          const opt = key2;
          if (opt in options)
            this.logger[log](`${msg}: option ${key2}. ${checkOpts[opt]}`);
        }
      }
      function getSchEnv(keyRef) {
        keyRef = (0, resolve_1.normalizeId)(keyRef);
        return this.schemas[keyRef] || this.refs[keyRef];
      }
      function addInitialSchemas() {
        const optsSchemas = this.opts.schemas;
        if (!optsSchemas)
          return;
        if (Array.isArray(optsSchemas))
          this.addSchema(optsSchemas);
        else
          for (const key2 in optsSchemas)
            this.addSchema(optsSchemas[key2], key2);
      }
      function addInitialFormats() {
        for (const name in this.opts.formats) {
          const format = this.opts.formats[name];
          if (format)
            this.addFormat(name, format);
        }
      }
      function addInitialKeywords(defs) {
        if (Array.isArray(defs)) {
          this.addVocabulary(defs);
          return;
        }
        this.logger.warn("keywords option as map is deprecated, pass array");
        for (const keyword in defs) {
          const def = defs[keyword];
          if (!def.keyword)
            def.keyword = keyword;
          this.addKeyword(def);
        }
      }
      function getMetaSchemaOptions() {
        const metaOpts = { ...this.opts };
        for (const opt of META_IGNORE_OPTIONS)
          delete metaOpts[opt];
        return metaOpts;
      }
      var noLogs = { log() {
      }, warn() {
      }, error() {
      } };
      function getLogger(logger) {
        if (logger === false)
          return noLogs;
        if (logger === void 0)
          return console;
        if (logger.log && logger.warn && logger.error)
          return logger;
        throw new Error("logger must implement log, warn and error methods");
      }
      var KEYWORD_NAME = /^[a-z_$][a-z0-9_$:-]*$/i;
      function checkKeyword(keyword, def) {
        const { RULES } = this;
        (0, util_1.eachItem)(keyword, (kwd) => {
          if (RULES.keywords[kwd])
            throw new Error(`Keyword ${kwd} is already defined`);
          if (!KEYWORD_NAME.test(kwd))
            throw new Error(`Keyword ${kwd} has invalid name`);
        });
        if (!def)
          return;
        if (def.$data && !("code" in def || "validate" in def)) {
          throw new Error('$data keyword must have "code" or "validate" function');
        }
      }
      function addRule(keyword, definition, dataType) {
        var _a;
        const post = definition === null || definition === void 0 ? void 0 : definition.post;
        if (dataType && post)
          throw new Error('keyword with "post" flag cannot have "type"');
        const { RULES } = this;
        let ruleGroup = post ? RULES.post : RULES.rules.find(({ type: t }) => t === dataType);
        if (!ruleGroup) {
          ruleGroup = { type: dataType, rules: [] };
          RULES.rules.push(ruleGroup);
        }
        RULES.keywords[keyword] = true;
        if (!definition)
          return;
        const rule = {
          keyword,
          definition: {
            ...definition,
            type: (0, dataType_1.getJSONTypes)(definition.type),
            schemaType: (0, dataType_1.getJSONTypes)(definition.schemaType)
          }
        };
        if (definition.before)
          addBeforeRule.call(this, ruleGroup, rule, definition.before);
        else
          ruleGroup.rules.push(rule);
        RULES.all[keyword] = rule;
        (_a = definition.implements) === null || _a === void 0 ? void 0 : _a.forEach((kwd) => this.addKeyword(kwd));
      }
      function addBeforeRule(ruleGroup, rule, before) {
        const i = ruleGroup.rules.findIndex((_rule) => _rule.keyword === before);
        if (i >= 0) {
          ruleGroup.rules.splice(i, 0, rule);
        } else {
          ruleGroup.rules.push(rule);
          this.logger.warn(`rule ${before} is not defined`);
        }
      }
      function keywordMetaschema(def) {
        let { metaSchema } = def;
        if (metaSchema === void 0)
          return;
        if (def.$data && this.opts.$data)
          metaSchema = schemaOrData(metaSchema);
        def.validateSchema = this.compile(metaSchema, true);
      }
      var $dataRef = {
        $ref: "https://raw.githubusercontent.com/ajv-validator/ajv/master/lib/refs/data.json#"
      };
      function schemaOrData(schema) {
        return { anyOf: [schema, $dataRef] };
      }
    }
  });

  // node_modules/ajv/dist/vocabularies/core/id.js
  var require_id = __commonJS({
    "node_modules/ajv/dist/vocabularies/core/id.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var def = {
        keyword: "id",
        code() {
          throw new Error('NOT SUPPORTED: keyword "id", use "$id" for schema ID');
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/core/ref.js
  var require_ref = __commonJS({
    "node_modules/ajv/dist/vocabularies/core/ref.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.callRef = exports.getValidate = void 0;
      var ref_error_1 = require_ref_error();
      var code_1 = require_code2();
      var codegen_1 = require_codegen();
      var names_1 = require_names();
      var compile_1 = require_compile();
      var util_1 = require_util();
      var def = {
        keyword: "$ref",
        schemaType: "string",
        code(cxt) {
          const { gen, schema: $ref, it } = cxt;
          const { baseId, schemaEnv: env, validateName, opts, self } = it;
          const { root } = env;
          if (($ref === "#" || $ref === "#/") && baseId === root.baseId)
            return callRootRef();
          const schOrEnv = compile_1.resolveRef.call(self, root, baseId, $ref);
          if (schOrEnv === void 0)
            throw new ref_error_1.default(it.opts.uriResolver, baseId, $ref);
          if (schOrEnv instanceof compile_1.SchemaEnv)
            return callValidate(schOrEnv);
          return inlineRefSchema(schOrEnv);
          function callRootRef() {
            if (env === root)
              return callRef(cxt, validateName, env, env.$async);
            const rootName = gen.scopeValue("root", { ref: root });
            return callRef(cxt, (0, codegen_1._)`${rootName}.validate`, root, root.$async);
          }
          function callValidate(sch) {
            const v = getValidate(cxt, sch);
            callRef(cxt, v, sch, sch.$async);
          }
          function inlineRefSchema(sch) {
            const schName = gen.scopeValue("schema", opts.code.source === true ? { ref: sch, code: (0, codegen_1.stringify)(sch) } : { ref: sch });
            const valid = gen.name("valid");
            const schCxt = cxt.subschema({
              schema: sch,
              dataTypes: [],
              schemaPath: codegen_1.nil,
              topSchemaRef: schName,
              errSchemaPath: $ref
            }, valid);
            cxt.mergeEvaluated(schCxt);
            cxt.ok(valid);
          }
        }
      };
      function getValidate(cxt, sch) {
        const { gen } = cxt;
        return sch.validate ? gen.scopeValue("validate", { ref: sch.validate }) : (0, codegen_1._)`${gen.scopeValue("wrapper", { ref: sch })}.validate`;
      }
      exports.getValidate = getValidate;
      function callRef(cxt, v, sch, $async) {
        const { gen, it } = cxt;
        const { allErrors, schemaEnv: env, opts } = it;
        const passCxt = opts.passContext ? names_1.default.this : codegen_1.nil;
        if ($async)
          callAsyncRef();
        else
          callSyncRef();
        function callAsyncRef() {
          if (!env.$async)
            throw new Error("async schema referenced by sync schema");
          const valid = gen.let("valid");
          gen.try(() => {
            gen.code((0, codegen_1._)`await ${(0, code_1.callValidateCode)(cxt, v, passCxt)}`);
            addEvaluatedFrom(v);
            if (!allErrors)
              gen.assign(valid, true);
          }, (e) => {
            gen.if((0, codegen_1._)`!(${e} instanceof ${it.ValidationError})`, () => gen.throw(e));
            addErrorsFrom(e);
            if (!allErrors)
              gen.assign(valid, false);
          });
          cxt.ok(valid);
        }
        function callSyncRef() {
          cxt.result((0, code_1.callValidateCode)(cxt, v, passCxt), () => addEvaluatedFrom(v), () => addErrorsFrom(v));
        }
        function addErrorsFrom(source) {
          const errs = (0, codegen_1._)`${source}.errors`;
          gen.assign(names_1.default.vErrors, (0, codegen_1._)`${names_1.default.vErrors} === null ? ${errs} : ${names_1.default.vErrors}.concat(${errs})`);
          gen.assign(names_1.default.errors, (0, codegen_1._)`${names_1.default.vErrors}.length`);
        }
        function addEvaluatedFrom(source) {
          var _a;
          if (!it.opts.unevaluated)
            return;
          const schEvaluated = (_a = sch === null || sch === void 0 ? void 0 : sch.validate) === null || _a === void 0 ? void 0 : _a.evaluated;
          if (it.props !== true) {
            if (schEvaluated && !schEvaluated.dynamicProps) {
              if (schEvaluated.props !== void 0) {
                it.props = util_1.mergeEvaluated.props(gen, schEvaluated.props, it.props);
              }
            } else {
              const props = gen.var("props", (0, codegen_1._)`${source}.evaluated.props`);
              it.props = util_1.mergeEvaluated.props(gen, props, it.props, codegen_1.Name);
            }
          }
          if (it.items !== true) {
            if (schEvaluated && !schEvaluated.dynamicItems) {
              if (schEvaluated.items !== void 0) {
                it.items = util_1.mergeEvaluated.items(gen, schEvaluated.items, it.items);
              }
            } else {
              const items = gen.var("items", (0, codegen_1._)`${source}.evaluated.items`);
              it.items = util_1.mergeEvaluated.items(gen, items, it.items, codegen_1.Name);
            }
          }
        }
      }
      exports.callRef = callRef;
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/core/index.js
  var require_core3 = __commonJS({
    "node_modules/ajv/dist/vocabularies/core/index.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var id_1 = require_id();
      var ref_1 = require_ref();
      var core = [
        "$schema",
        "$id",
        "$defs",
        "$vocabulary",
        { keyword: "$comment" },
        "definitions",
        id_1.default,
        ref_1.default
      ];
      exports.default = core;
    }
  });

  // node_modules/ajv/dist/vocabularies/validation/limitNumber.js
  var require_limitNumber = __commonJS({
    "node_modules/ajv/dist/vocabularies/validation/limitNumber.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var codegen_1 = require_codegen();
      var ops = codegen_1.operators;
      var KWDs = {
        maximum: { okStr: "<=", ok: ops.LTE, fail: ops.GT },
        minimum: { okStr: ">=", ok: ops.GTE, fail: ops.LT },
        exclusiveMaximum: { okStr: "<", ok: ops.LT, fail: ops.GTE },
        exclusiveMinimum: { okStr: ">", ok: ops.GT, fail: ops.LTE }
      };
      var error = {
        message: ({ keyword, schemaCode }) => (0, codegen_1.str)`must be ${KWDs[keyword].okStr} ${schemaCode}`,
        params: ({ keyword, schemaCode }) => (0, codegen_1._)`{comparison: ${KWDs[keyword].okStr}, limit: ${schemaCode}}`
      };
      var def = {
        keyword: Object.keys(KWDs),
        type: "number",
        schemaType: "number",
        $data: true,
        error,
        code(cxt) {
          const { keyword, data, schemaCode } = cxt;
          cxt.fail$data((0, codegen_1._)`${data} ${KWDs[keyword].fail} ${schemaCode} || isNaN(${data})`);
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/validation/multipleOf.js
  var require_multipleOf = __commonJS({
    "node_modules/ajv/dist/vocabularies/validation/multipleOf.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var codegen_1 = require_codegen();
      var error = {
        message: ({ schemaCode }) => (0, codegen_1.str)`must be multiple of ${schemaCode}`,
        params: ({ schemaCode }) => (0, codegen_1._)`{multipleOf: ${schemaCode}}`
      };
      var def = {
        keyword: "multipleOf",
        type: "number",
        schemaType: "number",
        $data: true,
        error,
        code(cxt) {
          const { gen, data, schemaCode, it } = cxt;
          const prec = it.opts.multipleOfPrecision;
          const res = gen.let("res");
          const invalid = prec ? (0, codegen_1._)`Math.abs(Math.round(${res}) - ${res}) > 1e-${prec}` : (0, codegen_1._)`${res} !== parseInt(${res})`;
          cxt.fail$data((0, codegen_1._)`(${schemaCode} === 0 || (${res} = ${data}/${schemaCode}, ${invalid}))`);
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/runtime/ucs2length.js
  var require_ucs2length = __commonJS({
    "node_modules/ajv/dist/runtime/ucs2length.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      function ucs2length(str) {
        const len = str.length;
        let length = 0;
        let pos = 0;
        let value;
        while (pos < len) {
          length++;
          value = str.charCodeAt(pos++);
          if (value >= 55296 && value <= 56319 && pos < len) {
            value = str.charCodeAt(pos);
            if ((value & 64512) === 56320)
              pos++;
          }
        }
        return length;
      }
      exports.default = ucs2length;
      ucs2length.code = 'require("ajv/dist/runtime/ucs2length").default';
    }
  });

  // node_modules/ajv/dist/vocabularies/validation/limitLength.js
  var require_limitLength = __commonJS({
    "node_modules/ajv/dist/vocabularies/validation/limitLength.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var codegen_1 = require_codegen();
      var util_1 = require_util();
      var ucs2length_1 = require_ucs2length();
      var error = {
        message({ keyword, schemaCode }) {
          const comp = keyword === "maxLength" ? "more" : "fewer";
          return (0, codegen_1.str)`must NOT have ${comp} than ${schemaCode} characters`;
        },
        params: ({ schemaCode }) => (0, codegen_1._)`{limit: ${schemaCode}}`
      };
      var def = {
        keyword: ["maxLength", "minLength"],
        type: "string",
        schemaType: "number",
        $data: true,
        error,
        code(cxt) {
          const { keyword, data, schemaCode, it } = cxt;
          const op = keyword === "maxLength" ? codegen_1.operators.GT : codegen_1.operators.LT;
          const len = it.opts.unicode === false ? (0, codegen_1._)`${data}.length` : (0, codegen_1._)`${(0, util_1.useFunc)(cxt.gen, ucs2length_1.default)}(${data})`;
          cxt.fail$data((0, codegen_1._)`${len} ${op} ${schemaCode}`);
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/validation/pattern.js
  var require_pattern = __commonJS({
    "node_modules/ajv/dist/vocabularies/validation/pattern.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var code_1 = require_code2();
      var util_1 = require_util();
      var codegen_1 = require_codegen();
      var error = {
        message: ({ schemaCode }) => (0, codegen_1.str)`must match pattern "${schemaCode}"`,
        params: ({ schemaCode }) => (0, codegen_1._)`{pattern: ${schemaCode}}`
      };
      var def = {
        keyword: "pattern",
        type: "string",
        schemaType: "string",
        $data: true,
        error,
        code(cxt) {
          const { gen, data, $data, schema, schemaCode, it } = cxt;
          const u = it.opts.unicodeRegExp ? "u" : "";
          if ($data) {
            const { regExp } = it.opts.code;
            const regExpCode = regExp.code === "new RegExp" ? (0, codegen_1._)`new RegExp` : (0, util_1.useFunc)(gen, regExp);
            const valid = gen.let("valid");
            gen.try(() => gen.assign(valid, (0, codegen_1._)`${regExpCode}(${schemaCode}, ${u}).test(${data})`), () => gen.assign(valid, false));
            cxt.fail$data((0, codegen_1._)`!${valid}`);
          } else {
            const regExp = (0, code_1.usePattern)(cxt, schema);
            cxt.fail$data((0, codegen_1._)`!${regExp}.test(${data})`);
          }
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/validation/limitProperties.js
  var require_limitProperties = __commonJS({
    "node_modules/ajv/dist/vocabularies/validation/limitProperties.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var codegen_1 = require_codegen();
      var error = {
        message({ keyword, schemaCode }) {
          const comp = keyword === "maxProperties" ? "more" : "fewer";
          return (0, codegen_1.str)`must NOT have ${comp} than ${schemaCode} properties`;
        },
        params: ({ schemaCode }) => (0, codegen_1._)`{limit: ${schemaCode}}`
      };
      var def = {
        keyword: ["maxProperties", "minProperties"],
        type: "object",
        schemaType: "number",
        $data: true,
        error,
        code(cxt) {
          const { keyword, data, schemaCode } = cxt;
          const op = keyword === "maxProperties" ? codegen_1.operators.GT : codegen_1.operators.LT;
          cxt.fail$data((0, codegen_1._)`Object.keys(${data}).length ${op} ${schemaCode}`);
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/validation/required.js
  var require_required = __commonJS({
    "node_modules/ajv/dist/vocabularies/validation/required.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var code_1 = require_code2();
      var codegen_1 = require_codegen();
      var util_1 = require_util();
      var error = {
        message: ({ params: { missingProperty } }) => (0, codegen_1.str)`must have required property '${missingProperty}'`,
        params: ({ params: { missingProperty } }) => (0, codegen_1._)`{missingProperty: ${missingProperty}}`
      };
      var def = {
        keyword: "required",
        type: "object",
        schemaType: "array",
        $data: true,
        error,
        code(cxt) {
          const { gen, schema, schemaCode, data, $data, it } = cxt;
          const { opts } = it;
          if (!$data && schema.length === 0)
            return;
          const useLoop = schema.length >= opts.loopRequired;
          if (it.allErrors)
            allErrorsMode();
          else
            exitOnErrorMode();
          if (opts.strictRequired) {
            const props = cxt.parentSchema.properties;
            const { definedProperties } = cxt.it;
            for (const requiredKey of schema) {
              if ((props === null || props === void 0 ? void 0 : props[requiredKey]) === void 0 && !definedProperties.has(requiredKey)) {
                const schemaPath = it.schemaEnv.baseId + it.errSchemaPath;
                const msg = `required property "${requiredKey}" is not defined at "${schemaPath}" (strictRequired)`;
                (0, util_1.checkStrictMode)(it, msg, it.opts.strictRequired);
              }
            }
          }
          function allErrorsMode() {
            if (useLoop || $data) {
              cxt.block$data(codegen_1.nil, loopAllRequired);
            } else {
              for (const prop of schema) {
                (0, code_1.checkReportMissingProp)(cxt, prop);
              }
            }
          }
          function exitOnErrorMode() {
            const missing = gen.let("missing");
            if (useLoop || $data) {
              const valid = gen.let("valid", true);
              cxt.block$data(valid, () => loopUntilMissing(missing, valid));
              cxt.ok(valid);
            } else {
              gen.if((0, code_1.checkMissingProp)(cxt, schema, missing));
              (0, code_1.reportMissingProp)(cxt, missing);
              gen.else();
            }
          }
          function loopAllRequired() {
            gen.forOf("prop", schemaCode, (prop) => {
              cxt.setParams({ missingProperty: prop });
              gen.if((0, code_1.noPropertyInData)(gen, data, prop, opts.ownProperties), () => cxt.error());
            });
          }
          function loopUntilMissing(missing, valid) {
            cxt.setParams({ missingProperty: missing });
            gen.forOf(missing, schemaCode, () => {
              gen.assign(valid, (0, code_1.propertyInData)(gen, data, missing, opts.ownProperties));
              gen.if((0, codegen_1.not)(valid), () => {
                cxt.error();
                gen.break();
              });
            }, codegen_1.nil);
          }
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/validation/limitItems.js
  var require_limitItems = __commonJS({
    "node_modules/ajv/dist/vocabularies/validation/limitItems.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var codegen_1 = require_codegen();
      var error = {
        message({ keyword, schemaCode }) {
          const comp = keyword === "maxItems" ? "more" : "fewer";
          return (0, codegen_1.str)`must NOT have ${comp} than ${schemaCode} items`;
        },
        params: ({ schemaCode }) => (0, codegen_1._)`{limit: ${schemaCode}}`
      };
      var def = {
        keyword: ["maxItems", "minItems"],
        type: "array",
        schemaType: "number",
        $data: true,
        error,
        code(cxt) {
          const { keyword, data, schemaCode } = cxt;
          const op = keyword === "maxItems" ? codegen_1.operators.GT : codegen_1.operators.LT;
          cxt.fail$data((0, codegen_1._)`${data}.length ${op} ${schemaCode}`);
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/runtime/equal.js
  var require_equal = __commonJS({
    "node_modules/ajv/dist/runtime/equal.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var equal = require_fast_deep_equal();
      equal.code = 'require("ajv/dist/runtime/equal").default';
      exports.default = equal;
    }
  });

  // node_modules/ajv/dist/vocabularies/validation/uniqueItems.js
  var require_uniqueItems = __commonJS({
    "node_modules/ajv/dist/vocabularies/validation/uniqueItems.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var dataType_1 = require_dataType();
      var codegen_1 = require_codegen();
      var util_1 = require_util();
      var equal_1 = require_equal();
      var error = {
        message: ({ params: { i, j } }) => (0, codegen_1.str)`must NOT have duplicate items (items ## ${j} and ${i} are identical)`,
        params: ({ params: { i, j } }) => (0, codegen_1._)`{i: ${i}, j: ${j}}`
      };
      var def = {
        keyword: "uniqueItems",
        type: "array",
        schemaType: "boolean",
        $data: true,
        error,
        code(cxt) {
          const { gen, data, $data, schema, parentSchema, schemaCode, it } = cxt;
          if (!$data && !schema)
            return;
          const valid = gen.let("valid");
          const itemTypes = parentSchema.items ? (0, dataType_1.getSchemaTypes)(parentSchema.items) : [];
          cxt.block$data(valid, validateUniqueItems, (0, codegen_1._)`${schemaCode} === false`);
          cxt.ok(valid);
          function validateUniqueItems() {
            const i = gen.let("i", (0, codegen_1._)`${data}.length`);
            const j = gen.let("j");
            cxt.setParams({ i, j });
            gen.assign(valid, true);
            gen.if((0, codegen_1._)`${i} > 1`, () => (canOptimize() ? loopN : loopN2)(i, j));
          }
          function canOptimize() {
            return itemTypes.length > 0 && !itemTypes.some((t) => t === "object" || t === "array");
          }
          function loopN(i, j) {
            const item = gen.name("item");
            const wrongType = (0, dataType_1.checkDataTypes)(itemTypes, item, it.opts.strictNumbers, dataType_1.DataType.Wrong);
            const indices = gen.const("indices", (0, codegen_1._)`{}`);
            gen.for((0, codegen_1._)`;${i}--;`, () => {
              gen.let(item, (0, codegen_1._)`${data}[${i}]`);
              gen.if(wrongType, (0, codegen_1._)`continue`);
              if (itemTypes.length > 1)
                gen.if((0, codegen_1._)`typeof ${item} == "string"`, (0, codegen_1._)`${item} += "_"`);
              gen.if((0, codegen_1._)`typeof ${indices}[${item}] == "number"`, () => {
                gen.assign(j, (0, codegen_1._)`${indices}[${item}]`);
                cxt.error();
                gen.assign(valid, false).break();
              }).code((0, codegen_1._)`${indices}[${item}] = ${i}`);
            });
          }
          function loopN2(i, j) {
            const eql = (0, util_1.useFunc)(gen, equal_1.default);
            const outer = gen.name("outer");
            gen.label(outer).for((0, codegen_1._)`;${i}--;`, () => gen.for((0, codegen_1._)`${j} = ${i}; ${j}--;`, () => gen.if((0, codegen_1._)`${eql}(${data}[${i}], ${data}[${j}])`, () => {
              cxt.error();
              gen.assign(valid, false).break(outer);
            })));
          }
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/validation/const.js
  var require_const = __commonJS({
    "node_modules/ajv/dist/vocabularies/validation/const.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var codegen_1 = require_codegen();
      var util_1 = require_util();
      var equal_1 = require_equal();
      var error = {
        message: "must be equal to constant",
        params: ({ schemaCode }) => (0, codegen_1._)`{allowedValue: ${schemaCode}}`
      };
      var def = {
        keyword: "const",
        $data: true,
        error,
        code(cxt) {
          const { gen, data, $data, schemaCode, schema } = cxt;
          if ($data || schema && typeof schema == "object") {
            cxt.fail$data((0, codegen_1._)`!${(0, util_1.useFunc)(gen, equal_1.default)}(${data}, ${schemaCode})`);
          } else {
            cxt.fail((0, codegen_1._)`${schema} !== ${data}`);
          }
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/validation/enum.js
  var require_enum = __commonJS({
    "node_modules/ajv/dist/vocabularies/validation/enum.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var codegen_1 = require_codegen();
      var util_1 = require_util();
      var equal_1 = require_equal();
      var error = {
        message: "must be equal to one of the allowed values",
        params: ({ schemaCode }) => (0, codegen_1._)`{allowedValues: ${schemaCode}}`
      };
      var def = {
        keyword: "enum",
        schemaType: "array",
        $data: true,
        error,
        code(cxt) {
          const { gen, data, $data, schema, schemaCode, it } = cxt;
          if (!$data && schema.length === 0)
            throw new Error("enum must have non-empty array");
          const useLoop = schema.length >= it.opts.loopEnum;
          let eql;
          const getEql = () => eql !== null && eql !== void 0 ? eql : eql = (0, util_1.useFunc)(gen, equal_1.default);
          let valid;
          if (useLoop || $data) {
            valid = gen.let("valid");
            cxt.block$data(valid, loopEnum);
          } else {
            if (!Array.isArray(schema))
              throw new Error("ajv implementation error");
            const vSchema = gen.const("vSchema", schemaCode);
            valid = (0, codegen_1.or)(...schema.map((_x, i) => equalCode(vSchema, i)));
          }
          cxt.pass(valid);
          function loopEnum() {
            gen.assign(valid, false);
            gen.forOf("v", schemaCode, (v) => gen.if((0, codegen_1._)`${getEql()}(${data}, ${v})`, () => gen.assign(valid, true).break()));
          }
          function equalCode(vSchema, i) {
            const sch = schema[i];
            return typeof sch === "object" && sch !== null ? (0, codegen_1._)`${getEql()}(${data}, ${vSchema}[${i}])` : (0, codegen_1._)`${data} === ${sch}`;
          }
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/validation/index.js
  var require_validation = __commonJS({
    "node_modules/ajv/dist/vocabularies/validation/index.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var limitNumber_1 = require_limitNumber();
      var multipleOf_1 = require_multipleOf();
      var limitLength_1 = require_limitLength();
      var pattern_1 = require_pattern();
      var limitProperties_1 = require_limitProperties();
      var required_1 = require_required();
      var limitItems_1 = require_limitItems();
      var uniqueItems_1 = require_uniqueItems();
      var const_1 = require_const();
      var enum_1 = require_enum();
      var validation = [
        // number
        limitNumber_1.default,
        multipleOf_1.default,
        // string
        limitLength_1.default,
        pattern_1.default,
        // object
        limitProperties_1.default,
        required_1.default,
        // array
        limitItems_1.default,
        uniqueItems_1.default,
        // any
        { keyword: "type", schemaType: ["string", "array"] },
        { keyword: "nullable", schemaType: "boolean" },
        const_1.default,
        enum_1.default
      ];
      exports.default = validation;
    }
  });

  // node_modules/ajv/dist/vocabularies/applicator/additionalItems.js
  var require_additionalItems = __commonJS({
    "node_modules/ajv/dist/vocabularies/applicator/additionalItems.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.validateAdditionalItems = void 0;
      var codegen_1 = require_codegen();
      var util_1 = require_util();
      var error = {
        message: ({ params: { len } }) => (0, codegen_1.str)`must NOT have more than ${len} items`,
        params: ({ params: { len } }) => (0, codegen_1._)`{limit: ${len}}`
      };
      var def = {
        keyword: "additionalItems",
        type: "array",
        schemaType: ["boolean", "object"],
        before: "uniqueItems",
        error,
        code(cxt) {
          const { parentSchema, it } = cxt;
          const { items } = parentSchema;
          if (!Array.isArray(items)) {
            (0, util_1.checkStrictMode)(it, '"additionalItems" is ignored when "items" is not an array of schemas');
            return;
          }
          validateAdditionalItems(cxt, items);
        }
      };
      function validateAdditionalItems(cxt, items) {
        const { gen, schema, data, keyword, it } = cxt;
        it.items = true;
        const len = gen.const("len", (0, codegen_1._)`${data}.length`);
        if (schema === false) {
          cxt.setParams({ len: items.length });
          cxt.pass((0, codegen_1._)`${len} <= ${items.length}`);
        } else if (typeof schema == "object" && !(0, util_1.alwaysValidSchema)(it, schema)) {
          const valid = gen.var("valid", (0, codegen_1._)`${len} <= ${items.length}`);
          gen.if((0, codegen_1.not)(valid), () => validateItems(valid));
          cxt.ok(valid);
        }
        function validateItems(valid) {
          gen.forRange("i", items.length, len, (i) => {
            cxt.subschema({ keyword, dataProp: i, dataPropType: util_1.Type.Num }, valid);
            if (!it.allErrors)
              gen.if((0, codegen_1.not)(valid), () => gen.break());
          });
        }
      }
      exports.validateAdditionalItems = validateAdditionalItems;
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/applicator/items.js
  var require_items = __commonJS({
    "node_modules/ajv/dist/vocabularies/applicator/items.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.validateTuple = void 0;
      var codegen_1 = require_codegen();
      var util_1 = require_util();
      var code_1 = require_code2();
      var def = {
        keyword: "items",
        type: "array",
        schemaType: ["object", "array", "boolean"],
        before: "uniqueItems",
        code(cxt) {
          const { schema, it } = cxt;
          if (Array.isArray(schema))
            return validateTuple(cxt, "additionalItems", schema);
          it.items = true;
          if ((0, util_1.alwaysValidSchema)(it, schema))
            return;
          cxt.ok((0, code_1.validateArray)(cxt));
        }
      };
      function validateTuple(cxt, extraItems, schArr = cxt.schema) {
        const { gen, parentSchema, data, keyword, it } = cxt;
        checkStrictTuple(parentSchema);
        if (it.opts.unevaluated && schArr.length && it.items !== true) {
          it.items = util_1.mergeEvaluated.items(gen, schArr.length, it.items);
        }
        const valid = gen.name("valid");
        const len = gen.const("len", (0, codegen_1._)`${data}.length`);
        schArr.forEach((sch, i) => {
          if ((0, util_1.alwaysValidSchema)(it, sch))
            return;
          gen.if((0, codegen_1._)`${len} > ${i}`, () => cxt.subschema({
            keyword,
            schemaProp: i,
            dataProp: i
          }, valid));
          cxt.ok(valid);
        });
        function checkStrictTuple(sch) {
          const { opts, errSchemaPath } = it;
          const l = schArr.length;
          const fullTuple = l === sch.minItems && (l === sch.maxItems || sch[extraItems] === false);
          if (opts.strictTuples && !fullTuple) {
            const msg = `"${keyword}" is ${l}-tuple, but minItems or maxItems/${extraItems} are not specified or different at path "${errSchemaPath}"`;
            (0, util_1.checkStrictMode)(it, msg, opts.strictTuples);
          }
        }
      }
      exports.validateTuple = validateTuple;
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/applicator/prefixItems.js
  var require_prefixItems = __commonJS({
    "node_modules/ajv/dist/vocabularies/applicator/prefixItems.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var items_1 = require_items();
      var def = {
        keyword: "prefixItems",
        type: "array",
        schemaType: ["array"],
        before: "uniqueItems",
        code: (cxt) => (0, items_1.validateTuple)(cxt, "items")
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/applicator/items2020.js
  var require_items2020 = __commonJS({
    "node_modules/ajv/dist/vocabularies/applicator/items2020.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var codegen_1 = require_codegen();
      var util_1 = require_util();
      var code_1 = require_code2();
      var additionalItems_1 = require_additionalItems();
      var error = {
        message: ({ params: { len } }) => (0, codegen_1.str)`must NOT have more than ${len} items`,
        params: ({ params: { len } }) => (0, codegen_1._)`{limit: ${len}}`
      };
      var def = {
        keyword: "items",
        type: "array",
        schemaType: ["object", "boolean"],
        before: "uniqueItems",
        error,
        code(cxt) {
          const { schema, parentSchema, it } = cxt;
          const { prefixItems } = parentSchema;
          it.items = true;
          if ((0, util_1.alwaysValidSchema)(it, schema))
            return;
          if (prefixItems)
            (0, additionalItems_1.validateAdditionalItems)(cxt, prefixItems);
          else
            cxt.ok((0, code_1.validateArray)(cxt));
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/applicator/contains.js
  var require_contains = __commonJS({
    "node_modules/ajv/dist/vocabularies/applicator/contains.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var codegen_1 = require_codegen();
      var util_1 = require_util();
      var error = {
        message: ({ params: { min, max } }) => max === void 0 ? (0, codegen_1.str)`must contain at least ${min} valid item(s)` : (0, codegen_1.str)`must contain at least ${min} and no more than ${max} valid item(s)`,
        params: ({ params: { min, max } }) => max === void 0 ? (0, codegen_1._)`{minContains: ${min}}` : (0, codegen_1._)`{minContains: ${min}, maxContains: ${max}}`
      };
      var def = {
        keyword: "contains",
        type: "array",
        schemaType: ["object", "boolean"],
        before: "uniqueItems",
        trackErrors: true,
        error,
        code(cxt) {
          const { gen, schema, parentSchema, data, it } = cxt;
          let min;
          let max;
          const { minContains, maxContains } = parentSchema;
          if (it.opts.next) {
            min = minContains === void 0 ? 1 : minContains;
            max = maxContains;
          } else {
            min = 1;
          }
          const len = gen.const("len", (0, codegen_1._)`${data}.length`);
          cxt.setParams({ min, max });
          if (max === void 0 && min === 0) {
            (0, util_1.checkStrictMode)(it, `"minContains" == 0 without "maxContains": "contains" keyword ignored`);
            return;
          }
          if (max !== void 0 && min > max) {
            (0, util_1.checkStrictMode)(it, `"minContains" > "maxContains" is always invalid`);
            cxt.fail();
            return;
          }
          if ((0, util_1.alwaysValidSchema)(it, schema)) {
            let cond = (0, codegen_1._)`${len} >= ${min}`;
            if (max !== void 0)
              cond = (0, codegen_1._)`${cond} && ${len} <= ${max}`;
            cxt.pass(cond);
            return;
          }
          it.items = true;
          const valid = gen.name("valid");
          if (max === void 0 && min === 1) {
            validateItems(valid, () => gen.if(valid, () => gen.break()));
          } else if (min === 0) {
            gen.let(valid, true);
            if (max !== void 0)
              gen.if((0, codegen_1._)`${data}.length > 0`, validateItemsWithCount);
          } else {
            gen.let(valid, false);
            validateItemsWithCount();
          }
          cxt.result(valid, () => cxt.reset());
          function validateItemsWithCount() {
            const schValid = gen.name("_valid");
            const count = gen.let("count", 0);
            validateItems(schValid, () => gen.if(schValid, () => checkLimits(count)));
          }
          function validateItems(_valid, block) {
            gen.forRange("i", 0, len, (i) => {
              cxt.subschema({
                keyword: "contains",
                dataProp: i,
                dataPropType: util_1.Type.Num,
                compositeRule: true
              }, _valid);
              block();
            });
          }
          function checkLimits(count) {
            gen.code((0, codegen_1._)`${count}++`);
            if (max === void 0) {
              gen.if((0, codegen_1._)`${count} >= ${min}`, () => gen.assign(valid, true).break());
            } else {
              gen.if((0, codegen_1._)`${count} > ${max}`, () => gen.assign(valid, false).break());
              if (min === 1)
                gen.assign(valid, true);
              else
                gen.if((0, codegen_1._)`${count} >= ${min}`, () => gen.assign(valid, true));
            }
          }
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/applicator/dependencies.js
  var require_dependencies = __commonJS({
    "node_modules/ajv/dist/vocabularies/applicator/dependencies.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.validateSchemaDeps = exports.validatePropertyDeps = exports.error = void 0;
      var codegen_1 = require_codegen();
      var util_1 = require_util();
      var code_1 = require_code2();
      exports.error = {
        message: ({ params: { property, depsCount, deps } }) => {
          const property_ies = depsCount === 1 ? "property" : "properties";
          return (0, codegen_1.str)`must have ${property_ies} ${deps} when property ${property} is present`;
        },
        params: ({ params: { property, depsCount, deps, missingProperty } }) => (0, codegen_1._)`{property: ${property},
    missingProperty: ${missingProperty},
    depsCount: ${depsCount},
    deps: ${deps}}`
        // TODO change to reference
      };
      var def = {
        keyword: "dependencies",
        type: "object",
        schemaType: "object",
        error: exports.error,
        code(cxt) {
          const [propDeps, schDeps] = splitDependencies(cxt);
          validatePropertyDeps(cxt, propDeps);
          validateSchemaDeps(cxt, schDeps);
        }
      };
      function splitDependencies({ schema }) {
        const propertyDeps = {};
        const schemaDeps = {};
        for (const key2 in schema) {
          if (key2 === "__proto__")
            continue;
          const deps = Array.isArray(schema[key2]) ? propertyDeps : schemaDeps;
          deps[key2] = schema[key2];
        }
        return [propertyDeps, schemaDeps];
      }
      function validatePropertyDeps(cxt, propertyDeps = cxt.schema) {
        const { gen, data, it } = cxt;
        if (Object.keys(propertyDeps).length === 0)
          return;
        const missing = gen.let("missing");
        for (const prop in propertyDeps) {
          const deps = propertyDeps[prop];
          if (deps.length === 0)
            continue;
          const hasProperty = (0, code_1.propertyInData)(gen, data, prop, it.opts.ownProperties);
          cxt.setParams({
            property: prop,
            depsCount: deps.length,
            deps: deps.join(", ")
          });
          if (it.allErrors) {
            gen.if(hasProperty, () => {
              for (const depProp of deps) {
                (0, code_1.checkReportMissingProp)(cxt, depProp);
              }
            });
          } else {
            gen.if((0, codegen_1._)`${hasProperty} && (${(0, code_1.checkMissingProp)(cxt, deps, missing)})`);
            (0, code_1.reportMissingProp)(cxt, missing);
            gen.else();
          }
        }
      }
      exports.validatePropertyDeps = validatePropertyDeps;
      function validateSchemaDeps(cxt, schemaDeps = cxt.schema) {
        const { gen, data, keyword, it } = cxt;
        const valid = gen.name("valid");
        for (const prop in schemaDeps) {
          if ((0, util_1.alwaysValidSchema)(it, schemaDeps[prop]))
            continue;
          gen.if(
            (0, code_1.propertyInData)(gen, data, prop, it.opts.ownProperties),
            () => {
              const schCxt = cxt.subschema({ keyword, schemaProp: prop }, valid);
              cxt.mergeValidEvaluated(schCxt, valid);
            },
            () => gen.var(valid, true)
            // TODO var
          );
          cxt.ok(valid);
        }
      }
      exports.validateSchemaDeps = validateSchemaDeps;
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/applicator/propertyNames.js
  var require_propertyNames = __commonJS({
    "node_modules/ajv/dist/vocabularies/applicator/propertyNames.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var codegen_1 = require_codegen();
      var util_1 = require_util();
      var error = {
        message: "property name must be valid",
        params: ({ params }) => (0, codegen_1._)`{propertyName: ${params.propertyName}}`
      };
      var def = {
        keyword: "propertyNames",
        type: "object",
        schemaType: ["object", "boolean"],
        error,
        code(cxt) {
          const { gen, schema, data, it } = cxt;
          if ((0, util_1.alwaysValidSchema)(it, schema))
            return;
          const valid = gen.name("valid");
          gen.forIn("key", data, (key2) => {
            cxt.setParams({ propertyName: key2 });
            cxt.subschema({
              keyword: "propertyNames",
              data: key2,
              dataTypes: ["string"],
              propertyName: key2,
              compositeRule: true
            }, valid);
            gen.if((0, codegen_1.not)(valid), () => {
              cxt.error(true);
              if (!it.allErrors)
                gen.break();
            });
          });
          cxt.ok(valid);
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/applicator/additionalProperties.js
  var require_additionalProperties = __commonJS({
    "node_modules/ajv/dist/vocabularies/applicator/additionalProperties.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var code_1 = require_code2();
      var codegen_1 = require_codegen();
      var names_1 = require_names();
      var util_1 = require_util();
      var error = {
        message: "must NOT have additional properties",
        params: ({ params }) => (0, codegen_1._)`{additionalProperty: ${params.additionalProperty}}`
      };
      var def = {
        keyword: "additionalProperties",
        type: ["object"],
        schemaType: ["boolean", "object"],
        allowUndefined: true,
        trackErrors: true,
        error,
        code(cxt) {
          const { gen, schema, parentSchema, data, errsCount, it } = cxt;
          if (!errsCount)
            throw new Error("ajv implementation error");
          const { allErrors, opts } = it;
          it.props = true;
          if (opts.removeAdditional !== "all" && (0, util_1.alwaysValidSchema)(it, schema))
            return;
          const props = (0, code_1.allSchemaProperties)(parentSchema.properties);
          const patProps = (0, code_1.allSchemaProperties)(parentSchema.patternProperties);
          checkAdditionalProperties();
          cxt.ok((0, codegen_1._)`${errsCount} === ${names_1.default.errors}`);
          function checkAdditionalProperties() {
            gen.forIn("key", data, (key2) => {
              if (!props.length && !patProps.length)
                additionalPropertyCode(key2);
              else
                gen.if(isAdditional(key2), () => additionalPropertyCode(key2));
            });
          }
          function isAdditional(key2) {
            let definedProp;
            if (props.length > 8) {
              const propsSchema = (0, util_1.schemaRefOrVal)(it, parentSchema.properties, "properties");
              definedProp = (0, code_1.isOwnProperty)(gen, propsSchema, key2);
            } else if (props.length) {
              definedProp = (0, codegen_1.or)(...props.map((p) => (0, codegen_1._)`${key2} === ${p}`));
            } else {
              definedProp = codegen_1.nil;
            }
            if (patProps.length) {
              definedProp = (0, codegen_1.or)(definedProp, ...patProps.map((p) => (0, codegen_1._)`${(0, code_1.usePattern)(cxt, p)}.test(${key2})`));
            }
            return (0, codegen_1.not)(definedProp);
          }
          function deleteAdditional(key2) {
            gen.code((0, codegen_1._)`delete ${data}[${key2}]`);
          }
          function additionalPropertyCode(key2) {
            if (opts.removeAdditional === "all" || opts.removeAdditional && schema === false) {
              deleteAdditional(key2);
              return;
            }
            if (schema === false) {
              cxt.setParams({ additionalProperty: key2 });
              cxt.error();
              if (!allErrors)
                gen.break();
              return;
            }
            if (typeof schema == "object" && !(0, util_1.alwaysValidSchema)(it, schema)) {
              const valid = gen.name("valid");
              if (opts.removeAdditional === "failing") {
                applyAdditionalSchema(key2, valid, false);
                gen.if((0, codegen_1.not)(valid), () => {
                  cxt.reset();
                  deleteAdditional(key2);
                });
              } else {
                applyAdditionalSchema(key2, valid);
                if (!allErrors)
                  gen.if((0, codegen_1.not)(valid), () => gen.break());
              }
            }
          }
          function applyAdditionalSchema(key2, valid, errors) {
            const subschema = {
              keyword: "additionalProperties",
              dataProp: key2,
              dataPropType: util_1.Type.Str
            };
            if (errors === false) {
              Object.assign(subschema, {
                compositeRule: true,
                createErrors: false,
                allErrors: false
              });
            }
            cxt.subschema(subschema, valid);
          }
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/applicator/properties.js
  var require_properties = __commonJS({
    "node_modules/ajv/dist/vocabularies/applicator/properties.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var validate_1 = require_validate();
      var code_1 = require_code2();
      var util_1 = require_util();
      var additionalProperties_1 = require_additionalProperties();
      var def = {
        keyword: "properties",
        type: "object",
        schemaType: "object",
        code(cxt) {
          const { gen, schema, parentSchema, data, it } = cxt;
          if (it.opts.removeAdditional === "all" && parentSchema.additionalProperties === void 0) {
            additionalProperties_1.default.code(new validate_1.KeywordCxt(it, additionalProperties_1.default, "additionalProperties"));
          }
          const allProps = (0, code_1.allSchemaProperties)(schema);
          for (const prop of allProps) {
            it.definedProperties.add(prop);
          }
          if (it.opts.unevaluated && allProps.length && it.props !== true) {
            it.props = util_1.mergeEvaluated.props(gen, (0, util_1.toHash)(allProps), it.props);
          }
          const properties = allProps.filter((p) => !(0, util_1.alwaysValidSchema)(it, schema[p]));
          if (properties.length === 0)
            return;
          const valid = gen.name("valid");
          for (const prop of properties) {
            if (hasDefault(prop)) {
              applyPropertySchema(prop);
            } else {
              gen.if((0, code_1.propertyInData)(gen, data, prop, it.opts.ownProperties));
              applyPropertySchema(prop);
              if (!it.allErrors)
                gen.else().var(valid, true);
              gen.endIf();
            }
            cxt.it.definedProperties.add(prop);
            cxt.ok(valid);
          }
          function hasDefault(prop) {
            return it.opts.useDefaults && !it.compositeRule && schema[prop].default !== void 0;
          }
          function applyPropertySchema(prop) {
            cxt.subschema({
              keyword: "properties",
              schemaProp: prop,
              dataProp: prop
            }, valid);
          }
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/applicator/patternProperties.js
  var require_patternProperties = __commonJS({
    "node_modules/ajv/dist/vocabularies/applicator/patternProperties.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var code_1 = require_code2();
      var codegen_1 = require_codegen();
      var util_1 = require_util();
      var util_2 = require_util();
      var def = {
        keyword: "patternProperties",
        type: "object",
        schemaType: "object",
        code(cxt) {
          const { gen, schema, data, parentSchema, it } = cxt;
          const { opts } = it;
          const patterns = (0, code_1.allSchemaProperties)(schema);
          const alwaysValidPatterns = patterns.filter((p) => (0, util_1.alwaysValidSchema)(it, schema[p]));
          if (patterns.length === 0 || alwaysValidPatterns.length === patterns.length && (!it.opts.unevaluated || it.props === true)) {
            return;
          }
          const checkProperties = opts.strictSchema && !opts.allowMatchingProperties && parentSchema.properties;
          const valid = gen.name("valid");
          if (it.props !== true && !(it.props instanceof codegen_1.Name)) {
            it.props = (0, util_2.evaluatedPropsToName)(gen, it.props);
          }
          const { props } = it;
          validatePatternProperties();
          function validatePatternProperties() {
            for (const pat of patterns) {
              if (checkProperties)
                checkMatchingProperties(pat);
              if (it.allErrors) {
                validateProperties(pat);
              } else {
                gen.var(valid, true);
                validateProperties(pat);
                gen.if(valid);
              }
            }
          }
          function checkMatchingProperties(pat) {
            for (const prop in checkProperties) {
              if (new RegExp(pat).test(prop)) {
                (0, util_1.checkStrictMode)(it, `property ${prop} matches pattern ${pat} (use allowMatchingProperties)`);
              }
            }
          }
          function validateProperties(pat) {
            gen.forIn("key", data, (key2) => {
              gen.if((0, codegen_1._)`${(0, code_1.usePattern)(cxt, pat)}.test(${key2})`, () => {
                const alwaysValid = alwaysValidPatterns.includes(pat);
                if (!alwaysValid) {
                  cxt.subschema({
                    keyword: "patternProperties",
                    schemaProp: pat,
                    dataProp: key2,
                    dataPropType: util_2.Type.Str
                  }, valid);
                }
                if (it.opts.unevaluated && props !== true) {
                  gen.assign((0, codegen_1._)`${props}[${key2}]`, true);
                } else if (!alwaysValid && !it.allErrors) {
                  gen.if((0, codegen_1.not)(valid), () => gen.break());
                }
              });
            });
          }
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/applicator/not.js
  var require_not = __commonJS({
    "node_modules/ajv/dist/vocabularies/applicator/not.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var util_1 = require_util();
      var def = {
        keyword: "not",
        schemaType: ["object", "boolean"],
        trackErrors: true,
        code(cxt) {
          const { gen, schema, it } = cxt;
          if ((0, util_1.alwaysValidSchema)(it, schema)) {
            cxt.fail();
            return;
          }
          const valid = gen.name("valid");
          cxt.subschema({
            keyword: "not",
            compositeRule: true,
            createErrors: false,
            allErrors: false
          }, valid);
          cxt.failResult(valid, () => cxt.reset(), () => cxt.error());
        },
        error: { message: "must NOT be valid" }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/applicator/anyOf.js
  var require_anyOf = __commonJS({
    "node_modules/ajv/dist/vocabularies/applicator/anyOf.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var code_1 = require_code2();
      var def = {
        keyword: "anyOf",
        schemaType: "array",
        trackErrors: true,
        code: code_1.validateUnion,
        error: { message: "must match a schema in anyOf" }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/applicator/oneOf.js
  var require_oneOf = __commonJS({
    "node_modules/ajv/dist/vocabularies/applicator/oneOf.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var codegen_1 = require_codegen();
      var util_1 = require_util();
      var error = {
        message: "must match exactly one schema in oneOf",
        params: ({ params }) => (0, codegen_1._)`{passingSchemas: ${params.passing}}`
      };
      var def = {
        keyword: "oneOf",
        schemaType: "array",
        trackErrors: true,
        error,
        code(cxt) {
          const { gen, schema, parentSchema, it } = cxt;
          if (!Array.isArray(schema))
            throw new Error("ajv implementation error");
          if (it.opts.discriminator && parentSchema.discriminator)
            return;
          const schArr = schema;
          const valid = gen.let("valid", false);
          const passing = gen.let("passing", null);
          const schValid = gen.name("_valid");
          cxt.setParams({ passing });
          gen.block(validateOneOf);
          cxt.result(valid, () => cxt.reset(), () => cxt.error(true));
          function validateOneOf() {
            schArr.forEach((sch, i) => {
              let schCxt;
              if ((0, util_1.alwaysValidSchema)(it, sch)) {
                gen.var(schValid, true);
              } else {
                schCxt = cxt.subschema({
                  keyword: "oneOf",
                  schemaProp: i,
                  compositeRule: true
                }, schValid);
              }
              if (i > 0) {
                gen.if((0, codegen_1._)`${schValid} && ${valid}`).assign(valid, false).assign(passing, (0, codegen_1._)`[${passing}, ${i}]`).else();
              }
              gen.if(schValid, () => {
                gen.assign(valid, true);
                gen.assign(passing, i);
                if (schCxt)
                  cxt.mergeEvaluated(schCxt, codegen_1.Name);
              });
            });
          }
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/applicator/allOf.js
  var require_allOf = __commonJS({
    "node_modules/ajv/dist/vocabularies/applicator/allOf.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var util_1 = require_util();
      var def = {
        keyword: "allOf",
        schemaType: "array",
        code(cxt) {
          const { gen, schema, it } = cxt;
          if (!Array.isArray(schema))
            throw new Error("ajv implementation error");
          const valid = gen.name("valid");
          schema.forEach((sch, i) => {
            if ((0, util_1.alwaysValidSchema)(it, sch))
              return;
            const schCxt = cxt.subschema({ keyword: "allOf", schemaProp: i }, valid);
            cxt.ok(valid);
            cxt.mergeEvaluated(schCxt);
          });
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/applicator/if.js
  var require_if = __commonJS({
    "node_modules/ajv/dist/vocabularies/applicator/if.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var codegen_1 = require_codegen();
      var util_1 = require_util();
      var error = {
        message: ({ params }) => (0, codegen_1.str)`must match "${params.ifClause}" schema`,
        params: ({ params }) => (0, codegen_1._)`{failingKeyword: ${params.ifClause}}`
      };
      var def = {
        keyword: "if",
        schemaType: ["object", "boolean"],
        trackErrors: true,
        error,
        code(cxt) {
          const { gen, parentSchema, it } = cxt;
          if (parentSchema.then === void 0 && parentSchema.else === void 0) {
            (0, util_1.checkStrictMode)(it, '"if" without "then" and "else" is ignored');
          }
          const hasThen = hasSchema(it, "then");
          const hasElse = hasSchema(it, "else");
          if (!hasThen && !hasElse)
            return;
          const valid = gen.let("valid", true);
          const schValid = gen.name("_valid");
          validateIf();
          cxt.reset();
          if (hasThen && hasElse) {
            const ifClause = gen.let("ifClause");
            cxt.setParams({ ifClause });
            gen.if(schValid, validateClause("then", ifClause), validateClause("else", ifClause));
          } else if (hasThen) {
            gen.if(schValid, validateClause("then"));
          } else {
            gen.if((0, codegen_1.not)(schValid), validateClause("else"));
          }
          cxt.pass(valid, () => cxt.error(true));
          function validateIf() {
            const schCxt = cxt.subschema({
              keyword: "if",
              compositeRule: true,
              createErrors: false,
              allErrors: false
            }, schValid);
            cxt.mergeEvaluated(schCxt);
          }
          function validateClause(keyword, ifClause) {
            return () => {
              const schCxt = cxt.subschema({ keyword }, schValid);
              gen.assign(valid, schValid);
              cxt.mergeValidEvaluated(schCxt, valid);
              if (ifClause)
                gen.assign(ifClause, (0, codegen_1._)`${keyword}`);
              else
                cxt.setParams({ ifClause: keyword });
            };
          }
        }
      };
      function hasSchema(it, keyword) {
        const schema = it.schema[keyword];
        return schema !== void 0 && !(0, util_1.alwaysValidSchema)(it, schema);
      }
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/applicator/thenElse.js
  var require_thenElse = __commonJS({
    "node_modules/ajv/dist/vocabularies/applicator/thenElse.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var util_1 = require_util();
      var def = {
        keyword: ["then", "else"],
        schemaType: ["object", "boolean"],
        code({ keyword, parentSchema, it }) {
          if (parentSchema.if === void 0)
            (0, util_1.checkStrictMode)(it, `"${keyword}" without "if" is ignored`);
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/applicator/index.js
  var require_applicator = __commonJS({
    "node_modules/ajv/dist/vocabularies/applicator/index.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var additionalItems_1 = require_additionalItems();
      var prefixItems_1 = require_prefixItems();
      var items_1 = require_items();
      var items2020_1 = require_items2020();
      var contains_1 = require_contains();
      var dependencies_1 = require_dependencies();
      var propertyNames_1 = require_propertyNames();
      var additionalProperties_1 = require_additionalProperties();
      var properties_1 = require_properties();
      var patternProperties_1 = require_patternProperties();
      var not_1 = require_not();
      var anyOf_1 = require_anyOf();
      var oneOf_1 = require_oneOf();
      var allOf_1 = require_allOf();
      var if_1 = require_if();
      var thenElse_1 = require_thenElse();
      function getApplicator(draft2020 = false) {
        const applicator = [
          // any
          not_1.default,
          anyOf_1.default,
          oneOf_1.default,
          allOf_1.default,
          if_1.default,
          thenElse_1.default,
          // object
          propertyNames_1.default,
          additionalProperties_1.default,
          dependencies_1.default,
          properties_1.default,
          patternProperties_1.default
        ];
        if (draft2020)
          applicator.push(prefixItems_1.default, items2020_1.default);
        else
          applicator.push(additionalItems_1.default, items_1.default);
        applicator.push(contains_1.default);
        return applicator;
      }
      exports.default = getApplicator;
    }
  });

  // node_modules/ajv/dist/vocabularies/format/format.js
  var require_format = __commonJS({
    "node_modules/ajv/dist/vocabularies/format/format.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var codegen_1 = require_codegen();
      var error = {
        message: ({ schemaCode }) => (0, codegen_1.str)`must match format "${schemaCode}"`,
        params: ({ schemaCode }) => (0, codegen_1._)`{format: ${schemaCode}}`
      };
      var def = {
        keyword: "format",
        type: ["number", "string"],
        schemaType: "string",
        $data: true,
        error,
        code(cxt, ruleType) {
          const { gen, data, $data, schema, schemaCode, it } = cxt;
          const { opts, errSchemaPath, schemaEnv, self } = it;
          if (!opts.validateFormats)
            return;
          if ($data)
            validate$DataFormat();
          else
            validateFormat();
          function validate$DataFormat() {
            const fmts = gen.scopeValue("formats", {
              ref: self.formats,
              code: opts.code.formats
            });
            const fDef = gen.const("fDef", (0, codegen_1._)`${fmts}[${schemaCode}]`);
            const fType = gen.let("fType");
            const format = gen.let("format");
            gen.if((0, codegen_1._)`typeof ${fDef} == "object" && !(${fDef} instanceof RegExp)`, () => gen.assign(fType, (0, codegen_1._)`${fDef}.type || "string"`).assign(format, (0, codegen_1._)`${fDef}.validate`), () => gen.assign(fType, (0, codegen_1._)`"string"`).assign(format, fDef));
            cxt.fail$data((0, codegen_1.or)(unknownFmt(), invalidFmt()));
            function unknownFmt() {
              if (opts.strictSchema === false)
                return codegen_1.nil;
              return (0, codegen_1._)`${schemaCode} && !${format}`;
            }
            function invalidFmt() {
              const callFormat = schemaEnv.$async ? (0, codegen_1._)`(${fDef}.async ? await ${format}(${data}) : ${format}(${data}))` : (0, codegen_1._)`${format}(${data})`;
              const validData = (0, codegen_1._)`(typeof ${format} == "function" ? ${callFormat} : ${format}.test(${data}))`;
              return (0, codegen_1._)`${format} && ${format} !== true && ${fType} === ${ruleType} && !${validData}`;
            }
          }
          function validateFormat() {
            const formatDef = self.formats[schema];
            if (!formatDef) {
              unknownFormat();
              return;
            }
            if (formatDef === true)
              return;
            const [fmtType, format, fmtRef] = getFormat(formatDef);
            if (fmtType === ruleType)
              cxt.pass(validCondition());
            function unknownFormat() {
              if (opts.strictSchema === false) {
                self.logger.warn(unknownMsg());
                return;
              }
              throw new Error(unknownMsg());
              function unknownMsg() {
                return `unknown format "${schema}" ignored in schema at path "${errSchemaPath}"`;
              }
            }
            function getFormat(fmtDef) {
              const code = fmtDef instanceof RegExp ? (0, codegen_1.regexpCode)(fmtDef) : opts.code.formats ? (0, codegen_1._)`${opts.code.formats}${(0, codegen_1.getProperty)(schema)}` : void 0;
              const fmt = gen.scopeValue("formats", { key: schema, ref: fmtDef, code });
              if (typeof fmtDef == "object" && !(fmtDef instanceof RegExp)) {
                return [fmtDef.type || "string", fmtDef.validate, (0, codegen_1._)`${fmt}.validate`];
              }
              return ["string", fmtDef, fmt];
            }
            function validCondition() {
              if (typeof formatDef == "object" && !(formatDef instanceof RegExp) && formatDef.async) {
                if (!schemaEnv.$async)
                  throw new Error("async format in sync schema");
                return (0, codegen_1._)`await ${fmtRef}(${data})`;
              }
              return typeof format == "function" ? (0, codegen_1._)`${fmtRef}(${data})` : (0, codegen_1._)`${fmtRef}.test(${data})`;
            }
          }
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/vocabularies/format/index.js
  var require_format2 = __commonJS({
    "node_modules/ajv/dist/vocabularies/format/index.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var format_1 = require_format();
      var format = [format_1.default];
      exports.default = format;
    }
  });

  // node_modules/ajv/dist/vocabularies/metadata.js
  var require_metadata = __commonJS({
    "node_modules/ajv/dist/vocabularies/metadata.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.contentVocabulary = exports.metadataVocabulary = void 0;
      exports.metadataVocabulary = [
        "title",
        "description",
        "default",
        "deprecated",
        "readOnly",
        "writeOnly",
        "examples"
      ];
      exports.contentVocabulary = [
        "contentMediaType",
        "contentEncoding",
        "contentSchema"
      ];
    }
  });

  // node_modules/ajv/dist/vocabularies/draft7.js
  var require_draft7 = __commonJS({
    "node_modules/ajv/dist/vocabularies/draft7.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var core_1 = require_core3();
      var validation_1 = require_validation();
      var applicator_1 = require_applicator();
      var format_1 = require_format2();
      var metadata_1 = require_metadata();
      var draft7Vocabularies = [
        core_1.default,
        validation_1.default,
        (0, applicator_1.default)(),
        format_1.default,
        metadata_1.metadataVocabulary,
        metadata_1.contentVocabulary
      ];
      exports.default = draft7Vocabularies;
    }
  });

  // node_modules/ajv/dist/vocabularies/discriminator/types.js
  var require_types = __commonJS({
    "node_modules/ajv/dist/vocabularies/discriminator/types.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.DiscrError = void 0;
      var DiscrError;
      (function(DiscrError2) {
        DiscrError2["Tag"] = "tag";
        DiscrError2["Mapping"] = "mapping";
      })(DiscrError || (exports.DiscrError = DiscrError = {}));
    }
  });

  // node_modules/ajv/dist/vocabularies/discriminator/index.js
  var require_discriminator = __commonJS({
    "node_modules/ajv/dist/vocabularies/discriminator/index.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      var codegen_1 = require_codegen();
      var types_1 = require_types();
      var compile_1 = require_compile();
      var ref_error_1 = require_ref_error();
      var util_1 = require_util();
      var error = {
        message: ({ params: { discrError, tagName } }) => discrError === types_1.DiscrError.Tag ? `tag "${tagName}" must be string` : `value of tag "${tagName}" must be in oneOf`,
        params: ({ params: { discrError, tag, tagName } }) => (0, codegen_1._)`{error: ${discrError}, tag: ${tagName}, tagValue: ${tag}}`
      };
      var def = {
        keyword: "discriminator",
        type: "object",
        schemaType: "object",
        error,
        code(cxt) {
          const { gen, data, schema, parentSchema, it } = cxt;
          const { oneOf } = parentSchema;
          if (!it.opts.discriminator) {
            throw new Error("discriminator: requires discriminator option");
          }
          const tagName = schema.propertyName;
          if (typeof tagName != "string")
            throw new Error("discriminator: requires propertyName");
          if (schema.mapping)
            throw new Error("discriminator: mapping is not supported");
          if (!oneOf)
            throw new Error("discriminator: requires oneOf keyword");
          const valid = gen.let("valid", false);
          const tag = gen.const("tag", (0, codegen_1._)`${data}${(0, codegen_1.getProperty)(tagName)}`);
          gen.if((0, codegen_1._)`typeof ${tag} == "string"`, () => validateMapping(), () => cxt.error(false, { discrError: types_1.DiscrError.Tag, tag, tagName }));
          cxt.ok(valid);
          function validateMapping() {
            const mapping = getMapping();
            gen.if(false);
            for (const tagValue in mapping) {
              gen.elseIf((0, codegen_1._)`${tag} === ${tagValue}`);
              gen.assign(valid, applyTagSchema(mapping[tagValue]));
            }
            gen.else();
            cxt.error(false, { discrError: types_1.DiscrError.Mapping, tag, tagName });
            gen.endIf();
          }
          function applyTagSchema(schemaProp) {
            const _valid = gen.name("valid");
            const schCxt = cxt.subschema({ keyword: "oneOf", schemaProp }, _valid);
            cxt.mergeEvaluated(schCxt, codegen_1.Name);
            return _valid;
          }
          function getMapping() {
            var _a;
            const oneOfMapping = {};
            const topRequired = hasRequired(parentSchema);
            let tagRequired = true;
            for (let i = 0; i < oneOf.length; i++) {
              let sch = oneOf[i];
              if ((sch === null || sch === void 0 ? void 0 : sch.$ref) && !(0, util_1.schemaHasRulesButRef)(sch, it.self.RULES)) {
                const ref = sch.$ref;
                sch = compile_1.resolveRef.call(it.self, it.schemaEnv.root, it.baseId, ref);
                if (sch instanceof compile_1.SchemaEnv)
                  sch = sch.schema;
                if (sch === void 0)
                  throw new ref_error_1.default(it.opts.uriResolver, it.baseId, ref);
              }
              const propSch = (_a = sch === null || sch === void 0 ? void 0 : sch.properties) === null || _a === void 0 ? void 0 : _a[tagName];
              if (typeof propSch != "object") {
                throw new Error(`discriminator: oneOf subschemas (or referenced schemas) must have "properties/${tagName}"`);
              }
              tagRequired = tagRequired && (topRequired || hasRequired(sch));
              addMappings(propSch, i);
            }
            if (!tagRequired)
              throw new Error(`discriminator: "${tagName}" must be required`);
            return oneOfMapping;
            function hasRequired({ required }) {
              return Array.isArray(required) && required.includes(tagName);
            }
            function addMappings(sch, i) {
              if (sch.const) {
                addMapping(sch.const, i);
              } else if (sch.enum) {
                for (const tagValue of sch.enum) {
                  addMapping(tagValue, i);
                }
              } else {
                throw new Error(`discriminator: "properties/${tagName}" must have "const" or "enum"`);
              }
            }
            function addMapping(tagValue, i) {
              if (typeof tagValue != "string" || tagValue in oneOfMapping) {
                throw new Error(`discriminator: "${tagName}" values must be unique strings`);
              }
              oneOfMapping[tagValue] = i;
            }
          }
        }
      };
      exports.default = def;
    }
  });

  // node_modules/ajv/dist/refs/json-schema-draft-07.json
  var require_json_schema_draft_07 = __commonJS({
    "node_modules/ajv/dist/refs/json-schema-draft-07.json"(exports, module) {
      module.exports = {
        $schema: "http://json-schema.org/draft-07/schema#",
        $id: "http://json-schema.org/draft-07/schema#",
        title: "Core schema meta-schema",
        definitions: {
          schemaArray: {
            type: "array",
            minItems: 1,
            items: { $ref: "#" }
          },
          nonNegativeInteger: {
            type: "integer",
            minimum: 0
          },
          nonNegativeIntegerDefault0: {
            allOf: [{ $ref: "#/definitions/nonNegativeInteger" }, { default: 0 }]
          },
          simpleTypes: {
            enum: ["array", "boolean", "integer", "null", "number", "object", "string"]
          },
          stringArray: {
            type: "array",
            items: { type: "string" },
            uniqueItems: true,
            default: []
          }
        },
        type: ["object", "boolean"],
        properties: {
          $id: {
            type: "string",
            format: "uri-reference"
          },
          $schema: {
            type: "string",
            format: "uri"
          },
          $ref: {
            type: "string",
            format: "uri-reference"
          },
          $comment: {
            type: "string"
          },
          title: {
            type: "string"
          },
          description: {
            type: "string"
          },
          default: true,
          readOnly: {
            type: "boolean",
            default: false
          },
          examples: {
            type: "array",
            items: true
          },
          multipleOf: {
            type: "number",
            exclusiveMinimum: 0
          },
          maximum: {
            type: "number"
          },
          exclusiveMaximum: {
            type: "number"
          },
          minimum: {
            type: "number"
          },
          exclusiveMinimum: {
            type: "number"
          },
          maxLength: { $ref: "#/definitions/nonNegativeInteger" },
          minLength: { $ref: "#/definitions/nonNegativeIntegerDefault0" },
          pattern: {
            type: "string",
            format: "regex"
          },
          additionalItems: { $ref: "#" },
          items: {
            anyOf: [{ $ref: "#" }, { $ref: "#/definitions/schemaArray" }],
            default: true
          },
          maxItems: { $ref: "#/definitions/nonNegativeInteger" },
          minItems: { $ref: "#/definitions/nonNegativeIntegerDefault0" },
          uniqueItems: {
            type: "boolean",
            default: false
          },
          contains: { $ref: "#" },
          maxProperties: { $ref: "#/definitions/nonNegativeInteger" },
          minProperties: { $ref: "#/definitions/nonNegativeIntegerDefault0" },
          required: { $ref: "#/definitions/stringArray" },
          additionalProperties: { $ref: "#" },
          definitions: {
            type: "object",
            additionalProperties: { $ref: "#" },
            default: {}
          },
          properties: {
            type: "object",
            additionalProperties: { $ref: "#" },
            default: {}
          },
          patternProperties: {
            type: "object",
            additionalProperties: { $ref: "#" },
            propertyNames: { format: "regex" },
            default: {}
          },
          dependencies: {
            type: "object",
            additionalProperties: {
              anyOf: [{ $ref: "#" }, { $ref: "#/definitions/stringArray" }]
            }
          },
          propertyNames: { $ref: "#" },
          const: true,
          enum: {
            type: "array",
            items: true,
            minItems: 1,
            uniqueItems: true
          },
          type: {
            anyOf: [
              { $ref: "#/definitions/simpleTypes" },
              {
                type: "array",
                items: { $ref: "#/definitions/simpleTypes" },
                minItems: 1,
                uniqueItems: true
              }
            ]
          },
          format: { type: "string" },
          contentMediaType: { type: "string" },
          contentEncoding: { type: "string" },
          if: { $ref: "#" },
          then: { $ref: "#" },
          else: { $ref: "#" },
          allOf: { $ref: "#/definitions/schemaArray" },
          anyOf: { $ref: "#/definitions/schemaArray" },
          oneOf: { $ref: "#/definitions/schemaArray" },
          not: { $ref: "#" }
        },
        default: true
      };
    }
  });

  // node_modules/ajv/dist/ajv.js
  var require_ajv = __commonJS({
    "node_modules/ajv/dist/ajv.js"(exports, module) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.MissingRefError = exports.ValidationError = exports.CodeGen = exports.Name = exports.nil = exports.stringify = exports.str = exports._ = exports.KeywordCxt = exports.Ajv = void 0;
      var core_1 = require_core2();
      var draft7_1 = require_draft7();
      var discriminator_1 = require_discriminator();
      var draft7MetaSchema = require_json_schema_draft_07();
      var META_SUPPORT_DATA = ["/properties"];
      var META_SCHEMA_ID = "http://json-schema.org/draft-07/schema";
      var Ajv2 = class extends core_1.default {
        _addVocabularies() {
          super._addVocabularies();
          draft7_1.default.forEach((v) => this.addVocabulary(v));
          if (this.opts.discriminator)
            this.addKeyword(discriminator_1.default);
        }
        _addDefaultMetaSchema() {
          super._addDefaultMetaSchema();
          if (!this.opts.meta)
            return;
          const metaSchema = this.opts.$data ? this.$dataMetaSchema(draft7MetaSchema, META_SUPPORT_DATA) : draft7MetaSchema;
          this.addMetaSchema(metaSchema, META_SCHEMA_ID, false);
          this.refs["http://json-schema.org/schema"] = META_SCHEMA_ID;
        }
        defaultMeta() {
          return this.opts.defaultMeta = super.defaultMeta() || (this.getSchema(META_SCHEMA_ID) ? META_SCHEMA_ID : void 0);
        }
      };
      exports.Ajv = Ajv2;
      module.exports = exports = Ajv2;
      module.exports.Ajv = Ajv2;
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.default = Ajv2;
      var validate_1 = require_validate();
      Object.defineProperty(exports, "KeywordCxt", { enumerable: true, get: function() {
        return validate_1.KeywordCxt;
      } });
      var codegen_1 = require_codegen();
      Object.defineProperty(exports, "_", { enumerable: true, get: function() {
        return codegen_1._;
      } });
      Object.defineProperty(exports, "str", { enumerable: true, get: function() {
        return codegen_1.str;
      } });
      Object.defineProperty(exports, "stringify", { enumerable: true, get: function() {
        return codegen_1.stringify;
      } });
      Object.defineProperty(exports, "nil", { enumerable: true, get: function() {
        return codegen_1.nil;
      } });
      Object.defineProperty(exports, "Name", { enumerable: true, get: function() {
        return codegen_1.Name;
      } });
      Object.defineProperty(exports, "CodeGen", { enumerable: true, get: function() {
        return codegen_1.CodeGen;
      } });
      var validation_error_1 = require_validation_error();
      Object.defineProperty(exports, "ValidationError", { enumerable: true, get: function() {
        return validation_error_1.default;
      } });
      var ref_error_1 = require_ref_error();
      Object.defineProperty(exports, "MissingRefError", { enumerable: true, get: function() {
        return ref_error_1.default;
      } });
    }
  });

  // packages/plugin-harness/dist/index.js
  var index_exports = {};
  __export(index_exports, {
    CapabilityExecutorNode: () => CapabilityExecutorNode,
    ConfidenceGateNode: () => ConfidenceGateNode,
    ContextualExperienceRecorderNode: () => ContextualExperienceRecorderNode,
    ContextualPolicyLookupNode: () => ContextualPolicyLookupNode,
    CueObserverNode: () => CueObserverNode,
    CuePolicyLookupNode: () => CuePolicyLookupNode,
    DecisionContextNode: () => DecisionContextNode,
    DecisionMergeNode: () => DecisionMergeNode,
    ExperienceRecorderNode: () => ExperienceRecorderNode,
    FallbackRequestNode: () => FallbackRequestNode,
    HARNESS_NODES: () => HARNESS_NODES,
    HarnessMonitorNode: () => HarnessMonitorNode,
    HarnessNode: () => HarnessNode,
    MONITOR_NODES: () => MONITOR_NODES,
    OutcomeEvaluatorNode: () => OutcomeEvaluatorNode,
    OutcomeObserverNode: () => OutcomeObserverNode,
    PolicyLookupNode: () => PolicyLookupNode,
    ReasoningProviderNode: () => ReasoningProviderNode,
    SafetyGuardNode: () => SafetyGuardNode,
    StateObserverNode: () => StateObserverNode,
    compileHarnessGraph: () => compileHarnessGraph,
    createGraphDriver: () => createGraphDriver,
    createHarnessNode: () => createHarnessNode,
    createRuntimeGraphDriver: () => createRuntimeGraphDriver,
    default: () => index_default,
    harness: () => dist_exports,
    harnessPort: () => harnessPort,
    parseHarnessDefinition: () => parseHarnessDefinition,
    validateHarnessGraph: () => validateHarnessGraph
  });

  // packages/harness/dist/index.js
  var dist_exports = {};
  __export(dist_exports, {
    ActionNode: () => ActionNode,
    AdaptiveCueObserver: () => AdaptiveCueObserver,
    AdaptivePolicyRuntime: () => AdaptivePolicyRuntime,
    AllowAllSafetyGuard: () => AllowAllSafetyGuard,
    CapabilityBinding: () => CapabilityBinding,
    CapabilityExecutorNode: () => CapabilityExecutorNode,
    CapabilityNode: () => CapabilityNode,
    CapabilityRegistry: () => CapabilityRegistry,
    ConfidenceGateNode: () => ConfidenceGateNode,
    ContextNode: () => ContextNode,
    ContextualExperienceRecorderNode: () => ContextualExperienceRecorderNode,
    ContextualPolicyGraph: () => ContextualPolicyGraph,
    ContextualPolicyLookupNode: () => ContextualPolicyLookupNode,
    CueFeatureNode: () => CueFeatureNode,
    CueObserverNode: () => CueObserverNode,
    CuePolicyLookupNode: () => CuePolicyLookupNode,
    DEFAULT_CONSOLIDATION_CONFIG: () => DEFAULT_CONSOLIDATION_CONFIG,
    DEFAULT_CUE_CONFIG: () => DEFAULT_CUE_CONFIG,
    DEFAULT_MODULATED_RESET_CONFIG: () => DEFAULT_MODULATED_RESET_CONFIG,
    DEFAULT_OPERATING_CONTEXT_CONFIG: () => DEFAULT_OPERATING_CONTEXT_CONFIG,
    DEFAULT_PLASTICITY_CONFIG: () => DEFAULT_PLASTICITY_CONFIG,
    DEFAULT_TEMPORAL_EVIDENCE_CONFIG: () => DEFAULT_TEMPORAL_EVIDENCE_CONFIG,
    DEFAULT_TOPOLOGY_CONFIG: () => DEFAULT_TOPOLOGY_CONFIG,
    DEFAULT_TOPOLOGY_TEMPORAL_CONFIG: () => DEFAULT_TOPOLOGY_TEMPORAL_CONFIG,
    DecisionContextNode: () => DecisionContextNode,
    DecisionMergeNode: () => DecisionMergeNode,
    ExactStateMatcher: () => ExactStateMatcher,
    ExecutionAuthority: () => ExecutionAuthority,
    ExperienceNode: () => ExperienceNode,
    ExperienceRecorderNode: () => ExperienceRecorderNode,
    FallbackRequestNode: () => FallbackRequestNode,
    HARNESS_NODES: () => HARNESS_NODES,
    HarnessNode: () => HarnessNode,
    HarnessSession: () => HarnessSession,
    MemoryRelationLink: () => MemoryRelationLink,
    OperatingContextTracker: () => OperatingContextTracker,
    OperatingModeNode: () => OperatingModeNode,
    OutcomeEvaluatorNode: () => OutcomeEvaluatorNode,
    OutcomeObserverNode: () => OutcomeObserverNode,
    PolicyGraph: () => PolicyGraph,
    PolicyLookupNode: () => PolicyLookupNode,
    PolicyMetrics: () => PolicyMetrics,
    PolicyTransition: () => PolicyTransition,
    ReasoningProviderNode: () => ReasoningProviderNode,
    SafetyGuardNode: () => SafetyGuardNode,
    StateObserverNode: () => StateObserverNode,
    TemporalCueObserver: () => TemporalCueObserver,
    TemporalEvidenceNetwork: () => TemporalEvidenceNetwork,
    TemporalTopologyMemory: () => TemporalTopologyMemory,
    TemporalTopologySession: () => TemporalTopologySession,
    TopologyActivationSession: () => TopologyActivationSession,
    TopologyExperienceRecorderNode: () => TopologyExperienceRecorderNode,
    TopologyGateNode: () => TopologyGateNode,
    TopologyLookupNode: () => TopologyLookupNode,
    TopologyMemory: () => TopologyMemory,
    V1_HARNESS_NODES: () => V1_HARNESS_NODES,
    abortable: () => abortable,
    advanceConsolidation: () => advanceConsolidation,
    assertJson: () => assertJson,
    checkAbort: () => checkAbort,
    compileHarnessGraph: () => compileHarnessGraph,
    compileInputSchema: () => compileInputSchema,
    contextKey: () => contextKey,
    createDecisionContext: () => createDecisionContext,
    createGraphDriver: () => createGraphDriver,
    createHarnessNode: () => createHarnessNode,
    createRuntimeGraphDriver: () => createRuntimeGraphDriver,
    createTemporalTopologyHarness: () => createTemporalTopologyHarness,
    createTopologyHarness: () => createTopologyHarness,
    harnessPort: () => harnessPort,
    immutableCopy: () => immutableCopy,
    initialTransitionStats: () => initialTransitionStats,
    isPolicyLink: () => isPolicyLink,
    isPolicyNode: () => isPolicyNode,
    jsonCopy: () => jsonCopy,
    operatingModeId: () => operatingModeId,
    parseHarnessDefinition: () => parseHarnessDefinition,
    scoreTransition: () => scoreTransition,
    stableStringify: () => stableStringify,
    topologyKey: () => topologyKey,
    transitionKey: () => transitionKey,
    updateTransitionStats: () => updateTransitionStats,
    validateConsolidationConfig: () => validateConsolidationConfig,
    validateConsolidationSupport: () => validateConsolidationSupport,
    validateCueConfiguration: () => validateCueConfiguration,
    validateDecision: () => validateDecision,
    validateEvaluation: () => validateEvaluation,
    validateHarnessGraph: () => validateHarnessGraph,
    validateIntention: () => validateIntention,
    validateModulatedResetConfig: () => validateModulatedResetConfig,
    validateOperatingConfig: () => validateOperatingConfig,
    validatePlasticityConfig: () => validatePlasticityConfig,
    validateState: () => validateState,
    validateTemporalEvidenceConfig: () => validateTemporalEvidenceConfig,
    validateTopologyConfig: () => validateTopologyConfig,
    validateTopologyDefinition: () => validateTopologyDefinition,
    validateTopologyTemporalConfig: () => validateTopologyTemporalConfig
  });

  // packages/harness/dist/canonical.js
  function stableStringify(value) {
    if (value === null || typeof value !== "object") {
      return JSON.stringify(value);
    }
    if (Array.isArray(value)) {
      return `[${value.map((item) => stableStringify(item)).join(",")}]`;
    }
    const record2 = value;
    return `{${Object.keys(record2).sort().map((key2) => `${JSON.stringify(key2)}:${stableStringify(record2[key2])}`).join(",")}}`;
  }
  function contextKey(state, intention) {
    return stableStringify(intention.parameters ? [state.id, intention.id, intention.parameters] : [state.id, intention.id]);
  }
  function createDecisionContext(state, intention, operatingContextId) {
    const key2 = contextKey(state, intention);
    return operatingContextId ? { key: stableStringify([key2, "operating", operatingContextId]), state, intention, operatingContextId } : { key: key2, state, intention };
  }
  function transitionKey(context, actionId, capabilityId, input) {
    return stableStringify([context.key, actionId, capabilityId, stableStringify(input)]);
  }

  // packages/harness/dist/matching.js
  var ExactStateMatcher = class {
    similarity(a, b) {
      return a.id === b.id ? 1 : 0;
    }
  };

  // packages/harness/dist/plasticity.js
  var DEFAULT_PLASTICITY_CONFIG = Object.freeze({
    rewardAlpha: 0.25,
    confidenceAlpha: 0.25,
    initialConfidence: 0.5,
    minimumEvidence: 3,
    maximumEffectiveEvidence: 8,
    promotionConfidence: 0.75,
    demotionConfidence: 0.55,
    promotionReward: 0.35,
    demotionReward: 0,
    maximumConsecutiveFailures: 3,
    scoreThreshold: 0.55
  });
  function validatePlasticityConfig(config) {
    for (const key2 of Object.keys(DEFAULT_PLASTICITY_CONFIG)) {
      if (!Number.isFinite(config[key2]))
        throw new Error(`Invalid plasticity parameter: ${key2}`);
    }
    if (config.rewardAlpha <= 0 || config.rewardAlpha > 1 || config.confidenceAlpha <= 0 || config.confidenceAlpha > 1 || config.initialConfidence < 0 || config.initialConfidence > 1 || config.minimumEvidence < 1 || config.maximumEffectiveEvidence < config.minimumEvidence || config.maximumConsecutiveFailures < 1 || config.promotionConfidence > 1 || config.demotionConfidence < 0 || config.promotionConfidence <= config.demotionConfidence || config.promotionReward > 1 || config.demotionReward < -1 || config.promotionReward <= config.demotionReward || config.scoreThreshold < 0 || config.scoreThreshold > 1)
      throw new Error("Invalid plasticity bounds or hysteresis");
  }
  function initialTransitionStats(config = DEFAULT_PLASTICITY_CONFIG) {
    return {
      totalUsageCount: 0,
      totalSuccessCount: 0,
      totalFailureCount: 0,
      rewardEma: 0,
      confidence: config.initialConfidence,
      effectiveEvidence: 0,
      consecutiveFailures: 0,
      directEligible: false
    };
  }
  function updateTransitionStats(previous, observation, observedAt, config = DEFAULT_PLASTICITY_CONFIG) {
    const reward = Math.max(-1, Math.min(1, observation.reward));
    const successSignal = observation.success ? 1 : 0;
    const rewardEma = previous.rewardEma * (1 - config.rewardAlpha) + reward * config.rewardAlpha;
    const confidence = previous.confidence * (1 - config.confidenceAlpha) + successSignal * config.confidenceAlpha;
    const effectiveEvidence = Math.min(config.maximumEffectiveEvidence, previous.effectiveEvidence + 1);
    const consecutiveFailures = observation.success ? 0 : previous.consecutiveFailures + 1;
    const canPromote = effectiveEvidence >= config.minimumEvidence && confidence >= config.promotionConfidence && rewardEma >= config.promotionReward;
    const canRetain = confidence >= config.demotionConfidence && rewardEma >= config.demotionReward && consecutiveFailures < config.maximumConsecutiveFailures;
    return {
      totalUsageCount: previous.totalUsageCount + 1,
      totalSuccessCount: previous.totalSuccessCount + (observation.success ? 1 : 0),
      totalFailureCount: previous.totalFailureCount + (observation.success ? 0 : 1),
      rewardEma,
      confidence,
      effectiveEvidence,
      consecutiveFailures,
      directEligible: previous.directEligible ? canRetain : canPromote,
      lastUsedAt: observedAt
    };
  }
  function scoreTransition(stats, similarity) {
    const rewardQuality = (Math.max(-1, Math.min(1, stats.rewardEma)) + 1) / 2;
    return rewardQuality * stats.confidence * Math.max(0, Math.min(1, similarity));
  }

  // packages/harness/dist/policy-graph.js
  var import_core = __toESM(require_core(), 1);

  // packages/harness/dist/validation.js
  var import_ajv = __toESM(require_ajv(), 1);
  var ajv = new import_ajv.default({ strict: true, allErrors: true });
  var decisionValidator = ajv.compile({
    type: "object",
    required: ["action", "invocation"],
    additionalProperties: false,
    properties: {
      source: { enum: ["policy", "fallback"] },
      action: {
        type: "object",
        required: ["id", "description"],
        additionalProperties: false,
        properties: { id: { type: "string", minLength: 1 }, description: { type: "string" } }
      },
      invocation: {
        type: "object",
        required: ["actionId", "capabilityId", "input"],
        additionalProperties: false,
        properties: { actionId: { type: "string", minLength: 1 }, capabilityId: { type: "string", minLength: 1 }, input: {} }
      },
      expectedOutcome: {
        type: "object",
        required: ["description"],
        additionalProperties: false,
        properties: { description: { type: "string" }, observableConditions: { type: "object" } }
      },
      rationale: { type: "string" }
    }
  });
  function assertJson(value, ancestors = /* @__PURE__ */ new Set()) {
    if (value === null || typeof value === "string" || typeof value === "boolean")
      return;
    if (typeof value === "number" && Number.isFinite(value))
      return;
    if (typeof value !== "object" || !value || ancestors.has(value))
      throw new Error("Expected finite, acyclic JSON data");
    if (!Array.isArray(value) && Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null) {
      throw new Error("Expected a plain JSON object");
    }
    ancestors.add(value);
    for (const item of Object.values(value))
      assertJson(item, ancestors);
    ancestors.delete(value);
  }
  function validateDecision(value) {
    const data = jsonCopy(value);
    assertJson(data);
    if (!decisionValidator(data))
      throw new Error(`Invalid decision: ${ajv.errorsText(decisionValidator.errors)}`);
    const decision = data;
    assertJson(decision.invocation.input);
    if (decision.action.id !== decision.invocation.actionId)
      throw new Error("Action and invocation IDs differ");
  }
  function jsonCopy(value) {
    const visit = (item, seen) => {
      if (item === null || typeof item === "string" || typeof item === "boolean")
        return item;
      if (typeof item === "number" && Number.isFinite(item))
        return item;
      if (!item || typeof item !== "object" || seen.has(item))
        throw new Error("Invalid JSON snapshot value");
      if (!Array.isArray(item) && Object.getPrototypeOf(item) !== Object.prototype && Object.getPrototypeOf(item) !== null) {
        throw new Error("Snapshot must contain plain data only");
      }
      seen.add(item);
      const result = Array.isArray(item) ? item.map((value2) => visit(value2, seen)) : Object.fromEntries(Object.entries(item).filter(([, value2]) => value2 !== void 0).map(([key2, value2]) => [key2, visit(value2, seen)]));
      seen.delete(item);
      return result;
    };
    return visit(value, /* @__PURE__ */ new Set());
  }
  function immutableCopy(value) {
    const freeze = (item) => {
      if (!item || typeof item !== "object")
        return;
      Object.values(item).forEach(freeze);
      Object.freeze(item);
    };
    const copy = jsonCopy(value);
    freeze(copy);
    return copy;
  }
  function compileInputSchema(schema) {
    assertJson(schema);
    const validate = ajv.compile(schema);
    return (input) => {
      assertJson(input);
      if (!validate(input))
        throw new Error(`Invalid capability arguments: ${ajv.errorsText(validate.errors)}`);
    };
  }
  function validateState(value) {
    if (!value || typeof value.id !== "string" || !value.id || !value.features || typeof value.features !== "object" || Array.isArray(value.features))
      throw new Error("Invalid observation");
    assertJson(value.features);
    if (value.embedding && (!Array.isArray(value.embedding) || !value.embedding.every(Number.isFinite)))
      throw new Error("Invalid embedding");
  }
  function validateIntention(value) {
    if (!value || typeof value.id !== "string" || !value.id || value.parameters !== void 0 && (!value.parameters || typeof value.parameters !== "object" || Array.isArray(value.parameters)))
      throw new Error("Invalid intention");
    if (value.parameters)
      assertJson(value.parameters);
  }
  function validateEvaluation(value) {
    if (!value || typeof value.success !== "boolean" || !Number.isFinite(value.reward) || Math.abs(value.reward) > 1)
      throw new Error("Invalid outcome evaluation");
  }
  function checkAbort(signal) {
    if (signal?.aborted)
      throw signal.reason instanceof Error ? signal.reason : new Error("Execution cancelled");
  }
  function abortable(work2, signal) {
    checkAbort(signal);
    return new Promise((resolve, reject) => {
      const cancel = () => reject(signal.reason ?? new Error("Execution cancelled"));
      signal.addEventListener("abort", cancel, { once: true });
      Promise.resolve().then(() => {
        checkAbort(signal);
        return work2();
      }).then(resolve, reject).finally(() => signal.removeEventListener("abort", cancel));
    });
  }

  // packages/harness/dist/policy-graph.js
  var CONTEXT_TYPE = "Harness.Policy:context";
  var ACTION_TYPE = "Harness.Policy:action";
  var CAPABILITY_TYPE = "Harness.Policy:capability";
  var EXPERIENCE_TYPE = "Harness.Policy:experience";
  var TRANSITION_TYPE = "Harness.Policy:transition";
  var BINDING_TYPE = "Harness.Policy:bindsTo";
  var ContextNode = class extends import_core.GraphNode {
    context;
    constructor(context) {
      super();
      this.context = context;
      this.id = `context:${context.key}`;
      this.type = CONTEXT_TYPE;
    }
  };
  var ActionNode = class extends import_core.GraphNode {
    action;
    constructor(action) {
      super();
      this.action = action;
      this.id = `action:${action.id}`;
      this.type = ACTION_TYPE;
    }
  };
  var CapabilityNode = class extends import_core.GraphNode {
    descriptor;
    constructor(descriptor) {
      super();
      this.descriptor = descriptor;
      this.id = `capability:${descriptor.id}`;
      this.type = CAPABILITY_TYPE;
    }
  };
  var ExperienceNode = class extends import_core.GraphNode {
    experience;
    constructor(experience) {
      super();
      this.experience = experience;
      this.id = `experience:${experience.id}`;
      this.type = EXPERIENCE_TYPE;
    }
  };
  var PolicyTransition = class extends import_core.GraphOLink {
    key;
    invocation;
    stats;
    expectedOutcome;
    constructor(context, action, key2, invocation, stats, expectedOutcome) {
      super(context, action);
      this.key = key2;
      this.invocation = invocation;
      this.stats = stats;
      this.expectedOutcome = expectedOutcome;
      this.id = `transition:${key2}`;
      this.type = TRANSITION_TYPE;
    }
  };
  var CapabilityBinding = class extends import_core.GraphOLink {
    constructor(action, capability) {
      super(action, capability);
      this.id = `binding:${action.action.id}:${capability.descriptor.id}`;
      this.type = BINDING_TYPE;
    }
  };
  var PolicyGraph = class _PolicyGraph {
    matcher;
    plasticity;
    graph = new import_core.GraphBuilder().build();
    contexts = /* @__PURE__ */ new Map();
    actions = /* @__PURE__ */ new Map();
    capabilities = /* @__PURE__ */ new Map();
    transitions = /* @__PURE__ */ new Map();
    bindings = /* @__PURE__ */ new Map();
    experiences = [];
    experienceSequence = 0;
    constructor(matcher = new ExactStateMatcher(), plasticity = DEFAULT_PLASTICITY_CONFIG) {
      this.matcher = matcher;
      this.plasticity = plasticity;
      validatePlasticityConfig(plasticity);
      this.plasticity = immutableCopy(plasticity);
    }
    graphView() {
      return this.graph;
    }
    findCandidateActions(state, intention, operatingContextId) {
      const candidates = [];
      for (const contextNode of this.contexts.values()) {
        if (contextNode.context.operatingContextId !== operatingContextId)
          continue;
        if (contextNode.context.intention.id !== intention.id)
          continue;
        if (stableStringify(contextNode.context.intention.parameters ?? {}) !== stableStringify(intention.parameters ?? {}))
          continue;
        const similarity = this.matcher.similarity(contextNode.context.state, state);
        if (similarity <= 0)
          continue;
        for (const link of contextNode.onsc((item) => item.type === TRANSITION_TYPE)) {
          const action = link.ofin;
          if (!action)
            continue;
          const score = scoreTransition(link.stats, similarity);
          candidates.push({
            transitionKey: link.key,
            context: contextNode.context,
            action: action.action,
            invocation: link.invocation,
            expectedOutcome: link.expectedOutcome,
            score,
            confidence: link.stats.confidence,
            similarity,
            eligible: link.stats.directEligible && score >= this.plasticity.scoreThreshold,
            stats: { ...link.stats }
          });
        }
      }
      return candidates.sort((a, b) => b.score - a.score || b.confidence - a.confidence);
    }
    recordExperience(input) {
      input = immutableCopy(input);
      validateState(input.stateBefore);
      validateState(input.stateAfter);
      validateIntention(input.intention);
      validateDecision(input.decision);
      if (input.experienceId && this.experiences.some((n) => n.experience.id === input.experienceId))
        throw new Error("Duplicate experience ID");
      validateEvaluation(input.evaluation);
      const observedAt = input.observedAt ?? Date.now();
      const context = createDecisionContext(input.stateBefore, input.intention, input.operatingContextId);
      const contextNode = this.ensureContext(context);
      const actionNode = this.ensureAction(input.decision.action);
      const capabilityNode = this.ensureCapability({
        id: input.decision.invocation.capabilityId,
        description: input.decision.invocation.capabilityId
      });
      this.ensureBinding(actionNode, capabilityNode);
      const key2 = transitionKey(context, input.decision.action.id, input.decision.invocation.capabilityId, input.decision.invocation.input);
      let transition = this.transitions.get(key2);
      if (!transition) {
        transition = new PolicyTransition(contextNode, actionNode, key2, input.decision.invocation, initialTransitionStats(this.plasticity), input.decision.expectedOutcome);
        this.transitions.set(key2, transition);
        this.addLink(transition);
      }
      transition.stats = updateTransitionStats(transition.stats, input.evaluation, observedAt, this.plasticity);
      transition.expectedOutcome = input.decision.expectedOutcome ?? transition.expectedOutcome;
      const id = input.experienceId ?? `exp-${observedAt}-${++this.experienceSequence}`;
      const experience = {
        id,
        decisionId: input.decisionId,
        context,
        decision: input.decision,
        stateAfter: input.stateAfter,
        result: input.result,
        evaluation: input.evaluation,
        observedAt
      };
      const node = new ExperienceNode(experience);
      this.experiences.push(node);
      this.addNode(node);
      return experience;
    }
    getKnownContexts() {
      return [...this.contexts.values()].map((node) => node.context);
    }
    getKnownStates() {
      const byId = /* @__PURE__ */ new Map();
      for (const node of this.contexts.values())
        byId.set(node.context.state.id, node.context.state);
      return [...byId.values()];
    }
    getOutgoingTransitions(state, intention) {
      return this.findCandidateActions(state, intention);
    }
    getActionHistory(actionId) {
      return this.experiences.map((node) => node.experience).filter((experience) => experience.decision.action.id === actionId);
    }
    getRecentFailures(state, intention, limit = 5) {
      const key2 = createDecisionContext(state, intention).key;
      return this.experiences.map((node) => node.experience).filter((experience) => experience.context.key === key2 && !experience.evaluation.success).slice(-limit).reverse();
    }
    getTransitionStats(state, intention, invocation, operatingContextId) {
      const context = createDecisionContext(state, intention, operatingContextId);
      const key2 = transitionKey(context, invocation.actionId, invocation.capabilityId, invocation.input);
      const stats = this.transitions.get(key2)?.stats;
      return stats ? { ...stats } : void 0;
    }
    snapshot() {
      return immutableCopy({
        version: 1,
        plasticity: this.plasticity,
        contexts: [...this.contexts.values()].map((node) => node.context),
        actions: [...this.actions.values()].map((node) => node.action),
        capabilities: [...this.capabilities.values()].map((node) => node.descriptor),
        transitions: [...this.transitions.values()].map((transition) => ({
          contextKey: transition.oini.context.key,
          actionId: transition.ofin.action.id,
          key: transition.key,
          invocation: transition.invocation,
          stats: transition.stats,
          expectedOutcome: transition.expectedOutcome
        })),
        bindings: [...this.bindings.values()].map((binding) => ({
          actionId: binding.oini.action.id,
          capabilityId: binding.ofin.descriptor.id
        })),
        experiences: this.experiences.map((node) => node.experience)
      });
    }
    static fromSnapshot(snapshot, matcher = new ExactStateMatcher(), plasticity = snapshot.plasticity ?? DEFAULT_PLASTICITY_CONFIG) {
      snapshot = immutableCopy(snapshot);
      if (snapshot.version !== 1)
        throw new Error(`Unsupported policy snapshot version: ${String(snapshot.version)}`);
      for (const key2 of ["contexts", "actions", "capabilities", "transitions", "bindings", "experiences"]) {
        if (!Array.isArray(snapshot[key2]))
          throw new Error(`Invalid snapshot collection: ${key2}`);
      }
      const policy = new _PolicyGraph(matcher, plasticity);
      for (const context of snapshot.contexts) {
        validateState(context.state);
        validateIntention(context.intention);
        if (!context.state?.id || !context.intention?.id || context.key !== createDecisionContext(context.state, context.intention, context.operatingContextId).key || policy.contexts.has(context.key))
          throw new Error("Invalid or duplicate context");
        policy.ensureContext(context);
      }
      for (const action of snapshot.actions) {
        if (!action.id || typeof action.description !== "string" || policy.actions.has(action.id))
          throw new Error("Invalid or duplicate action");
        policy.ensureAction(action);
      }
      for (const capability of snapshot.capabilities) {
        if (!capability.id || policy.capabilities.has(capability.id))
          throw new Error("Invalid or duplicate capability");
        policy.ensureCapability(capability);
      }
      for (const item of snapshot.transitions) {
        const context = policy.contexts.get(item.contextKey);
        const action = policy.actions.get(item.actionId);
        if (!context || !action)
          throw new Error(`Invalid transition snapshot: ${item.key}`);
        validateDecision({ action: action.action, invocation: item.invocation, expectedOutcome: item.expectedOutcome });
        if (item.key !== transitionKey(context.context, item.actionId, item.invocation.capabilityId, item.invocation.input) || policy.transitions.has(item.key) || !policy.capabilities.has(item.invocation.capabilityId))
          throw new Error("Invalid transition identity");
        const stats = item.stats;
        if (!stats || ![stats.totalUsageCount, stats.totalSuccessCount, stats.totalFailureCount, stats.consecutiveFailures].every((n) => Number.isSafeInteger(n) && n >= 0) || stats.totalUsageCount !== stats.totalSuccessCount + stats.totalFailureCount || stats.consecutiveFailures > stats.totalFailureCount || stats.effectiveEvidence > stats.totalUsageCount || !Number.isFinite(stats.rewardEma) || Math.abs(stats.rewardEma) > 1 || !Number.isFinite(stats.confidence) || stats.confidence < 0 || stats.confidence > 1 || !Number.isFinite(stats.effectiveEvidence) || stats.effectiveEvidence < 0 || stats.effectiveEvidence > plasticity.maximumEffectiveEvidence || typeof stats.directEligible !== "boolean")
          throw new Error("Invalid transition statistics");
        const transition = new PolicyTransition(context, action, item.key, item.invocation, { ...item.stats }, item.expectedOutcome);
        policy.transitions.set(item.key, transition);
        policy.addLink(transition);
      }
      for (const item of snapshot.bindings) {
        const action = policy.actions.get(item.actionId);
        const capability = policy.capabilities.get(item.capabilityId);
        if (!action || !capability)
          throw new Error(`Invalid capability binding: ${item.actionId}/${item.capabilityId}`);
        policy.ensureBinding(action, capability);
      }
      for (const experience of snapshot.experiences) {
        if (!experience.id || policy.experiences.some((n) => n.experience.id === experience.id) || !policy.contexts.has(experience.context.key))
          throw new Error("Invalid or duplicate experience");
        validateDecision(experience.decision);
        validateEvaluation(experience.evaluation);
        validateState(experience.stateAfter);
        validateState(experience.context.state);
        validateIntention(experience.context.intention);
        if (!experience.result || typeof experience.result.ok !== "boolean" || !Number.isFinite(experience.observedAt) || !["policy", "fallback"].includes(experience.decision.source) || experience.context.key !== createDecisionContext(experience.context.state, experience.context.intention, experience.context.operatingContextId).key)
          throw new Error("Invalid experience payload");
        const node = new ExperienceNode(experience);
        policy.experiences.push(node);
        policy.addNode(node);
        policy.experienceSequence += 1;
      }
      return policy;
    }
    ensureContext(context) {
      let node = this.contexts.get(context.key);
      if (!node) {
        node = new ContextNode(context);
        this.contexts.set(context.key, node);
        this.addNode(node);
      }
      return node;
    }
    ensureAction(action) {
      let node = this.actions.get(action.id);
      if (!node) {
        node = new ActionNode(action);
        this.actions.set(action.id, node);
        this.addNode(node);
      }
      return node;
    }
    ensureCapability(descriptor) {
      let node = this.capabilities.get(descriptor.id);
      if (!node) {
        node = new CapabilityNode(descriptor);
        this.capabilities.set(descriptor.id, node);
        this.addNode(node);
      }
      return node;
    }
    ensureBinding(action, capability) {
      const key2 = `${action.action.id}:${capability.descriptor.id}`;
      let binding = this.bindings.get(key2);
      if (!binding) {
        binding = new CapabilityBinding(action, capability);
        this.bindings.set(key2, binding);
        this.addLink(binding);
      }
      return binding;
    }
    addNode(node) {
      this.graph.nodes.push(node);
      this.graph.hiddens.push(node);
    }
    addLink(link) {
      this.graph.links.push(link);
    }
  };
  function isPolicyNode(node) {
    return [CONTEXT_TYPE, ACTION_TYPE, CAPABILITY_TYPE, EXPERIENCE_TYPE].includes(node.type ?? "");
  }
  function isPolicyLink(link) {
    return link.type === TRANSITION_TYPE || link.type === BINDING_TYPE;
  }

  // packages/harness/dist/capability.js
  var CapabilityRegistry = class {
    options;
    capabilities = /* @__PURE__ */ new Map();
    validators = /* @__PURE__ */ new Map();
    inFlight = false;
    constructor(options = {}) {
      this.options = options;
    }
    register(capability) {
      const descriptor = immutableCopy(capability.descriptor);
      if (!descriptor.id || this.capabilities.has(descriptor.id))
        throw new Error(`Invalid or duplicate capability: ${descriptor.id}`);
      if (descriptor.replayPolicy && !["automatic", "approval-required", "never"].includes(descriptor.replayPolicy)) {
        throw new Error("Invalid replay policy");
      }
      this.validators.set(descriptor.id, descriptor.inputSchema === void 0 ? assertJson : compileInputSchema(descriptor.inputSchema));
      this.capabilities.set(descriptor.id, {
        descriptor,
        execute: capability.execute.bind(capability),
        isAvailable: capability.isAvailable?.bind(capability)
      });
    }
    get(id) {
      return this.capabilities.get(id);
    }
    list() {
      return [...this.capabilities.values()].map((c) => c.descriptor);
    }
    async listAvailable(context) {
      const available = [];
      for (const capability of this.capabilities.values()) {
        checkAbort(context.signal);
        if (capability.descriptor.replayPolicy === "never")
          continue;
        if (capability.descriptor.replayPolicy === "approval-required" && !this.options.approve)
          continue;
        if (!capability.isAvailable || await capability.isAvailable(context))
          available.push(capability.descriptor);
      }
      checkAbort(context.signal);
      return available;
    }
    validate(decision) {
      validateDecision(decision);
      const capability = this.get(decision.invocation.capabilityId);
      if (!capability)
        throw new Error(`Unknown capability: ${decision.invocation.capabilityId}`);
      if (capability.descriptor.replayPolicy === "never")
        throw new Error("Capability forbidden to the harness");
      this.validators.get(capability.descriptor.id)(decision.invocation.input);
    }
    async execute(decision, context, beforeExecute) {
      checkAbort(context.signal);
      this.validate(decision);
      if (this.inFlight)
        throw new Error("A previous capability execution is still in flight; reconcile it before retrying");
      this.inFlight = true;
      try {
        const capability = this.get(decision.invocation.capabilityId);
        if (capability.isAvailable && !await capability.isAvailable(context))
          throw new Error("Capability unavailable");
        checkAbort(context.signal);
        if (capability.descriptor.replayPolicy === "approval-required") {
          if (!this.options.approve || !await this.options.approve(immutableCopy(decision), context))
            throw new Error("Approval required or denied");
        }
        checkAbort(context.signal);
        await beforeExecute?.();
        checkAbort(context.signal);
        const result = await capability.execute(immutableCopy(decision.invocation.input), context);
        checkAbort(context.signal);
        assertJson(result);
        if (typeof result.ok !== "boolean")
          throw new Error("Invalid capability result");
        return immutableCopy(result);
      } finally {
        this.inFlight = false;
      }
    }
  };
  var AllowAllSafetyGuard = class {
    async validate(_decision, _context) {
      return { allowed: true };
    }
  };

  // packages/harness/dist/metrics.js
  var PolicyMetrics = class {
    decisions = 0;
    fallbackCalls = 0;
    policyHits = 0;
    policyMisses = 0;
    executedActions = 0;
    successCount = 0;
    totalReward = 0;
    recordDecision(source) {
      this.decisions += 1;
      if (source === "policy")
        this.policyHits += 1;
      else {
        this.policyMisses += 1;
        this.fallbackCalls += 1;
      }
    }
    recordOutcome(evaluation, executed) {
      if (executed)
        this.executedActions += 1;
      if (evaluation.success)
        this.successCount += 1;
      this.totalReward += evaluation.reward;
    }
    snapshot() {
      return {
        decisions: this.decisions,
        fallbackCalls: this.fallbackCalls,
        policyHits: this.policyHits,
        policyMisses: this.policyMisses,
        executedActions: this.executedActions,
        successCount: this.successCount,
        totalReward: this.totalReward,
        fallbackRatio: this.decisions === 0 ? 0 : this.fallbackCalls / this.decisions,
        policyHitRatio: this.decisions === 0 ? 0 : this.policyHits / this.decisions,
        successRate: this.decisions === 0 ? 0 : this.successCount / this.decisions,
        averageReward: this.decisions === 0 ? 0 : this.totalReward / this.decisions
      };
    }
  };

  // packages/harness/dist/session.js
  var import_core2 = __toESM(require_core(), 1);

  // packages/harness/dist/authorization.js
  var ExecutionAuthority = class {
    options;
    #permits = /* @__PURE__ */ new Map();
    #started = false;
    #completed;
    constructor(options) {
      this.options = options;
    }
    context(context) {
      this.options.assertActive();
      validateState(context.state);
      validateIntention(context.intention);
      if (stableStringify(context.intention) !== stableStringify(this.options.intention)) {
        throw new Error("Foreign decision intention");
      }
      return Object.freeze({
        decisionId: this.options.decisionId,
        state: context.state,
        intention: context.intention,
        signal: this.options.signal
      });
    }
    listAvailable(context) {
      return this.options.capabilities.listAvailable(this.context(context));
    }
    async authorize(value) {
      this.options.assertActive();
      if (this.#started)
        throw new Error("A capability was already dispatched for this decision");
      const selected = immutableCopy(value);
      this.context(selected.context);
      validateDecision(selected.decision);
      this.options.capabilities.validate(selected.decision);
      const result = await this.options.guard.validate(selected.decision, selected.context);
      this.options.assertActive();
      if (result.allowed !== true)
        throw new Error(result.reason ?? "Decision rejected by safety guard");
      const authorizationId = globalThis.crypto.randomUUID();
      this.#permits.set(authorizationId, selected);
      return Object.freeze({ authorizationId });
    }
    async execute(receipt) {
      this.options.assertActive();
      const selected = receipt && this.#permits.get(receipt.authorizationId);
      if (!selected)
        throw new Error("Missing, foreign or consumed execution authorization");
      if (this.#started)
        throw new Error("A capability was already dispatched for this decision");
      this.#started = true;
      this.#permits.clear();
      const result = await this.options.capabilities.execute(selected.decision, this.context(selected.context), async () => {
        const current = immutableCopy(await this.options.observer.observe());
        validateState(current);
        this.options.assertActive();
        if (stableStringify(current) !== stableStringify(selected.context.state)) {
          throw new Error("Stale decision: observed world changed before execution");
        }
      });
      this.options.assertActive();
      this.#completed = immutableCopy({ ...selected, result });
      return this.#completed;
    }
    assertExecuted(value) {
      this.options.assertActive();
      const actual = immutableCopy({ context: value.context, decision: value.decision, candidate: value.candidate, result: value.result });
      if (!this.#completed || stableStringify(actual) !== stableStringify(this.#completed)) {
        throw new Error("Experience does not belong to a completed execution in this session");
      }
    }
    close() {
      this.#permits.clear();
    }
  };

  // packages/harness/dist/session.js
  var HarnessSession = class extends import_core2.Session {
    options;
    authority;
    #packets = /* @__PURE__ */ new WeakMap();
    #visited = /* @__PURE__ */ new Set();
    #closed = false;
    #executing = false;
    #trace;
    constructor(graph, options) {
      super(graph);
      this.options = options;
      this.authority = new ExecutionAuthority({
        decisionId: this.frame.decisionId,
        intention: this.intention,
        signal: this.signal,
        capabilities: options.capabilities,
        guard: options.guard,
        observer: this.services.observer,
        assertActive: () => this.assertActive()
      });
    }
    get frame() {
      return this.options.frame;
    }
    get intention() {
      return this.options.intention;
    }
    get signal() {
      return this.options.signal;
    }
    get startedAt() {
      return this.options.startedAt;
    }
    get services() {
      return this.options.services;
    }
    get trace() {
      return this.#trace;
    }
    now() {
      return this.options.clock();
    }
    hasVisited(node) {
      return this.#visited.has(node);
    }
    assertActive() {
      checkAbort(this.signal);
      if (this.#closed)
        throw new Error("Decision session closed");
    }
    packet(type, value) {
      this.assertActive();
      const packet = Object.freeze({ decisionId: this.frame.decisionId });
      this.#packets.set(packet, { type, value: immutableCopy(value) });
      return packet;
    }
    take(packet, type) {
      this.assertActive();
      const data = typeof packet === "object" && packet !== null ? this.#packets.get(packet) : void 0;
      if (!data || data.type !== type)
        throw new Error("Missing, duplicated, mistyped or foreign decision packet");
      this.#packets.delete(packet);
      return data.value;
    }
    /** Generic lifecycle wrapper. The supplied node operation owns all business logic. */
    async invoke(node, operation) {
      this.assertActive();
      if (!this.graph.nodes.includes(node) || this.#visited.has(node) || this.#executing)
        throw new Error("Foreign, duplicated or reentrant node execution");
      this.#visited.add(node);
      this.#executing = true;
      this.emit(node.stage, "start");
      try {
        await abortable(operation, this.signal);
        this.assertActive();
        this.emit(node.stage, "complete");
        try {
          this.options.onNode?.(String(node.id), node.stage);
        } catch {
        }
      } catch (error) {
        this.emit(node.stage, "error", String(error));
        throw error;
      } finally {
        this.#executing = false;
      }
    }
    assertCanComplete() {
      this.assertActive();
      if (this.#trace)
        throw new Error("Decision already recorded");
    }
    complete(trace) {
      this.assertCanComplete();
      if (trace.decisionId !== this.frame.decisionId)
        throw new Error("Foreign decision trace");
      this.#trace = immutableCopy(trace);
    }
    close() {
      this.#closed = true;
      this.authority.close();
    }
    emit(stage, status, message) {
      try {
        this.options.onStage?.({ decisionId: this.frame.decisionId, stage, status, message });
      } catch {
      }
    }
    /** Compatibility with the current core async topological pass: drain its delivery queue. */
    publish(index, value) {
      this.assertActive();
      super.publish(index, value);
      for (const item of this.queue.splice(0)) {
        if (!(0, import_core2.isLinkRef)(item))
          throw new Error("Unexpected async scheduler event");
        this.deliverLinkRef(item);
      }
    }
  };

  // packages/harness/dist/runtime.js
  var AdaptivePolicyRuntime = class {
    options;
    metrics;
    safetyGuard;
    clock;
    idFactory;
    runs = /* @__PURE__ */ new WeakMap();
    issuedIds = /* @__PURE__ */ new Set();
    busy = false;
    constructor(options) {
      this.options = options;
      this.metrics = options.metrics ?? new PolicyMetrics();
      this.safetyGuard = options.safetyGuard ?? new AllowAllSafetyGuard();
      this.clock = options.clock ?? (() => Date.now());
      this.idFactory = options.idFactory ?? (() => `decision-${globalThis.crypto.randomUUID()}`);
      if (options.timeoutMs !== void 0 && (!Number.isFinite(options.timeoutMs) || options.timeoutMs <= 0))
        throw new Error("Invalid timeout");
    }
    async step(intention, signal, driver = this.options.driver) {
      checkAbort(signal);
      if (!driver)
        throw new Error("No harness graph configured: provide a driver in runtime options or step()");
      if (this.busy)
        throw new Error("A decision is already running");
      const savedIntention = immutableCopy(intention);
      validateIntention(savedIntention);
      const decisionId = this.idFactory();
      if (!decisionId || this.issuedIds.has(decisionId))
        throw new Error("Invalid or duplicate decision ID");
      this.issuedIds.add(decisionId);
      const frame = Object.freeze({ decisionId });
      this.busy = true;
      const controller = new AbortController();
      const cancel = () => controller.abort(signal?.reason ?? new Error("Execution cancelled"));
      signal?.addEventListener("abort", cancel, { once: true });
      const timer = setTimeout(() => controller.abort(new Error("Decision timeout")), this.options.timeoutMs ?? 1e4);
      const run = { frame, intention: savedIntention, signal: controller.signal, startedAt: this.clock() };
      this.runs.set(frame, run);
      try {
        await abortable(() => driver(this, frame), run.signal);
        checkAbort(run.signal);
        if (!run.session?.trace)
          throw new Error("Incomplete harness: no experience reached the recorder");
        return run.session.trace;
      } finally {
        clearTimeout(timer);
        signal?.removeEventListener("abort", cancel);
        run.session?.close();
        controller.abort(new Error("Decision session closed"));
        this.runs.delete(frame);
        this.busy = false;
      }
    }
    async executeGraph(graph, frame, onNode) {
      const run = this.runs.get(frame);
      if (!run)
        throw new Error("Unknown or closed decision session");
      checkAbort(run.signal);
      if (run.session)
        throw new Error("Decision graph already started");
      const session = new HarnessSession(graph, {
        ...run,
        clock: this.clock,
        onStage: this.options.onStage,
        onNode,
        services: {
          cueObserver: this.options.cueObserver,
          cueMode: this.options.cueMode,
          operatingContexts: this.options.operatingContexts,
          policy: this.options.policy,
          observer: this.options.observer,
          fallback: this.options.fallback,
          evaluator: this.options.evaluator,
          metrics: this.metrics
        },
        capabilities: this.options.capabilities,
        guard: this.safetyGuard
      });
      run.session = session;
      try {
        await graph.runAsync(0, session);
      } finally {
        session.close();
      }
    }
  };

  // packages/harness/dist/nodes.js
  var import_core3 = __toESM(require_core(), 1);
  var harnessPort = (slot, type) => ({ slot, type: `harness.${type}`, optional: false });
  var HarnessNode = class extends import_core3.RuntimeNode {
    stage;
    inputPorts;
    outputPorts;
    constructor(stage, inputPorts, outputPorts) {
      super();
      this.stage = stage;
      this.inputPorts = inputPorts;
      this.outputPorts = outputPorts;
    }
    isReady(session) {
      return !(session instanceof HarnessSession && session.hasVisited(this)) && super.isReady(session);
    }
    fire() {
      throw new Error("Harness nodes require asynchronous execution with a HarnessSession");
    }
    async fireAsync(session) {
      if (!(session instanceof HarnessSession))
        throw new Error("HarnessSession services must be provided before execution");
      await session.invoke(this, async () => {
        const incoming = this.inputPorts.map((port5) => ({ port: port5, packet: this.consumeLatest(session, port5.slot) })).filter((item) => item.packet !== void 0);
        if (incoming.length !== (this.inputPorts.length ? 1 : 0))
          throw new Error("Missing or duplicated decision input");
        const input = incoming.length ? session.take(incoming[0].packet, incoming[0].port.type) : void 0;
        const output = await this.execute(input, session);
        session.assertActive();
        if (output === void 0) {
          if (this.outputPorts.length)
            throw new Error("Missing node output");
          return;
        }
        const port4 = this.outputPorts.find((port5) => port5.slot === output.slot);
        if (!port4)
          throw new Error("Unknown node output slot");
        this.publishAll(session, output.slot, session.packet(port4.type, output.value));
      });
    }
  };
  var StateObserverNode = class extends HarnessNode {
    constructor() {
      super("observe", [], [harnessPort("state", "state")]);
    }
    async execute(_input, session) {
      const state = immutableCopy(await session.services.observer.observe());
      validateState(state);
      return { slot: "state", value: state };
    }
  };
  var DecisionContextNode = class extends HarnessNode {
    constructor() {
      super("context", [harnessPort("state", "state")], [harnessPort("context", "context")]);
    }
    async execute(state, session) {
      return { slot: "context", value: createDecisionContext(state, session.intention) };
    }
  };
  var PolicyLookupNode = class extends HarnessNode {
    constructor() {
      super("lookup", [harnessPort("context", "context")], [harnessPort("candidates", "candidates")]);
    }
    async execute(context, session) {
      return { slot: "candidates", value: { context, candidates: session.services.policy.findCandidateActions(context.state, context.intention) } };
    }
  };
  var ConfidenceGateNode = class extends HarnessNode {
    constructor() {
      super("gate", [harnessPort("candidates", "candidates")], [harnessPort("policy", "decision"), harnessPort("fallback", "uncertain")]);
    }
    async execute(input, session) {
      const available = await session.authority.listAvailable(input.context);
      const candidate2 = input.candidates.find((c) => c.eligible && available.some((a) => a.id === c.invocation.capabilityId));
      if (!candidate2)
        return { slot: "fallback", value: input };
      const selected = { context: input.context, candidate: candidate2, decision: {
        source: "policy",
        action: candidate2.action,
        invocation: candidate2.invocation,
        expectedOutcome: candidate2.expectedOutcome
      } };
      return { slot: "policy", value: selected };
    }
  };
  var FallbackRequestNode = class extends HarnessNode {
    constructor() {
      super("request", [harnessPort("fallback", "uncertain")], [harnessPort("request", "request")]);
    }
    async execute(input, session) {
      return { slot: "request", value: { context: input.context, request: {
        decisionId: session.frame.decisionId,
        state: input.context.state,
        intention: input.context.intention,
        allowedCapabilities: await session.authority.listAvailable(input.context),
        candidates: input.candidates,
        recentFailures: session.services.policy.getRecentFailures(input.context.state, input.context.intention)
      } } };
    }
  };
  var ReasoningProviderNode = class extends HarnessNode {
    constructor() {
      super("reason", [harnessPort("request", "request")], [harnessPort("decision", "decision")]);
    }
    async execute(input, session) {
      const proposed = await session.services.fallback.resolve(Object.freeze({ ...input.request, signal: session.signal }));
      session.assertActive();
      validateDecision(proposed);
      if (!input.request.allowedCapabilities.some((c) => c.id === proposed.invocation.capabilityId))
        throw new Error("Provider proposed a capability outside the allowlist");
      return { slot: "decision", value: { context: input.context, decision: { ...proposed, source: "fallback" } } };
    }
  };
  var DecisionMergeNode = class extends HarnessNode {
    constructor() {
      super("merge", [harnessPort("policy", "decision"), harnessPort("reasoning", "decision")], [harnessPort("decision", "merged")]);
    }
    isReady(session) {
      return this.enabled && !(session instanceof HarnessSession && session.hasVisited(this)) && session.graph.links.some((link, index) => link.ofin === this && session.linkStates[index].ready);
    }
    async execute(selected, session) {
      session.services.metrics.recordDecision(selected.decision.source);
      return { slot: "decision", value: selected };
    }
  };
  var SafetyGuardNode = class extends HarnessNode {
    constructor() {
      super("guard", [harnessPort("decision", "merged")], [harnessPort("authorized", "authorized")]);
    }
    async execute(selected, session) {
      return { slot: "authorized", value: await session.authority.authorize(selected) };
    }
  };
  var CapabilityExecutorNode = class extends HarnessNode {
    constructor() {
      super("execute", [harnessPort("authorized", "authorized")], [harnessPort("result", "result")]);
    }
    async execute(receipt, session) {
      return { slot: "result", value: await session.authority.execute(receipt) };
    }
  };
  var OutcomeObserverNode = class extends HarnessNode {
    constructor() {
      super("observe-after", [harnessPort("result", "result")], [harnessPort("outcome", "outcome")]);
    }
    async execute(input, session) {
      const stateAfter = immutableCopy(await session.services.observer.observe());
      validateState(stateAfter);
      return { slot: "outcome", value: { ...input, stateAfter } };
    }
  };
  var OutcomeEvaluatorNode = class extends HarnessNode {
    constructor() {
      super("evaluate", [harnessPort("outcome", "outcome")], [harnessPort("experience", "experience")]);
    }
    async execute(input, session) {
      const evaluation = immutableCopy(await session.services.evaluator.evaluate({
        context: input.context,
        decision: input.decision,
        stateAfter: input.stateAfter,
        result: input.result
      }));
      validateEvaluation(evaluation);
      return { slot: "experience", value: { ...input, evaluation } };
    }
  };
  var ExperienceRecorderNode = class extends HarnessNode {
    constructor() {
      super("record", [harnessPort("experience", "experience")], []);
    }
    async execute(input, session) {
      session.assertCanComplete();
      session.authority.assertExecuted(input);
      validateState(input.stateAfter);
      validateEvaluation(input.evaluation);
      const { policy, metrics } = session.services;
      const { context, decision, stateAfter, result, evaluation, candidate: candidate2 } = input;
      policy.recordExperience({
        decisionId: session.frame.decisionId,
        experienceId: `experience:${session.frame.decisionId}`,
        stateBefore: context.state,
        intention: context.intention,
        decision,
        stateAfter,
        result,
        evaluation,
        observedAt: session.now()
      });
      metrics.recordOutcome(evaluation, true);
      session.complete({
        decisionId: session.frame.decisionId,
        source: decision.source,
        stateBefore: context.state,
        intention: context.intention,
        decision,
        candidateScore: candidate2?.score,
        candidateConfidence: candidate2?.confidence,
        result,
        stateAfter,
        evaluation,
        transitionAfter: policy.getTransitionStats(context.state, context.intention, decision.invocation),
        startedAt: session.startedAt,
        completedAt: session.now()
      });
    }
  };

  // packages/harness/dist/graph.js
  var import_core5 = __toESM(require_core(), 1);

  // packages/harness/dist/consolidation.js
  var DEFAULT_CONSOLIDATION_CONFIG = Object.freeze({
    minimumObservations: 6,
    minimumDurationMs: 5e3,
    maximumGapMs: 2e3,
    maximumPendingObservations: 128
  });
  function validateConsolidationConfig(config) {
    if (!config || Object.keys(config).some((k) => !Object.hasOwn(DEFAULT_CONSOLIDATION_CONFIG, k)) || !Number.isSafeInteger(config.minimumObservations) || config.minimumObservations < 2 || !Number.isSafeInteger(config.maximumPendingObservations) || config.maximumPendingObservations < config.minimumObservations || config.maximumPendingObservations > 4096 || !Number.isFinite(config.minimumDurationMs) || config.minimumDurationMs <= 0 || !Number.isFinite(config.maximumGapMs) || config.maximumGapMs <= 0)
      throw new Error("Invalid consolidation configuration");
  }
  function advanceConsolidation(previous, signatureKey, observedAt, config) {
    if (!Number.isFinite(observedAt) || previous && observedAt < previous.lastObservedAt) {
      throw new Error("Consolidation requires a monotonic observation clock");
    }
    const continuing = signatureKey !== void 0 && previous?.signatureKey === signatureKey && observedAt - previous.lastObservedAt <= config.maximumGapMs && previous.observations < config.maximumPendingObservations;
    const startedAt = continuing ? previous.startedAt : observedAt;
    const observations = signatureKey === void 0 ? 0 : continuing ? previous.observations + 1 : 1;
    const durationMs = observedAt - startedAt;
    return Object.freeze({
      ...signatureKey === void 0 ? {} : { signatureKey },
      startedAt,
      lastObservedAt: observedAt,
      observations,
      durationMs,
      status: signatureKey === void 0 ? "idle" : observations >= config.minimumObservations && durationMs >= config.minimumDurationMs ? "stable" : "pending"
    });
  }
  function validateConsolidationSupport(times, config) {
    if (times.length < config.minimumObservations || times.length > config.maximumPendingObservations || times.some((t, i) => !Number.isFinite(t) || i > 0 && (t < times[i - 1] || t - times[i - 1] > config.maximumGapMs)) || times[times.length - 1] - times[0] < config.minimumDurationMs)
      throw new Error("Insufficient temporal consolidation support");
  }

  // packages/harness/dist/contextual-policy.js
  var import_core4 = __toESM(require_core(), 1);

  // packages/harness/dist/operating-types.js
  var DEFAULT_OPERATING_CONTEXT_CONFIG = Object.freeze({
    noveltyConfirmations: 2,
    maximumModesPerScope: 8
  });
  function validateOperatingConfig(config) {
    if (config.consolidation) {
      validateConsolidationConfig(config.consolidation);
      if (config.consolidation.minimumObservations < config.noveltyConfirmations)
        throw new Error("Consolidation cannot weaken novelty confirmation");
    }
    if (!Number.isSafeInteger(config.noveltyConfirmations) || config.noveltyConfirmations < 2 || config.noveltyConfirmations > 32 || !Number.isSafeInteger(config.maximumModesPerScope) || config.maximumModesPerScope < 1 || config.maximumModesPerScope > 64) {
      throw new Error("Invalid operating-context configuration");
    }
  }

  // packages/harness/dist/contextual-policy.js
  var json = (value) => stableStringify(value);
  var unique = (items, key2) => [...new Map(items.map((item) => [key2(item), item])).values()];
  var operatingModeId = (scope, signature) => "mode:" + json([scope, signature]);
  var OperatingModeNode = class extends import_core4.GraphNode {
    mode;
    constructor(mode) {
      super();
      this.mode = mode;
      this.id = mode.id;
      this.type = "Harness.Memory:operating-mode";
    }
  };
  var MemoryRelationLink = class extends import_core4.GraphOLink {
    relation;
    constructor(from, to, relation) {
      super(from, to);
      this.relation = relation;
      this.id = relation.id;
      this.type = "Harness.Memory:" + relation.kind;
    }
  };
  var ContextualPolicyGraph = class _ContextualPolicyGraph extends PolicyGraph {
    modelId;
    learned = new PolicyGraph(void 0, this.plasticity);
    legacy = new PolicyGraph(void 0, this.plasticity).snapshot();
    ledger = [];
    modeNodes = /* @__PURE__ */ new Map();
    revisionSequence = 0;
    contextConfig;
    constructor(modelId, config = DEFAULT_OPERATING_CONTEXT_CONFIG, plasticity = DEFAULT_PLASTICITY_CONFIG) {
      super(void 0, plasticity);
      this.modelId = modelId;
      if (typeof modelId !== "string" || !modelId)
        throw new Error("Missing effect signature model ID");
      validateOperatingConfig(config);
      this.contextConfig = immutableCopy(config);
    }
    modes(scope) {
      return [...this.modeNodes.values()].map((n) => n.mode).filter((m) => scope === void 0 || m.scope === scope);
    }
    mode(id) {
      return this.modeNodes.get(id)?.mode;
    }
    confirmMode(scope, signature, observedAt, consolidationSupport) {
      const id = operatingModeId(scope, signature), existing = this.mode(id);
      if (existing)
        return existing;
      if (this.modes(scope).length >= this.contextConfig.maximumModesPerScope)
        return void 0;
      const mode = immutableCopy({
        id,
        scope,
        signature,
        label: "M" + (this.modeNodes.size + 1),
        createdAt: observedAt,
        ...consolidationSupport ? { consolidationSupport: [...consolidationSupport] } : {}
      });
      this.validateModeSupport(mode);
      this.modeNodes.set(id, new OperatingModeNode(mode));
      return mode;
    }
    validateModeSupport(mode) {
      const config = this.contextConfig.consolidation;
      if (!config) {
        if (mode.consolidationSupport !== void 0)
          throw new Error("Unexpected consolidation support");
        return;
      }
      const ids = mode.consolidationSupport;
      if (!Array.isArray(ids) || new Set(ids).size !== ids.length)
        throw new Error("Missing or duplicate consolidation support");
      const evidence = ids.map((id) => this.evidence(id));
      if (evidence.some((e) => e.context.key !== mode.scope || json(e.attribution?.signature) !== json(mode.signature)) || evidence.at(-1)?.observedAt !== mode.createdAt)
        throw new Error("Foreign consolidation support");
      validateConsolidationSupport(evidence.map((e) => e.observedAt), config);
    }
    findCandidateActions(state, intention, modeId) {
      const scope = contextKey(state, intention);
      const modes = modeId ? this.modes(scope).filter((m) => m.id === modeId) : this.modes(scope);
      return modes.flatMap((mode) => this.learned.findCandidateActions(state, intention, mode.id).map((candidate2) => ({ ...candidate2, eligible: !!modeId && candidate2.eligible })));
    }
    getTransitionStats(state, intention, invocation, modeId) {
      return modeId ? this.learned.getTransitionStats(state, intention, invocation, modeId) : void 0;
    }
    getKnownContexts() {
      return this.snapshot().contexts.slice();
    }
    getKnownStates() {
      return unique(this.getKnownContexts().map((c) => c.state), (s) => s.id);
    }
    getOutgoingTransitions(state, intention) {
      return this.findCandidateActions(state, intention);
    }
    getActionHistory(actionId) {
      return this.ledger.filter((e) => e.decision.action.id === actionId);
    }
    getRecentFailures(state, intention, limit = 5) {
      const scope = contextKey(state, intention);
      return this.ledger.filter((e) => contextKey(e.context.state, e.context.intention) === scope && !e.evaluation.success).slice(-limit).reverse();
    }
    recordExperience(_input) {
      throw new Error("Contextual memory requires an OperatingContextTracker and contextual recorder");
    }
    appendEvidence(input, before, signature) {
      input = immutableCopy(input);
      validateState(input.stateBefore);
      validateState(input.stateAfter);
      validateIntention(input.intention);
      validateDecision(input.decision);
      validateEvaluation(input.evaluation);
      if (!input.result || typeof input.result.ok !== "boolean")
        throw new Error("Invalid execution result");
      const id = input.experienceId ?? "experience:" + crypto.randomUUID(), observedAt = input.observedAt ?? Date.now();
      if (typeof id !== "string" || !id || !Number.isFinite(observedAt) || !["policy", "fallback"].includes(input.decision.source) || this.ledger.some((e) => e.id === id))
        throw new Error("Invalid or duplicate experience");
      const context = createDecisionContext(input.stateBefore, input.intention);
      if (before.scope !== context.key)
        throw new Error("Foreign operating scope");
      const current = { status: "pending", reason: "Awaiting attribution", sequence: ++this.revisionSequence };
      const experience = immutableCopy({
        id,
        decisionId: input.decisionId,
        context,
        decision: input.decision,
        stateAfter: input.stateAfter,
        result: input.result,
        evaluation: input.evaluation,
        observedAt,
        attribution: { before, signature, current, revisions: [current] },
        ...input.cues ? { cues: input.cues } : {}
      });
      this.ledger.push(experience);
      return experience;
    }
    /** Explicit, audited correction. Rebuild EMA projections so old evidence is removed from its former branch. */
    attribute(id, status, modeId, reason) {
      const index = this.ledger.findIndex((e) => e.id === id), previous = this.ledger[index];
      if (!previous?.attribution || typeof reason !== "string" || !reason)
        throw new Error("Unknown contextual experience or missing attribution reason");
      if (!["pending", "confirmed", "anomaly", "unresolved", "revised", "transient"].includes(status))
        throw new Error("Invalid attribution status");
      const mode = modeId ? this.mode(modeId) : void 0;
      if (modeId && (!mode || mode.scope !== previous.context.key))
        throw new Error("Foreign attribution mode");
      if (["confirmed", "anomaly", "revised"].includes(status) !== !!modeId)
        throw new Error("Invalid attribution status");
      if (status === "confirmed" && json(mode.signature) !== json(previous.attribution.signature))
        throw new Error("Contradictory confirmed attribution");
      const current = { status, modeId, reason, sequence: ++this.revisionSequence };
      const next = immutableCopy({ ...previous, attribution: {
        ...previous.attribution,
        current,
        revisions: [...previous.attribution.revisions, current]
      } });
      this.ledger[index] = next;
      if (previous.attribution.current.modeId)
        this.rebuildLearning();
      else if (modeId) {
        if (this.ledger.slice(index + 1).some((e) => e.attribution?.current.modeId))
          this.rebuildLearning();
        else
          this.learn(next);
      }
      return next;
    }
    evidence(id) {
      const item = this.ledger.find((e) => e.id === id);
      if (!item)
        throw new Error("Unknown experience");
      return item;
    }
    reconsiderUnresolved(mode) {
      for (const item of [...this.ledger]) {
        if (item.context.key === mode.scope && item.attribution && ["pending", "unresolved"].includes(item.attribution.current.status) && json(item.attribution.signature) === json(mode.signature)) {
          this.attribute(item.id, "confirmed", mode.id, "Subsequent consistent observations established this hypothesis");
        }
      }
    }
    learn(experience) {
      const modeId = experience.attribution?.current.modeId;
      if (!modeId)
        return;
      this.learned.recordExperience({
        experienceId: experience.id,
        decisionId: experience.decisionId,
        stateBefore: experience.context.state,
        intention: experience.context.intention,
        operatingContextId: modeId,
        decision: experience.decision,
        stateAfter: experience.stateAfter,
        result: experience.result,
        evaluation: experience.evaluation,
        observedAt: experience.observedAt
      });
    }
    rebuildLearning() {
      this.learned = new PolicyGraph(void 0, this.plasticity);
      for (const experience of this.ledger)
        this.learn(experience);
    }
    collections() {
      const learned = this.learned.snapshot();
      return {
        contexts: unique([...this.legacy.contexts, ...this.ledger.map((e) => e.context), ...learned.contexts], (c) => c.key),
        actions: unique([...this.legacy.actions, ...this.ledger.map((e) => e.decision.action)], (a) => a.id),
        capabilities: unique([...this.legacy.capabilities, ...this.ledger.map((e) => ({
          id: e.decision.invocation.capabilityId,
          description: e.decision.invocation.capabilityId
        }))], (c) => c.id),
        transitions: [...this.legacy.transitions, ...learned.transitions],
        bindings: unique([...this.legacy.bindings, ...this.ledger.map((e) => ({
          actionId: e.decision.action.id,
          capabilityId: e.decision.invocation.capabilityId
        }))], (b) => json([b.actionId, b.capabilityId])),
        experiences: this.ledger
      };
    }
    relations() {
      const links = [];
      const add = (from, to, kind) => links.push({ id: json([from, kind, to]), from, to, kind });
      for (const context of this.learned.getKnownContexts())
        add(context.operatingContextId, "context:" + context.key, "appliesTo");
      for (const e of this.ledger) {
        if (!e.attribution)
          continue;
        const id = "experience:" + e.id, { before, current, signature } = e.attribution;
        add(id, "context:" + e.context.key, "observedIn");
        add(id, "action:" + e.decision.action.id, "executed");
        if (before.modeId) {
          add(id, before.modeId, "assumed");
          if (signature !== null && json(signature) !== json(this.mode(before.modeId).signature))
            add(id, before.modeId, "contradicts");
        }
        if (current.modeId)
          add(id, current.modeId, "attributedTo");
      }
      return links;
    }
    snapshot() {
      return immutableCopy({
        version: 2,
        plasticity: this.plasticity,
        ...this.collections(),
        operatingMemory: { modelId: this.modelId, config: this.contextConfig, modes: this.modes(), relations: this.relations() }
      });
    }
    graphView() {
      const data = this.collections(), nodes = /* @__PURE__ */ new Map(), links = [];
      const add = (node) => nodes.set(String(node.id), node);
      data.contexts.forEach((c) => add(new ContextNode(c)));
      data.actions.forEach((a) => add(new ActionNode(a)));
      data.capabilities.forEach((c) => add(new CapabilityNode(c)));
      this.ledger.forEach((e) => add(new ExperienceNode(e)));
      this.modeNodes.forEach((node) => add(new OperatingModeNode(node.mode)));
      for (const t of data.transitions)
        links.push(new PolicyTransition(nodes.get("context:" + t.contextKey), nodes.get("action:" + t.actionId), t.key, t.invocation, t.stats, t.expectedOutcome));
      for (const b of data.bindings)
        links.push(new CapabilityBinding(nodes.get("action:" + b.actionId), nodes.get("capability:" + b.capabilityId)));
      for (const r of this.relations())
        links.push(new MemoryRelationLink(nodes.get(r.from), nodes.get(r.to), r));
      return new import_core4.GraphBuilder().withNodes(...nodes.values()).withLinks(...links).build();
    }
    static restore(snapshot, legacyModelId) {
      snapshot = immutableCopy(snapshot);
      if (snapshot.version === 1) {
        if (!legacyModelId)
          throw new Error("Specify the effect model when migrating V1");
        if (snapshot.contexts.some((c) => c.operatingContextId) || snapshot.experiences.some((e) => e.attribution))
          throw new Error("V1 documents cannot contain contextual metadata");
        const legacy = PolicyGraph.fromSnapshot(snapshot);
        const policy2 = new _ContextualPolicyGraph(legacyModelId, void 0, legacy.plasticity);
        policy2.legacy = legacy.snapshot();
        policy2.ledger = [...policy2.legacy.experiences];
        return policy2;
      }
      const memory = snapshot.operatingMemory;
      if (snapshot.version !== 2 || !memory || !Array.isArray(memory.modes) || !Array.isArray(memory.relations))
        throw new Error("Invalid contextual policy snapshot");
      const policy = new _ContextualPolicyGraph(memory.modelId, memory.config, snapshot.plasticity);
      PolicyGraph.fromSnapshot({ ...snapshot, version: 1 });
      for (const mode of memory.modes) {
        if (!mode.scope || typeof mode.scope !== "string" || mode.signature === null || typeof mode.label !== "string" || !mode.label || !Number.isFinite(mode.createdAt) || mode.id !== operatingModeId(mode.scope, mode.signature) || policy.modeNodes.has(mode.id) || policy.modes(mode.scope).length >= policy.contextConfig.maximumModesPerScope)
          throw new Error("Invalid or duplicate operating mode");
        policy.modeNodes.set(mode.id, new OperatingModeNode(mode));
      }
      const revisions = /* @__PURE__ */ new Set();
      for (const e of snapshot.experiences) {
        const a = e.attribution;
        if (!a)
          continue;
        if (e.context.operatingContextId || a.before.scope !== e.context.key || a.before.scope !== contextKey(e.context.state, e.context.intention) || !["unknown", "recognized", "uncertain"].includes(a.before.status) || !Array.isArray(a.revisions) || !a.revisions.length || json(a.current) !== json(a.revisions.at(-1)))
          throw new Error("Invalid attribution history");
        if (a.before.status === "recognized" && !a.before.modeId || a.before.status === "unknown" && !!a.before.modeId || a.before.modeId && policy.mode(a.before.modeId)?.scope !== a.before.scope)
          throw new Error("Invalid prior hypothesis");
        let last = 0;
        for (const r of a.revisions) {
          if (!["pending", "confirmed", "anomaly", "unresolved", "revised", "transient"].includes(r.status) || !r.reason || !Number.isSafeInteger(r.sequence) || r.sequence <= last || revisions.has(r.sequence) || ["confirmed", "anomaly", "revised"].includes(r.status) !== !!r.modeId || r.modeId && policy.mode(r.modeId)?.scope !== a.before.scope || r.status === "confirmed" && json(policy.mode(r.modeId).signature) !== json(a.signature))
            throw new Error("Invalid attribution revision");
          last = r.sequence;
          revisions.add(last);
          policy.revisionSequence = Math.max(policy.revisionSequence, last);
        }
      }
      for (const mode of policy.modes()) {
        const support = snapshot.experiences.filter((e) => e.attribution?.before.scope === mode.scope && json(e.attribution.signature) === json(mode.signature));
        if (support.length < policy.contextConfig.noveltyConfirmations)
          throw new Error("Operating hypothesis has insufficient observed support");
      }
      for (const context of snapshot.contexts)
        if (context.operatingContextId && policy.mode(context.operatingContextId)?.scope !== contextKey(context.state, context.intention))
          throw new Error("Foreign conditional context");
      policy.legacy = {
        version: 1,
        plasticity: snapshot.plasticity,
        contexts: snapshot.contexts.filter((c) => !c.operatingContextId),
        actions: snapshot.actions.slice(),
        capabilities: snapshot.capabilities.slice(),
        bindings: snapshot.bindings.slice(),
        transitions: snapshot.transitions.filter((t) => !snapshot.contexts.find((c) => c.key === t.contextKey)?.operatingContextId),
        experiences: snapshot.experiences.filter((e) => !e.attribution)
      };
      policy.ledger = [...snapshot.experiences];
      for (const mode of policy.modes())
        policy.validateModeSupport(mode);
      policy.rebuildLearning();
      if (json(policy.snapshot().transitions) !== json(snapshot.transitions) || json(policy.relations()) !== json(memory.relations)) {
        throw new Error("Contextual projection does not match its evidence or provenance");
      }
      return policy;
    }
  };

  // packages/harness/dist/contextual-nodes.js
  function tracker(session) {
    const contexts = session.services.operatingContexts;
    if (!contexts || !(session.services.policy instanceof ContextualPolicyGraph) || contexts.policy !== session.services.policy) {
      throw new Error("Contextual nodes require the host's matching memory and operating-context tracker");
    }
    return contexts;
  }
  var ContextualPolicyLookupNode = class extends PolicyLookupNode {
    async execute(input, session) {
      const contexts = tracker(session), belief = contexts.belief(input.state, input.intention);
      const modeId = belief.status === "recognized" ? belief.modeId : void 0;
      const context = createDecisionContext(input.state, input.intention, modeId);
      return { slot: "candidates", value: { context, candidates: contexts.policy.findCandidateActions(input.state, input.intention, modeId) } };
    }
  };
  var ContextualExperienceRecorderNode = class extends ExperienceRecorderNode {
    async execute(input, session) {
      session.assertCanComplete();
      session.authority.assertExecuted(input);
      validateState(input.stateAfter);
      validateEvaluation(input.evaluation);
      const contexts = tracker(session), { context, decision, stateAfter, result, evaluation, candidate: candidate2 } = input;
      const prior = contexts.belief(context.state, context.intention);
      const before = context.cues?.basis === "cues" ? { scope: prior.scope, status: "recognized", modeId: context.operatingContextId } : context.cues?.basis === "uncertain" ? { ...prior, status: "uncertain" } : prior;
      const { experience, after } = contexts.record({
        decisionId: session.frame.decisionId,
        experienceId: "experience:" + session.frame.decisionId,
        stateBefore: context.state,
        intention: context.intention,
        decision,
        stateAfter,
        result,
        evaluation,
        observedAt: session.now(),
        cues: context.cues
      }, before);
      const modeId = experience.attribution.current.modeId;
      session.services.metrics.recordOutcome(evaluation, true);
      session.complete({
        decisionId: session.frame.decisionId,
        source: decision.source,
        stateBefore: context.state,
        intention: context.intention,
        decision,
        candidateScore: candidate2?.score,
        candidateConfidence: candidate2?.confidence,
        result,
        stateAfter,
        evaluation,
        transitionAfter: contexts.policy.getTransitionStats(context.state, context.intention, decision.invocation, modeId),
        operatingBefore: before,
        operatingAfter: after,
        attribution: experience.attribution,
        ...context.cues ? { cues: context.cues } : {},
        startedAt: session.startedAt,
        completedAt: session.now()
      });
    }
  };

  // packages/harness/dist/cue-nodes.js
  function observer(session) {
    const service = session.services.cueObserver;
    if (!service || service.policy !== session.services.policy || service.policy !== session.services.operatingContexts?.policy)
      throw new Error("Cue nodes require matching host services");
    const mode = session.services.cueMode ?? "shadow";
    if (!["shadow", "active"].includes(mode))
      throw new Error("Invalid cue run mode");
    return { service, mode };
  }
  var CueObserverNode = class extends HarnessNode {
    constructor() {
      super("cues", [harnessPort("context", "context")], [harnessPort("context", "context")]);
    }
    async execute(context, session) {
      const { service, mode } = observer(session);
      const assessment = service.assess(context);
      const basis = mode === "shadow" ? "shadow" : assessment.status === "recognized" ? "cues" : assessment.status === "learning" ? "effect-history" : "uncertain";
      return { slot: "context", value: { ...context, cues: { mode, basis, assessment } } };
    }
  };
  var CuePolicyLookupNode = class extends ContextualPolicyLookupNode {
    async execute(input, session) {
      const { service, mode } = observer(session), cues = input.cues;
      if (!cues || cues.mode !== mode)
        throw new Error("Missing cue observation");
      service.validateAssessment(input, cues.assessment);
      const expected = mode === "shadow" ? "shadow" : cues.assessment.status === "recognized" ? "cues" : cues.assessment.status === "learning" ? "effect-history" : "uncertain";
      if (cues.basis !== expected)
        throw new Error("Invalid cue selection basis");
      if (cues.basis === "shadow" || cues.basis === "effect-history") {
        const result = await super.execute(input, session);
        const value = result.value;
        return { ...result, value: { ...value, context: { ...value.context, cues } } };
      }
      const modeId = cues.basis === "cues" ? cues.assessment.modeId : void 0;
      const context = { ...createDecisionContext(input.state, input.intention, modeId), cues };
      return { slot: "candidates", value: { context, candidates: service.policy.findCandidateActions(input.state, input.intention, modeId) } };
    }
  };

  // packages/harness/dist/catalog.js
  var V1_HARNESS_NODES = [
    { type: "Harness.Observation:state", label: "Observer", ctor: StateObserverNode },
    { type: "Harness.Policy:context", label: "Contexte + intention", ctor: DecisionContextNode },
    { type: "Harness.Policy:lookup", label: "Chercher une policy", ctor: PolicyLookupNode },
    { type: "Harness.Policy:confidence-gate", label: "Confiance suffisante ?", ctor: ConfidenceGateNode },
    { type: "Harness.Reasoning:request", label: "Construire la demande", ctor: FallbackRequestNode },
    { type: "Harness.Reasoning:provider", label: "Raisonneur (mock)", ctor: ReasoningProviderNode },
    { type: "Harness.Policy:merge", label: "Fusion des branches", ctor: DecisionMergeNode },
    { type: "Harness.Safety:guard", label: "Valider + autoriser", ctor: SafetyGuardNode },
    { type: "Harness.Execution:capability", label: "Executer la capacite", ctor: CapabilityExecutorNode },
    { type: "Harness.Observation:outcome", label: "Observer le resultat", ctor: OutcomeObserverNode },
    { type: "Harness.Learning:evaluate", label: "Evaluer le progres", ctor: OutcomeEvaluatorNode },
    { type: "Harness.Learning:record", label: "Apprendre", ctor: ExperienceRecorderNode }
  ];
  var HARNESS_NODES = [
    ...V1_HARNESS_NODES,
    { type: "Harness.Observation:cues", label: "Observer les indices", ctor: CueObserverNode },
    { type: "Harness.Policy:cue-lookup", label: "Reconna\xEEtre les conditions", ctor: CuePolicyLookupNode },
    { type: "Harness.Policy:contextual-lookup", label: "Chercher selon le fonctionnement", ctor: ContextualPolicyLookupNode },
    { type: "Harness.Learning:contextual-record", label: "Attribuer et apprendre", ctor: ContextualExperienceRecorderNode }
  ];
  function createHarnessNode(type) {
    const entry = HARNESS_NODES.find((n) => n.type === type);
    if (!entry)
      throw new Error(`Unknown harness node type: ${type}`);
    const node = new entry.ctor();
    node.type = type;
    return node;
  }

  // packages/harness/dist/graph.js
  function parseHarnessDefinition(value, factory = createHarnessNode) {
    const def = immutableCopy(value);
    if (!def || def.version !== 1 || !def.intention?.id || !Array.isArray(def.nodes) || !Array.isArray(def.edges))
      throw new Error("Invalid harness document");
    validateIntention(def.intention);
    if (Object.keys(def).some((k) => !["version", "intention", "nodes", "edges"].includes(k)))
      throw new Error("Harness documents cannot contain runtime services or policy data");
    const ids = /* @__PURE__ */ new Set();
    for (const node of def.nodes) {
      if (!node.id || typeof node.id !== "string" || ids.has(node.id) || !Number.isFinite(node.x) || !Number.isFinite(node.y))
        throw new Error("Invalid or duplicate node");
      if (Object.keys(node).some((k) => !["id", "type", "x", "y", "enabled"].includes(k)))
        throw new Error("Unexpected node configuration");
      if (typeof node.type !== "string" || !node.type)
        throw new Error("Invalid node type");
      if (node.enabled !== void 0 && typeof node.enabled !== "boolean")
        throw new Error("Invalid enabled state");
      if (!(factory(node.type) instanceof HarnessNode))
        throw new Error("Factory must return a HarnessNode");
      ids.add(node.id);
    }
    const edgeKeys = /* @__PURE__ */ new Set();
    for (const edge of def.edges) {
      const key2 = JSON.stringify([edge.from, edge.output, edge.to, edge.input]);
      if (edgeKeys.has(key2))
        throw new Error("Invalid duplicate edge");
      edgeKeys.add(key2);
      if (!ids.has(edge.from) || !ids.has(edge.to) || typeof edge.input !== "string" || typeof edge.output !== "string")
        throw new Error("Invalid graph endpoint");
      if (Object.keys(edge).some((k) => !["from", "to", "input", "output"].includes(k)))
        throw new Error("Unexpected edge configuration");
    }
    return def;
  }
  function validateHarnessGraph(graph) {
    const { nodes, links } = graph;
    if (graph.mode !== "static")
      throw new Error("Harness execution requires a static graph");
    if (nodes.some((node) => !(node instanceof HarnessNode)))
      throw new Error("Graph must contain HarnessNodes");
    if (new Set(nodes).size !== nodes.length || new Set(nodes.map((n) => n.id)).size !== nodes.length)
      throw new Error("Duplicate node instance or ID");
    if (nodes.some((node) => !node.enabled))
      throw new Error("Disabled required node: re-enable every node before executing");
    for (const node of nodes)
      for (const ports of [node.inputPorts, node.outputPorts]) {
        if (new Set(ports.map((p) => p.slot)).size !== ports.length || ports.some((p) => typeof p.slot !== "string" || !p.slot || typeof p.type !== "string" || !p.type)) {
          throw new Error("Invalid or duplicate node port");
        }
      }
    for (const link of links) {
      if (!link.enabled || link.delayed)
        throw new Error("Disabled or delayed channels are not supported");
      const from = nodes.find((n) => n === link.oini), to = nodes.find((n) => n === link.ofin);
      if (!from || !to)
        throw new Error("Invalid graph endpoint");
      const output = from.outputPorts.find((p) => p.slot === link.slot);
      const input = to.inputPorts.find((p) => p.slot === link.toSlot);
      if (!output || !input || input.type !== output.type)
        throw new Error("Incompatible harness ports");
    }
    for (const node of nodes) {
      for (const port4 of node.inputPorts) {
        if (links.filter((l) => l.ofin === node && l.toSlot === port4.slot).length !== 1)
          throw new Error(`Missing or duplicate input: ${node.stage}.${port4.slot}`);
      }
      for (const port4 of node.outputPorts) {
        if (links.filter((l) => l.oini === node && l.slot === port4.slot).length !== 1)
          throw new Error(`Missing or duplicate output: ${node.stage}.${port4.slot}`);
      }
    }
    const sources = nodes.filter((n) => !n.inputPorts.length), sinks = nodes.filter((n) => !n.outputPorts.length);
    if (sources.length !== 1 || !(sources[0] instanceof StateObserverNode) || sinks.length !== 1 || !(sinks[0] instanceof ExperienceRecorderNode)) {
      throw new Error("A decision graph requires one observation source and one experience sink");
    }
    import_core5.Scheduler.GetStaticOrder(graph);
  }
  function compileHarnessGraph(value, factory = createHarnessNode) {
    const def = parseHarnessDefinition(value, factory);
    const nodes = def.nodes.map((saved) => {
      const node = factory(saved.type);
      if (!(node instanceof HarnessNode))
        throw new Error("Factory must return a HarnessNode");
      node.id = saved.id;
      node.type = saved.type;
      node.enabled = saved.enabled !== false;
      return node;
    });
    if (new Set(nodes).size !== nodes.length)
      throw new Error("Factory reused a node instance");
    const byId = new Map(nodes.map((node) => [String(node.id), node]));
    const builder = new import_core5.RuntimeGraphBuilder().withMode("static").withNodes(...nodes);
    for (const edge of def.edges)
      builder.withChannel(byId.get(edge.from), byId.get(edge.to), edge.output, edge.input);
    const graph = builder.build();
    validateHarnessGraph(graph);
    return graph;
  }
  function createRuntimeGraphDriver(graph, onNode) {
    validateHarnessGraph(graph);
    return (runtime, frame) => runtime.executeGraph(graph, frame, onNode);
  }
  function createGraphDriver(value, onNode, factory = createHarnessNode) {
    return createRuntimeGraphDriver(compileHarnessGraph(value, factory), onNode);
  }

  // packages/harness/dist/operating-context.js
  var OperatingContextTracker = class {
    policy;
    provider;
    scopes = /* @__PURE__ */ new Map();
    constructor(policy, provider) {
      this.policy = policy;
      this.provider = provider;
      if (provider.id !== policy.modelId)
        throw new Error("Effect signature model does not match the memory");
    }
    belief(state, intention) {
      const scope = contextKey(state, intention);
      return immutableCopy(this.scopes.get(scope)?.belief ?? { scope, status: "unknown" });
    }
    consolidation(state, intention) {
      const progress = this.scopes.get(contextKey(state, intention))?.consolidation;
      return progress ? immutableCopy(progress) : void 0;
    }
    /** A host can mark a missing or non-attributable observation without inventing an experience. */
    interrupt(state, intention, observedAt) {
      const config = this.policy.contextConfig.consolidation;
      if (!config)
        return;
      const scope = contextKey(state, intention), entry = this.scopes.get(scope);
      if (!entry)
        return;
      const progress = advanceConsolidation(entry.consolidation, void 0, observedAt, config);
      this.flushTemporal(entry, "Consolidation interrupted by a non-attributable observation");
      entry.consolidation = progress;
      entry.belief = { ...entry.belief, status: "uncertain" };
    }
    record(input, assumed) {
      const scope = contextKey(input.stateBefore, input.intention);
      const entry = this.scopes.get(scope) ?? { belief: { scope, status: "unknown" }, pending: [] };
      const signature = immutableCopy(this.provider.describe(immutableCopy({
        context: { key: scope, state: input.stateBefore, intention: input.intention },
        decision: input.decision,
        result: input.result,
        stateAfter: input.stateAfter,
        evaluation: input.evaluation
      })));
      const before = immutableCopy(assumed ?? entry.belief);
      if (before.scope !== scope || !["unknown", "recognized", "uncertain"].includes(before.status) || before.status === "recognized" && !before.modeId || before.status === "unknown" && before.modeId || before.modeId && this.policy.mode(before.modeId)?.scope !== scope)
        throw new Error("Invalid operating assumption");
      const signatureKey = signature === null ? void 0 : stableStringify(signature);
      const observedAt = input.observedAt ?? Date.now(), config = this.policy.contextConfig.consolidation;
      const progress = config ? advanceConsolidation(entry.consolidation, signatureKey, observedAt, config) : void 0;
      const experience = this.policy.appendEvidence({ ...input, observedAt }, before, signature);
      this.scopes.set(scope, entry);
      const known = signature === null ? void 0 : this.policy.mode(operatingModeId(scope, signature));
      if (progress)
        return this.recordTemporal(entry, experience, signature, before, progress, known?.id);
      if (known) {
        if (entry.pendingSignature === signatureKey) {
          for (const id of entry.pending)
            if (this.policy.evidence(id).attribution?.current.status === "pending") {
              this.policy.attribute(id, "confirmed", known.id, "Shared knowledge confirmed the pending observed effect");
            }
          entry.pending = [];
          entry.pendingSignature = void 0;
        } else
          this.flush(entry, "Isolated contradiction, not enough evidence for another operating context");
        this.policy.attribute(experience.id, "confirmed", known.id, "Observed effect matches a learned operating context");
        entry.belief = { scope, status: "recognized", modeId: known.id };
      } else if (signatureKey !== void 0) {
        if (entry.pendingSignature !== signatureKey)
          this.flush(entry, "Inconsistent novel effects");
        entry.pendingSignature = signatureKey;
        entry.pending.push(experience.id);
        entry.belief = { scope, status: "uncertain", modeId: before.modeId };
        if (entry.pending.length >= this.policy.contextConfig.noveltyConfirmations) {
          const mode = this.policy.confirmMode(scope, signature, experience.observedAt);
          if (mode) {
            for (const id of entry.pending)
              this.policy.attribute(id, "confirmed", mode.id, "Repeated consistent effects confirmed a new context");
            entry.pending = [];
            entry.pendingSignature = void 0;
            this.policy.reconsiderUnresolved(mode);
            entry.belief = { scope, status: "recognized", modeId: mode.id };
          } else
            this.flush(entry, "Context capacity reached; novelty cannot shelter an existing skill indefinitely");
        }
      } else {
        this.flush(entry, "Ambiguous evidence interrupted novelty confirmation");
        this.policy.attribute(experience.id, before.modeId ? "anomaly" : "unresolved", before.modeId, "Effect is ambiguous; retain a provisional attribution to the previous hypothesis when available");
        entry.belief = { scope, status: "uncertain", modeId: before.modeId };
      }
      return { experience: this.policy.evidence(experience.id), after: immutableCopy(entry.belief) };
    }
    recordTemporal(entry, experience, signature, before, progress, knownId) {
      const scope = before.scope;
      if (progress.observations <= 1 || entry.pendingSignature !== progress.signatureKey) {
        this.flushTemporal(entry, "Transient effect: persistence window interrupted or expired");
      }
      entry.consolidation = progress;
      if (knownId) {
        for (const id of entry.pending)
          if (this.policy.evidence(id).attribution?.current.status === "pending") {
            this.policy.attribute(id, "confirmed", knownId, "Current contiguous evidence matches an already consolidated context");
          }
        entry.pending = [];
        entry.pendingSignature = void 0;
        this.policy.attribute(experience.id, "confirmed", knownId, "Observed effect matches a consolidated context");
        entry.belief = { scope, status: "recognized", modeId: knownId };
      } else if (signature !== null) {
        entry.pendingSignature = progress.signatureKey;
        entry.pending.push(experience.id);
        entry.belief = { scope, status: "uncertain", modeId: before.modeId };
        if (progress.status === "stable") {
          const mode = this.policy.confirmMode(scope, signature, experience.observedAt, entry.pending);
          if (mode) {
            for (const id of entry.pending)
              this.policy.attribute(id, "confirmed", mode.id, "Coherent effects persisted across the required observation duration");
            entry.pending = [];
            entry.pendingSignature = void 0;
            entry.belief = { scope, status: "recognized", modeId: mode.id };
          } else {
            this.flushTemporal(entry, "Capacity reached: evidence retained without granting replay");
            entry.consolidation = void 0;
          }
        }
      } else {
        this.policy.attribute(experience.id, "unresolved", void 0, "Ambiguous effect: no causal credit assigned");
        entry.belief = { scope, status: "uncertain", modeId: before.modeId };
      }
      return { experience: this.policy.evidence(experience.id), after: immutableCopy(entry.belief) };
    }
    flushTemporal(entry, reason) {
      for (const id of entry.pending)
        if (this.policy.evidence(id).attribution?.current.status === "pending") {
          this.policy.attribute(id, "transient", void 0, reason);
        }
      entry.pending = [];
      entry.pendingSignature = void 0;
    }
    flush(entry, reason) {
      for (const id of entry.pending) {
        const pending = this.policy.evidence(id), modeId = pending.attribution.before.modeId;
        if (pending.attribution.current.status !== "pending")
          continue;
        this.policy.attribute(id, modeId ? "anomaly" : "unresolved", modeId, reason);
      }
      entry.pending = [];
      entry.pendingSignature = void 0;
    }
  };

  // packages/harness/dist/cue-types.js
  var DEFAULT_CUE_CONFIG = Object.freeze({
    samplesPerMode: 24,
    minimumSamples: 3,
    recencyDecay: 0.92,
    minimumRelevance: 0.1,
    maximumDistance: 0.35,
    minimumMargin: 0.2,
    minimumCoverage: 0.8
  });

  // packages/harness/dist/cue-observer.js
  var import_core6 = __toESM(require_core(), 1);
  var json2 = (value) => stableStringify(value);
  var encoder = "harness.adaptive-metric.v1";
  var finite = (value) => typeof value === "number" && Number.isFinite(value);
  var record = (value) => !!value && typeof value === "object" && !Array.isArray(value);
  function validateCueConfiguration(schema, config) {
    if (!schema || typeof schema.id !== "string" || !schema.id || !Number.isSafeInteger(schema.version) || schema.version < 1 || Object.keys(schema).some((k) => !["id", "version", "fields"].includes(k)) || !Array.isArray(schema.fields) || schema.fields.length < 1 || schema.fields.length > 32)
      throw new Error("Invalid cue schema");
    const ids = /* @__PURE__ */ new Set(), paths = /* @__PURE__ */ new Set();
    for (const field of schema.fields) {
      if (!field || Object.keys(field).some((k) => !["id", "path", "scale"].includes(k)) || typeof field.id !== "string" || !field.id || ids.has(field.id) || !finite(field.scale) || field.scale <= 0 || !Array.isArray(field.path) || field.path.length < 1 || field.path.length > 8 || field.path.some((p) => typeof p !== "string" || !p || ["__proto__", "prototype", "constructor"].includes(p)))
        throw new Error("Invalid cue field");
      if (paths.has(json2(field.path)))
        throw new Error("Duplicate cue source");
      ids.add(field.id);
      paths.add(json2(field.path));
    }
    if (!config || !Number.isSafeInteger(config.samplesPerMode) || config.samplesPerMode < 3 || config.samplesPerMode > 256 || !Number.isSafeInteger(config.minimumSamples) || config.minimumSamples < 3 || config.minimumSamples > config.samplesPerMode || !finite(config.recencyDecay) || config.recencyDecay <= 0 || config.recencyDecay >= 1 || !finite(config.minimumRelevance) || config.minimumRelevance <= 0 || config.minimumRelevance >= 1 || !finite(config.maximumDistance) || config.maximumDistance <= 0 || config.maximumDistance > 10 || !finite(config.minimumMargin) || config.minimumMargin <= 0 || config.minimumMargin > 10 || !finite(config.minimumCoverage) || config.minimumCoverage <= 0 || config.minimumCoverage > 1 || Object.keys(config).some((k) => !Object.hasOwn(DEFAULT_CUE_CONFIG, k)))
      throw new Error("Invalid cue configuration");
  }
  var AdaptiveCueObserver = class _AdaptiveCueObserver {
    policy;
    schema;
    config;
    constructor(policy, schema, config = DEFAULT_CUE_CONFIG) {
      this.policy = policy;
      validateCueConfiguration(schema, config);
      this.schema = immutableCopy(schema);
      this.config = immutableCopy(config);
    }
    values(state) {
      return this.schema.fields.map((field) => {
        let value = state.features;
        for (const part of field.path)
          value = record(value) && Object.hasOwn(value, part) ? value[part] : void 0;
        if (value === void 0 || value === null)
          return null;
        if (!finite(value) || !finite(value / field.scale) || Math.abs(value / field.scale) > 1e6)
          throw new Error("Invalid numeric cue: " + field.id);
        return value / field.scale;
      });
    }
    model(context) {
      const scope = contextKey(context.state, context.intention);
      const experiences = this.policy.snapshot().experiences;
      const revision = experiences.reduce((max, e) => Math.max(max, e.attribution?.current.sequence ?? 0), 0);
      const groups = this.policy.modes(scope).map((mode) => {
        const samples = experiences.filter((e) => e.context.key === scope && e.attribution?.current.modeId === mode.id && ["confirmed", "revised"].includes(e.attribution.current.status) && json2(e.attribution.signature) === json2(mode.signature)).map((experience) => ({ experience, values: this.values(experience.context.state) })).filter((s) => s.values.some((v) => v !== null)).slice(-this.config.samplesPerMode);
        const means = [], variances = [];
        this.schema.fields.forEach((_field, i) => {
          const available = samples.map((s, order) => ({ value: s.values[i], weight: this.config.recencyDecay ** (samples.length - 1 - order) })).filter((s) => s.value !== null);
          if (available.length < this.config.minimumSamples) {
            means.push(null);
            variances.push(0);
            return;
          }
          const sum = available.reduce((n, s) => n + s.weight, 0);
          const mean = available.reduce((n, s) => n + s.value * s.weight, 0) / sum;
          means.push(mean);
          variances.push(available.reduce((n, s) => n + s.weight * (s.value - mean) ** 2, 0) / sum);
        });
        return { id: mode.id, samples, means, variances };
      }).filter((g) => g.samples.length >= this.config.minimumSamples);
      const relevance = this.schema.fields.map((_field, i) => {
        if (groups.length < 2 || groups.some((g) => g.means[i] === null))
          return 0;
        const means = groups.map((g) => g.means[i]);
        const spread = (Math.max(...means) - Math.min(...means)) ** 2;
        const noise = groups.reduce((n, g) => n + g.variances[i], 0) / groups.length;
        const weight = spread / (spread + 4 * noise + 0.01);
        return weight >= this.config.minimumRelevance ? weight : 0;
      });
      return { scope, revision, groups, relevance };
    }
    assess(context) {
      validateState(context.state);
      validateIntention(context.intention);
      const values = this.values(context.state), model = this.model(context);
      const total = model.relevance.reduce((a, b) => a + b, 0);
      const available = model.relevance.reduce((sum, w, i) => sum + (values[i] === null ? 0 : w), 0);
      const coverage = total ? available / total : 0;
      const distance = (other) => {
        let sum = 0, weight = 0;
        model.relevance.forEach((w, i) => {
          if (w && values[i] !== null && other[i] !== null) {
            sum += w * (values[i] - other[i]) ** 2;
            weight += w;
          }
        });
        return weight ? Math.sqrt(sum / weight) : null;
      };
      const candidates = model.groups.flatMap((group) => {
        const d = distance(group.means);
        if (d === null)
          return [];
        const nearest = group.samples.map((sample) => ({ id: sample.experience.id, distance: distance(sample.values) })).filter((s) => s.distance !== null).sort((a, b) => a.distance - b.distance || a.id.localeCompare(b.id)).slice(0, 3);
        return [{ modeId: group.id, distance: d, experienceIds: nearest.map((n) => n.id) }];
      }).sort((a, b) => a.distance - b.distance || a.modeId.localeCompare(b.modeId));
      const status = values.every((v) => v === null) ? "missing" : model.groups.length < 2 ? "learning" : total === 0 ? "ambiguous" : coverage < this.config.minimumCoverage ? "missing" : !candidates.length || candidates[0].distance > this.config.maximumDistance ? "novel" : candidates.length < 2 || candidates[1].distance - candidates[0].distance < this.config.minimumMargin ? "ambiguous" : "recognized";
      return immutableCopy({
        encoder,
        schemaKey: json2([this.schema, this.config]),
        modelRevision: model.revision,
        observationKey: json2(context.state),
        scope: model.scope,
        status,
        modeId: status === "recognized" ? candidates[0].modeId : void 0,
        features: this.schema.fields.map((field, i) => ({
          id: field.id,
          value: values[i],
          relevance: model.relevance[i],
          sourceRef: "state.features/" + field.path.map((p) => encodeURIComponent(p)).join("/")
        })),
        embedding: values.map((v, i) => v === null ? null : v * Math.sqrt(model.relevance[i])),
        coverage,
        candidates
      });
    }
    validateAssessment(context, assessment) {
      if (json2(assessment) !== json2(this.assess(context)))
        throw new Error("Stale or foreign cue assessment");
    }
    snapshot() {
      return immutableCopy({ version: 3, policy: this.policy.snapshot(), observer: { encoder, schema: this.schema, config: this.config } });
    }
    static restore(snapshot) {
      snapshot = immutableCopy(snapshot);
      if (!snapshot || snapshot.version !== 3 || snapshot.observer?.encoder !== encoder || Object.keys(snapshot).some((k) => !["version", "policy", "observer"].includes(k)) || Object.keys(snapshot.observer).some((k) => !["encoder", "schema", "config"].includes(k)))
        throw new Error("Invalid V3 cue memory");
      const observer2 = new _AdaptiveCueObserver(ContextualPolicyGraph.restore(snapshot.policy), snapshot.observer.schema, snapshot.observer.config);
      const ledger = observer2.policy.snapshot().experiences, seen = /* @__PURE__ */ new Set();
      for (const e of ledger) {
        if (e.cues) {
          const a = e.cues.assessment;
          if (!a || a.encoder !== encoder || a.schemaKey !== json2([observer2.schema, observer2.config]) || a.observationKey !== json2(e.context.state) || a.scope !== e.context.key || !["shadow", "active"].includes(e.cues.mode) || !["cues", "effect-history", "uncertain", "shadow"].includes(e.cues.basis) || !["learning", "missing", "ambiguous", "novel", "recognized"].includes(a.status) || !Number.isSafeInteger(a.modelRevision) || a.modelRevision < 0 || a.modelRevision >= (e.attribution?.revisions[0].sequence ?? 0) || !finite(a.coverage) || a.coverage < 0 || a.coverage > 1 || a.features?.length !== observer2.schema.fields.length || a.embedding?.length !== observer2.schema.fields.length || !Array.isArray(a.candidates) || a.status === "recognized" !== !!a.modeId || a.modeId && observer2.policy.mode(a.modeId)?.scope !== a.scope)
            throw new Error("Invalid stored cue assessment");
          const expectedBasis = e.cues.mode === "shadow" ? "shadow" : a.status === "recognized" ? "cues" : a.status === "learning" ? "effect-history" : "uncertain";
          if (e.cues.basis !== expectedBasis)
            throw new Error("Invalid stored cue decision basis");
          const values = observer2.values(e.context.state);
          a.features.forEach((f, i) => {
            const field = observer2.schema.fields[i];
            if (f.id !== field.id || f.value !== values[i] || !finite(f.relevance) || f.relevance < 0 || f.relevance > 1 || f.sourceRef !== "state.features/" + field.path.map((p) => encodeURIComponent(p)).join("/") || a.embedding[i] !== (f.value === null ? null : f.value * Math.sqrt(f.relevance)))
              throw new Error("Corrupt cue feature or embedding");
          });
          const candidates = /* @__PURE__ */ new Set();
          for (const c of a.candidates) {
            if (candidates.has(c.modeId) || observer2.policy.mode(c.modeId)?.scope !== a.scope || !finite(c.distance) || c.distance < 0 || !Array.isArray(c.experienceIds) || c.experienceIds.length > 3 || new Set(c.experienceIds).size !== c.experienceIds.length || c.experienceIds.some((id) => !seen.has(id) || observer2.policy.evidence(id).context.key !== a.scope))
              throw new Error("Invalid cue provenance");
            candidates.add(c.modeId);
          }
          if (a.modeId && a.candidates[0]?.modeId !== a.modeId)
            throw new Error("Invalid cue selection");
        }
        seen.add(e.id);
      }
      return observer2;
    }
    /** Read-only materialization: observed cue nodes and similarity links, not new evidence. */
    graphView(context) {
      const assessment = this.assess(context), base = this.policy.graphView();
      const nodes = new Map(base.nodes.map((n) => [String(n.id), n])), links = [...base.links];
      const observation = new import_core6.GraphNode();
      observation.id = "cue-observation:" + json2([assessment.scope, assessment.observationKey]);
      observation.type = "Harness.Memory:cue-observation";
      nodes.set(String(observation.id), observation);
      const connect = (from, to, kind) => {
        const link = new import_core6.GraphOLink(from, to);
        link.id = json2([from.id, kind, to.id]);
        link.type = "Harness.Memory:" + kind;
        links.push(link);
      };
      for (const feature of assessment.features) {
        const node = new CueFeatureNode(String(observation.id) + ":" + feature.id, feature);
        nodes.set(String(node.id), node);
        connect(observation, node, "measured");
        if (feature.value !== null && feature.relevance > 0)
          for (const c of assessment.candidates)
            for (const id of c.experienceIds) {
              connect(node, nodes.get("experience:" + id), "resembles");
            }
      }
      return new import_core6.GraphBuilder().withNodes(...nodes.values()).withLinks(...links).build();
    }
  };
  var CueFeatureNode = class extends import_core6.GraphNode {
    feature;
    constructor(id, feature) {
      super();
      this.feature = feature;
      this.id = id;
      this.type = "Harness.Memory:cue";
    }
  };

  // packages/harness/dist/temporal-evidence.js
  var import_core7 = __toESM(require_core(), 1);
  var DEFAULT_MODULATED_RESET_CONFIG = Object.freeze({ alpha: 0.8 });
  function validateModulatedResetConfig(config) {
    if (!config || Object.keys(config).some((k) => k !== "alpha") || !Number.isFinite(config.alpha) || config.alpha < 0 || config.alpha >= 1)
      throw new Error("Invalid modulated reset configuration");
  }
  var DEFAULT_TEMPORAL_EVIDENCE_CONFIG = Object.freeze({
    timeConstantSeconds: 3,
    threshold: 1.5,
    activationLifetimeSeconds: 3,
    maximumGapSeconds: 2,
    maximumScopes: 64,
    maximumModes: 8
  });
  function validateTemporalEvidenceConfig(config) {
    if (!config || Object.keys(config).some((k) => !Object.hasOwn(DEFAULT_TEMPORAL_EVIDENCE_CONFIG, k)) || ![config.timeConstantSeconds, config.threshold, config.activationLifetimeSeconds, config.maximumGapSeconds].every((n) => Number.isFinite(n) && n > 0) || config.threshold >= config.timeConstantSeconds || !Number.isSafeInteger(config.maximumScopes) || config.maximumScopes < 1 || config.maximumScopes > 256 || !Number.isSafeInteger(config.maximumModes) || config.maximumModes < 1 || config.maximumModes > 64) {
      throw new Error("Invalid temporal evidence configuration");
    }
  }
  var work = () => ({ sourceFirings: 0, integratorFirings: 0, readoutFirings: 0, inputEvents: 0, outputEvents: 0 });
  var port = (slot, type) => ({ slot, type, optional: false, kind: "stream", capacity: 1 });
  var EvidenceSource = class extends import_core7.RuntimeNode {
    inputPorts = [];
    outputPorts = [port("spike", "spike")];
    createNodeState() {
      return { linksReady: 0, amplitude: 0, firings: 0 };
    }
    reset(session) {
      const state = session.nodeStateOf(this);
      Object.assign(state, { amplitude: 0, firings: 0 });
      delete state.evidenceRate;
    }
    fire(session, t) {
      const state = session.nodeStateOf(this);
      state.firings++;
      const spike = { timestamp: t, amplitude: state.amplitude, source: this };
      if (state.evidenceRate !== void 0)
        spike.evidenceRate = state.evidenceRate;
      this.publishAll(session, "spike", spike);
    }
  };
  var CountedLif = class extends import_core7.LifNeuronNode {
    createNodeState() {
      return { ...super.createNodeState(), firings: 0 };
    }
    reset(session) {
      super.reset(session);
      session.nodeStateOf(this).firings = 0;
    }
    fire(session, t) {
      session.nodeStateOf(this).firings++;
      super.fire(session, t);
    }
  };
  var ModulatedResetLif = class extends CountedLif {
    alpha;
    constructor(alpha) {
      super();
      this.alpha = alpha;
    }
    createNodeState() {
      return { ...super.createNodeState(), evidenceRate: 0, lastResetPotential: null };
    }
    reset(session) {
      super.reset(session);
      Object.assign(session.nodeStateOf(this), { evidenceRate: 0, lastResetPotential: null });
    }
    fire(session, t) {
      const channels = this.inputChannels("spike").filter((c) => c.enabled);
      if (channels.length !== 1)
        throw new Error("Modulated reset requires one observed-evidence channel");
      const index = this.channelIndex(session, channels[0]);
      const token = index >= 0 ? session.peek(index) : void 0;
      if (!token || token.timestamp !== t || !Number.isFinite(token.amplitude) || typeof token.evidenceRate !== "number" || !Number.isFinite(token.evidenceRate) || token.evidenceRate < 0 || token.evidenceRate > 1)
        throw new Error("Invalid observed reset evidence");
      const state = session.nodeStateOf(this);
      state.evidenceRate = token.evidenceRate;
      const previousCount = state.spikeCount;
      super.fire(session, t);
      if (state.spikeCount !== previousCount) {
        state.lastResetPotential = this.threshold * this.alpha * state.evidenceRate;
        state.membranePotential = state.lastResetPotential;
      }
    }
  };
  var ContinuousEvidenceNode = class extends CountedLif {
    outputPorts = [port("level", "number")];
    fire(session, t) {
      super.fire(session, t);
      this.publishAll(session, "level", this.stateOf(session).membranePotential);
    }
  };
  var EvidenceReadout = class extends import_core7.RuntimeNode {
    mode;
    threshold;
    inputPorts;
    outputPorts = [];
    constructor(mode, threshold) {
      super();
      this.mode = mode;
      this.threshold = threshold;
      this.inputPorts = [port(mode !== "continuous" ? "spike" : "level", mode !== "continuous" ? "spike" : "number")];
    }
    createNodeState() {
      return { linksReady: 0, lastActivation: null, lastValue: 0, firings: 0 };
    }
    reset(session) {
      Object.assign(session.nodeStateOf(this), { lastActivation: null, lastValue: 0, firings: 0 });
    }
    fire(session, t) {
      const channel = this.inputChannels(this.inputPorts[0].slot)[0];
      const payload = session.consume(this.channelIndex(session, channel));
      const state = session.nodeStateOf(this);
      state.firings++;
      state.lastValue = this.mode !== "continuous" ? payload.amplitude : payload;
      if (this.mode !== "continuous" || state.lastValue >= this.threshold)
        state.lastActivation = t;
    }
  };
  var TemporalSessionStateNode = class extends import_core7.RuntimeNode {
    createNodeState() {
      return { linksReady: 0, banks: /* @__PURE__ */ new Map(), counts: work(), resets: 0, evictions: 0, graphBuilds: 0 };
    }
    reset(session) {
      Object.assign(session.nodeStateOf(this), this.createNodeState(), { cueCache: void 0 });
    }
  };
  var TemporalEvidenceNetwork = class {
    mode;
    config;
    resetModulation;
    stateNode = new TemporalSessionStateNode();
    /** A host may reset this core session to discard all temporal state, without touching the policy. */
    session = new import_core7.Session(new import_core7.RuntimeGraphBuilder().withNodes(this.stateNode).build());
    get sessionState() {
      return this.session.nodeStateOf(this.stateNode);
    }
    constructor(mode, config = DEFAULT_TEMPORAL_EVIDENCE_CONFIG, resetModulation) {
      this.mode = mode;
      if (!["continuous", "spikes", "spikes-modulated"].includes(mode))
        throw new Error("Unknown temporal propagation");
      validateTemporalEvidenceConfig(config);
      this.config = immutableCopy(config);
      if (mode === "spikes-modulated") {
        const reset = resetModulation === void 0 ? DEFAULT_MODULATED_RESET_CONFIG : resetModulation;
        validateModulatedResetConfig(reset);
        this.resetModulation = immutableCopy(reset);
      } else if (resetModulation !== void 0)
        throw new Error("Reset modulation requires its own variant");
    }
    create(ids) {
      const units = ids.map((id) => {
        const source = new EvidenceSource();
        const neuron = this.mode === "spikes-modulated" ? new ModulatedResetLif(this.resetModulation.alpha) : this.mode === "spikes" ? new CountedLif() : new ContinuousEvidenceNode();
        neuron.membraneTimeConstant = this.config.timeConstantSeconds;
        neuron.threshold = this.mode !== "continuous" ? this.config.threshold : Number.MAX_VALUE;
        neuron.refractoryPeriod = 0;
        const readout = new EvidenceReadout(this.mode, this.config.threshold);
        source.id = id + ":input";
        neuron.id = id + ":integrator";
        readout.id = id + ":readout";
        return { id, source, neuron, readout };
      });
      const builder = new import_core7.RuntimeGraphBuilder().withMode("dynamic");
      for (const unit of units)
        builder.withNodes(unit.source, unit.neuron, unit.readout).withChannel(unit.source, unit.neuron, "spike", "spike").withChannel(unit.neuron, unit.readout, this.mode !== "continuous" ? "spike" : "level");
      this.sessionState.graphBuilds++;
      return { units, session: new import_core7.Session(builder.build()), lastTime: null, previousRate: 0, winner: null };
    }
    /** Missing/novel evidence invalidates temporary activations, not durable experience. */
    forget(scope) {
      if (this.sessionState.banks.delete(scope))
        this.sessionState.resets++;
    }
    advance(scope, ids, winner, rate, timeSeconds) {
      if (!scope || !Number.isFinite(timeSeconds) || timeSeconds < 0 || !Number.isFinite(rate) || rate < 0 || rate > 1 || !ids.length || ids.length > this.config.maximumModes || new Set(ids).size !== ids.length || ids.some((id) => typeof id !== "string" || !id) || winner !== null && !ids.includes(winner) || winner === null && rate !== 0)
        throw new Error("Invalid temporal evidence input");
      let bank = this.sessionState.banks.get(scope);
      if (bank?.lastTime !== null && bank?.lastTime !== void 0 && timeSeconds <= bank.lastTime) {
        throw new Error("Temporal observations require an increasing clock");
      }
      const sorted = [...ids].sort();
      const topologyChanged = bank && JSON.stringify(bank.units.map((u) => u.id)) !== JSON.stringify(sorted);
      const interrupted = bank && bank.lastTime !== null && timeSeconds - bank.lastTime > this.config.maximumGapSeconds;
      if (topologyChanged || interrupted || bank && winner !== bank.winner) {
        this.forget(scope);
        bank = void 0;
      }
      if (!bank) {
        if (this.sessionState.banks.size >= this.config.maximumScopes) {
          this.sessionState.banks.delete(this.sessionState.banks.keys().next().value);
          this.sessionState.evictions++;
        }
        bank = this.create(sorted);
      }
      this.sessionState.banks.delete(scope);
      this.sessionState.banks.set(scope, bank);
      const dt = bank.lastTime === null ? 0 : timeSeconds - bank.lastTime;
      const supportedRate = Math.min(rate, bank.previousRate);
      const input = supportedRate * this.config.timeConstantSeconds * -Math.expm1(-dt / this.config.timeConstantSeconds);
      const before = this.bankWork(bank);
      for (const unit of bank.units) {
        const source = bank.session.nodeStateOf(unit.source);
        source.amplitude = unit.id === winner ? input : 0;
        if (this.mode === "spikes-modulated")
          source.evidenceRate = unit.id === winner ? rate : 0;
      }
      bank.session.run(timeSeconds);
      const after = this.bankWork(bank);
      for (const key2 of Object.keys(after))
        this.sessionState.counts[key2] += after[key2] - before[key2];
      bank.lastTime = timeSeconds;
      bank.previousRate = rate;
      bank.winner = winner;
      const units = bank.units.map((unit) => ({
        modeId: unit.id,
        potential: unit.neuron.stateOf(bank.session).membranePotential,
        lastActivation: bank.session.nodeStateOf(unit.readout).lastActivation,
        spikes: unit.neuron.stateOf(bank.session).spikeCount,
        ...unit.neuron instanceof ModulatedResetLif ? {
          resetEvidence: bank.session.nodeStateOf(unit.neuron).evidenceRate,
          lastResetPotential: bank.session.nodeStateOf(unit.neuron).lastResetPotential
        } : {}
      }));
      const activated = units.find((u) => u.modeId === winner);
      const modeId = rate > 0 && activated?.lastActivation !== null && activated?.lastActivation !== void 0 && timeSeconds - activated.lastActivation <= this.config.activationLifetimeSeconds ? winner : null;
      return immutableCopy({ mode: this.mode, timeSeconds, winner, modeId, units });
    }
    bankWork(bank) {
      const sourceFirings = bank.units.reduce((n, u) => n + bank.session.nodeStateOf(u.source).firings, 0);
      const integratorFirings = bank.units.reduce((n, u) => n + bank.session.nodeStateOf(u.neuron).firings, 0);
      const readoutFirings = bank.units.reduce((n, u) => n + bank.session.nodeStateOf(u.readout).firings, 0);
      return { sourceFirings, integratorFirings, readoutFirings, inputEvents: sourceFirings, outputEvents: readoutFirings };
    }
    inspect() {
      const graphs = [...this.sessionState.banks.entries()].map(([scope, bank]) => ({
        scope,
        engine: "spikypanda-core",
        builder: "RuntimeGraphBuilder",
        scheduling: "dynamic",
        nodes: bank.session.graph.nodes.map((n) => ({ id: String(n.id), implementation: n.constructor.name })),
        edges: bank.session.graph.links.map((l) => ({ from: String(l.oini?.id), to: String(l.ofin?.id), output: l.slot, input: l.toSlot })),
        state: bank.units.map((u) => ({
          modeId: u.id,
          potential: u.neuron.stateOf(bank.session).membranePotential,
          lastActivation: bank.session.nodeStateOf(u.readout).lastActivation
        }))
      }));
      return immutableCopy({
        mode: this.mode,
        config: this.config,
        ...this.resetModulation ? { resetModulation: this.resetModulation } : {},
        ...this.sessionState.counts,
        nodeFirings: this.sessionState.counts.sourceFirings + this.sessionState.counts.integratorFirings + this.sessionState.counts.readoutFirings,
        spikeEvents: this.mode !== "continuous" ? this.sessionState.counts.outputEvents : 0,
        scopes: this.sessionState.banks.size,
        graphBuilds: this.sessionState.graphBuilds,
        resets: this.sessionState.resets,
        evictions: this.sessionState.evictions,
        liveNodes: graphs.reduce((n, g) => n + g.nodes.length, 0),
        graphs
      });
    }
  };

  // packages/harness/dist/temporal-cue-observer.js
  var json3 = (value) => stableStringify(value);
  var encoder2 = "harness.temporal-cue-gate.v1";
  var TemporalCueObserver = class {
    base;
    propagation;
    clockSeconds;
    network;
    get last() {
      return this.network.sessionState.cueCache;
    }
    constructor(base, propagation, clockSeconds, config = DEFAULT_TEMPORAL_EVIDENCE_CONFIG, resetModulation) {
      this.base = base;
      this.propagation = propagation;
      this.clockSeconds = clockSeconds;
      this.network = new TemporalEvidenceNetwork(propagation, config, resetModulation);
    }
    get policy() {
      return this.base.policy;
    }
    key(context) {
      return json3([context.state, context.intention]);
    }
    assess(context) {
      const time = this.clockSeconds(), key2 = this.key(context);
      if (!Number.isFinite(time) || time < 0 || this.last && time < this.last.time)
        throw new Error("Invalid temporal observation clock");
      const raw = this.base.assess(context);
      if (this.last?.time === time) {
        if (this.last.key === key2 && json3(raw) === json3(this.last.raw))
          return this.last.result;
        throw new Error("Conflicting temporal observation at the same timestamp");
      }
      const candidates = raw.candidates, best = candidates[0], next = candidates[1];
      let evidence = null, rate = 0;
      let reason;
      let status = raw.status, modeId;
      if (["learning", "missing", "novel"].includes(raw.status)) {
        this.network.forget(raw.scope);
        reason = raw.status;
      } else if (!next || candidates.length > this.network.config.maximumModes) {
        this.network.forget(raw.scope);
        reason = "capacity";
        status = "ambiguous";
      } else {
        const gap = Math.max(0, next.distance - best.distance);
        rate = Math.max(0, 1 - best.distance / this.base.config.maximumDistance) * Math.min(1, gap / this.base.config.minimumMargin);
        const winner = rate > 0 ? best.modeId : null;
        evidence = this.network.advance(raw.scope, candidates.map((c) => c.modeId), winner, rate, time);
        modeId = evidence.modeId ?? void 0;
        status = modeId ? "recognized" : "ambiguous";
        reason = modeId ? "activated" : "integrating";
      }
      const result = immutableCopy({
        ...raw,
        encoder: encoder2,
        status,
        modeId,
        temporal: {
          propagation: this.propagation,
          instantaneousStatus: raw.status,
          observedAtSeconds: time,
          evidenceRate: rate,
          evidence,
          reason
        }
      });
      this.network.sessionState.cueCache = { key: key2, time, raw, result };
      return result;
    }
    validateAssessment(context, assessment) {
      if (!this.last || this.last.key !== this.key(context) || this.clockSeconds() !== this.last.time || json3(assessment) !== json3(this.last.result))
        throw new Error("Stale or foreign temporal assessment");
      this.base.validateAssessment(context, this.last.raw);
    }
    /** Explicit experimental envelope. Not a V3 import file; active membranes are never durable memory. */
    snapshot() {
      return immutableCopy({
        kind: "harness.temporal-cue-experiment",
        version: 1,
        policy: this.policy.snapshot(),
        observer: {
          encoder: encoder2,
          propagation: this.propagation,
          schema: this.base.schema,
          metricConfig: this.base.config,
          temporalConfig: this.network.config,
          ...this.network.resetModulation ? { resetModulation: this.network.resetModulation } : {}
        },
        persistence: "diagnostic-only; no temporal observer restore contract"
      });
    }
    inspect() {
      return this.network.inspect();
    }
  };

  // packages/harness/dist/topology-types.js
  var DEFAULT_TOPOLOGY_CONFIG = Object.freeze({
    minimumSupport: 0.6,
    minimumMargin: 0.15,
    minimumConfidence: 0.75,
    maximumNodes: 256,
    maximumEdges: 1024,
    maximumPasses: 1e4,
    maximumObservationAgeSeconds: 2
  });

  // packages/harness/dist/topology-memory.js
  var import_core9 = __toESM(require_core(), 1);

  // packages/harness/dist/topology-execution.js
  var import_core8 = __toESM(require_core(), 1);
  var port2 = (slot) => ({ slot, type: "topology.support", optional: false, kind: "stream", capacity: 1 });
  var key = (v) => stableStringify(v);
  function unknownSignal(reason) {
    return { known: false, support: 0, evidence: [], blockers: [], missing: [reason], nodeIds: [], edgeIds: [] };
  }
  var strings = (xs) => [...new Set(xs)].sort();
  var evidences = (xs) => [...new Map(xs.map((x) => [key(x), x])).entries()].sort(([a], [b]) => a.localeCompare(b)).map(([, x]) => x);
  var TopologyFrameSource = class extends import_core8.RuntimeNode {
    inputPorts = [];
    outputPorts = [port2("support")];
    createNodeState() {
      return {
        linksReady: 0,
        busy: false,
        boundDecision: null,
        seenObservations: /* @__PURE__ */ new Set(),
        seenDecisions: /* @__PURE__ */ new Set(),
        issued: /* @__PURE__ */ new WeakSet(),
        trace: [],
        proposals: [],
        journal: [],
        claimed: false,
        closed: false,
        budget: 0,
        lastTime: null,
        passes: 0,
        attempts: 0,
        deliveries: 0,
        positives: 0,
        completions: 0,
        sourceFirings: 0
      };
    }
    reset(session) {
      Object.assign(session.nodeStateOf(this), this.createNodeState(), { frame: void 0, abort: void 0, lastPass: void 0, lastKey: void 0 });
    }
    state(session) {
      return session.nodeStateOf(this);
    }
    current(session) {
      const s = this.state(session);
      checkAbort(s.abort);
      if (!s.busy || !s.frame)
        throw new Error("No active topology frame");
      return s;
    }
    fire(session) {
      const s = this.current(session);
      if (s.sourceFirings + s.trace.length >= s.budget)
        throw new Error("Topology work budget exceeded");
      s.sourceFirings++;
      this.forward(session, this, { ...unknownSignal("observation-envelope"), known: true, support: 1, missing: [] });
    }
    forward(session, from, signal) {
      const s = this.current(session), f = s.frame;
      for (const channel of session.graph.links.filter((c) => c.oini === from && c.slot === "support")) {
        const index = session.graph.links.indexOf(channel);
        const packet = immutableCopy({
          decisionId: f.decisionId,
          observationId: f.observationId,
          memoryRevision: f.memoryRevision,
          schemaVersion: f.schemaVersion,
          edgeId: String(channel.id),
          from: String(from.id),
          signal
        });
        s.issued.add(packet);
        session.publish(index, packet);
      }
    }
    receive(session, node, slot) {
      const s = this.current(session), channels = session.graph.links.filter((c) => c.ofin === node && c.toSlot === slot);
      if (!channels.length)
        return unknownSignal("unwired:" + node.id + ":" + slot);
      if (channels.length !== 1)
        throw new Error("Multiple topology producers on one input");
      const channel = channels[0], index = session.graph.links.indexOf(channel), packet = session.consume(index);
      if (!packet || !s.issued.has(packet) || packet.decisionId !== s.frame.decisionId || packet.observationId !== s.frame.observationId || packet.memoryRevision !== s.frame.memoryRevision || packet.schemaVersion !== s.frame.schemaVersion || packet.edgeId !== channel.id || packet.from !== channel.oini?.id)
        throw new Error("Foreign, stale or consumed topology packet");
      s.issued.delete(packet);
      s.deliveries++;
      return { ...packet.signal, edgeIds: strings([
        ...packet.signal.edgeIds,
        ...String(channel.id).startsWith("$") ? [] : [String(channel.id)]
      ]) };
    }
  };
  var TopologyRuntimeNode = class extends import_core8.RuntimeNode {
    frameSource;
    inputPorts;
    outputPorts = [port2("support")];
    constructor(frameSource, slots) {
      super();
      this.frameSource = frameSource;
      this.inputPorts = slots.map(port2);
    }
    createNodeState() {
      return { linksReady: 0, lastDecision: null, visits: 0 };
    }
    reset(session) {
      Object.assign(session.nodeStateOf(this), { lastDecision: null, visits: 0, lastSignal: void 0 });
    }
    isReady(session) {
      const frame = this.frameSource.state(session).frame;
      return !!frame && session.nodeStateOf(this).lastDecision !== frame.decisionId && super.isReady(session);
    }
    fire(session) {
      const s = this.frameSource.current(session), local = session.nodeStateOf(this);
      if (s.sourceFirings + s.trace.length >= s.budget)
        throw new Error("Topology work budget exceeded");
      if (local.lastDecision === s.frame.decisionId)
        throw new Error("Duplicate topology firing");
      const inputs = this.inputPorts.map((p) => this.frameSource.receive(session, this, String(p.slot)));
      const signal = immutableCopy(this.transformSignal(session, { ...this.evaluate(s.frame, inputs), nodeIds: strings([
        ...inputs.flatMap((x) => x.nodeIds),
        String(this.id)
      ]) }));
      local.lastDecision = s.frame.decisionId;
      local.visits++;
      local.lastSignal = signal;
      s.trace.push({ nodeId: String(this.id), implementation: this.constructor.name, signal });
      if (signal.known && signal.support > 0 && !signal.blockers.length)
        s.positives++;
      else
        s.completions++;
      this.afterEvaluation(session, signal);
      this.frameSource.forward(session, this, signal);
    }
    /** Optional local dynamics, executed once inside this memory node's passage. */
    transformSignal(_session, signal) {
      return signal;
    }
    afterEvaluation(_session, _signal) {
    }
  };
  var TopologyConditionNode = class extends TopologyRuntimeNode {
    definition;
    constructor(source, definition) {
      super(source, ["frame"]);
      this.definition = definition;
    }
    evaluate(frame) {
      let value = frame.context.state.features;
      for (const part of this.definition.path)
        value = value && typeof value === "object" && !Array.isArray(value) && Object.hasOwn(value, part) ? value[part] : void 0;
      const evidence = [{ observationId: frame.observationId, path: this.definition.path }];
      if (typeof value !== "number" || !Number.isFinite(value))
        return { ...unknownSignal("missing:" + this.id), evidence };
      const support = Math.max(0, 1 - Math.abs(value - this.definition.center) / this.definition.tolerance);
      return {
        known: true,
        support,
        evidence,
        missing: [],
        nodeIds: [],
        edgeIds: [],
        blockers: support === 0 && this.definition.vetoOnMismatch ? [String(this.id)] : []
      };
    }
  };
  function combineSignals(inputs, mode) {
    const known = mode === "and" ? inputs.every((x) => x.known) : inputs.some((x) => x.known);
    const blockers = strings(inputs.flatMap((x) => x.blockers));
    const support = !known || blockers.length ? 0 : mode === "and" ? Math.min(...inputs.map((x) => x.support)) : Math.max(...inputs.filter((x) => x.known).map((x) => x.support));
    return {
      known,
      support,
      blockers,
      evidence: evidences(inputs.flatMap((x) => x.evidence)),
      missing: strings(inputs.flatMap((x) => x.missing)),
      nodeIds: strings(inputs.flatMap((x) => x.nodeIds)),
      edgeIds: strings(inputs.flatMap((x) => x.edgeIds))
    };
  }
  var TopologyAndNode = class extends TopologyRuntimeNode {
    definition;
    constructor(source, definition) {
      super(source, definition.inputs);
      this.definition = definition;
    }
    evaluate(_frame, inputs) {
      return combineSignals(inputs, "and");
    }
  };
  var TopologyOrNode = class extends TopologyAndNode {
    evaluate(_frame, inputs) {
      return combineSignals(inputs, "or");
    }
  };
  var TopologyBranchNode = class extends TopologyRuntimeNode {
    definition;
    outputPorts = [];
    constructor(source, definition) {
      super(source, definition.inputs);
      this.definition = definition;
    }
    evaluate(_frame, inputs) {
      return inputs[0];
    }
    afterEvaluation(session, signal) {
      if (signal.known && signal.support > 0 && !signal.blockers.length)
        this.frameSource.current(session).proposals.push(immutableCopy({
          branchId: String(this.id),
          support: signal.support,
          decision: this.definition.decision,
          stats: this.definition.stats,
          experienceIds: this.definition.experienceIds,
          signal
        }));
    }
  };

  // packages/harness/dist/topology-memory.js
  var topologyKey = (value) => stableStringify(value);
  var identifier = (v) => typeof v === "string" && v.length > 0 && v.length <= 256 && !v.startsWith("$");
  var objectKeys = (v, allowed) => {
    if (!v || typeof v !== "object" || Array.isArray(v) || Object.keys(v).some((k) => !allowed.includes(k)))
      throw new Error("Invalid topology fields");
  };
  function validateTopologyConfig(config) {
    objectKeys(config, Object.keys(DEFAULT_TOPOLOGY_CONFIG));
    if (![config.minimumSupport, config.minimumMargin, config.minimumConfidence].every((n) => Number.isFinite(n) && n > 0 && n <= 1) || !Number.isFinite(config.maximumObservationAgeSeconds) || config.maximumObservationAgeSeconds < 0 || ![config.maximumNodes, config.maximumEdges, config.maximumPasses].every((n) => Number.isSafeInteger(n) && n > 0) || config.maximumNodes > 1024 || config.maximumEdges > 8192 || config.maximumPasses > 1e5)
      throw new Error("Invalid topology limits");
  }
  function validateTopologyDefinition(value, config) {
    assertJson(value);
    objectKeys(value, ["version", "revision", "schemaVersion", "contextKey", "nodes", "edges"]);
    if (value.version !== 1 || !identifier(value.revision) || !identifier(value.schemaVersion) || typeof value.contextKey !== "string" || !value.contextKey || !Array.isArray(value.nodes) || !Array.isArray(value.edges) || !value.nodes.length || value.nodes.length > config.maximumNodes || value.edges.length > config.maximumEdges)
      throw new Error("Invalid topology definition or budget");
    const ids = /* @__PURE__ */ new Map();
    for (const n of value.nodes) {
      if (!identifier(n?.id) || ids.has(n.id))
        throw new Error("Invalid or duplicate topology node");
      if (n.kind === "condition") {
        objectKeys(n, ["id", "kind", "path", "center", "tolerance", "vetoOnMismatch"]);
        if (!Array.isArray(n.path) || !n.path.length || n.path.length > 8 || n.path.some((p) => !identifier(p) || ["__proto__", "prototype", "constructor"].includes(p)) || !Number.isFinite(n.center) || !Number.isFinite(n.tolerance) || n.tolerance <= 0 || n.vetoOnMismatch !== void 0 && typeof n.vetoOnMismatch !== "boolean")
          throw new Error("Invalid topology condition");
      } else if (n.kind === "and" || n.kind === "or" || n.kind === "branch") {
        objectKeys(n, n.kind === "branch" ? ["id", "kind", "inputs", "decision", "stats", "experienceIds"] : ["id", "kind", "inputs"]);
        if (!Array.isArray(n.inputs) || !n.inputs.length || n.inputs.length > 32 || new Set(n.inputs).size !== n.inputs.length || n.inputs.some((p) => !identifier(p) || p.startsWith("_")))
          throw new Error("Invalid topology input slots");
        if (n.kind === "branch") {
          if (topologyKey(n.inputs) !== '["support"]')
            throw new Error("A branch requires one support input");
          validateDecision(n.decision);
          if (Object.hasOwn(n.decision, "source"))
            throw new Error("A memory proposal cannot declare a decision source");
          objectKeys(n.stats, [
            "totalUsageCount",
            "totalSuccessCount",
            "totalFailureCount",
            "rewardEma",
            "confidence",
            "effectiveEvidence",
            "consecutiveFailures",
            "directEligible",
            "lastUsedAt"
          ]);
          const s = n.stats;
          if (![s.totalUsageCount, s.totalSuccessCount, s.totalFailureCount, s.consecutiveFailures].every((v) => Number.isSafeInteger(v) && v >= 0) || s.totalSuccessCount + s.totalFailureCount !== s.totalUsageCount || s.consecutiveFailures > s.totalFailureCount || !Number.isFinite(s.rewardEma) || Math.abs(s.rewardEma) > 1 || !Number.isFinite(s.confidence) || s.confidence < 0 || s.confidence > 1 || !Number.isFinite(s.effectiveEvidence) || s.effectiveEvidence < 0 || s.effectiveEvidence > s.totalUsageCount || typeof s.directEligible !== "boolean" || s.lastUsedAt !== void 0 && !Number.isFinite(s.lastUsedAt))
            throw new Error("Invalid branch statistics");
          if (!Array.isArray(n.experienceIds) || new Set(n.experienceIds).size !== n.experienceIds.length || n.experienceIds.some((id) => !identifier(id)) || s.directEligible && !n.experienceIds.length)
            throw new Error("Invalid branch provenance");
        }
      } else
        throw new Error("Unknown topology node kind");
      ids.set(n.id, n);
    }
    if (!value.nodes.some((n) => n.kind === "condition") || !value.nodes.some((n) => n.kind === "branch"))
      throw new Error("Topology needs conditions and branches");
    const edgeIds = /* @__PURE__ */ new Set(), destinations = /* @__PURE__ */ new Set();
    for (const edge of value.edges) {
      objectKeys(edge, ["id", "from", "to", "input"]);
      const from = ids.get(edge.from), to = ids.get(edge.to), slot = topologyKey([edge.to, edge.input]);
      if (!identifier(edge.id) || edgeIds.has(edge.id) || !from || !to || from.kind === "branch" || to.kind === "condition" || !to.inputs.includes(edge.input) || destinations.has(slot))
        throw new Error("Invalid topology relation or duplicate producer");
      edgeIds.add(edge.id);
      destinations.add(slot);
    }
  }
  var createTopologyNode = (source, def) => def.kind === "condition" ? new TopologyConditionNode(source, def) : def.kind === "and" ? new TopologyAndNode(source, def) : def.kind === "or" ? new TopologyOrNode(source, def) : new TopologyBranchNode(source, def);
  var MemoryElement = class extends import_core9.GraphNode {
    definition;
    constructor(definition) {
      super();
      this.definition = definition;
      this.id = definition.id;
      this.type = "Harness.Topology:" + definition.kind;
    }
  };
  var TopologyMemory = class {
    definition;
    config;
    frameSource = new TopologyFrameSource();
    graph;
    memoryGraph;
    nodeRefs;
    linkRefs;
    shape;
    constructor(definition, config = DEFAULT_TOPOLOGY_CONFIG, factory = createTopologyNode) {
      validateTopologyConfig(config);
      this.config = immutableCopy(config);
      this.definition = immutableCopy(definition);
      validateTopologyDefinition(this.definition, this.config);
      const savedNodes = this.definition.nodes.map((n) => new MemoryElement(n));
      const saved = new Map(savedNodes.map((n) => [String(n.id), n]));
      const data = new import_core9.GraphBuilder().withNodes(...savedNodes);
      for (const edge of this.definition.edges) {
        const link = new import_core9.GraphOLink(saved.get(edge.from), saved.get(edge.to));
        link.id = edge.id;
        data.withLinks(link);
      }
      this.memoryGraph = data.build();
      this.frameSource.id = "$observation";
      const nodes = this.definition.nodes.map((def) => {
        const node = factory(this.frameSource, def);
        if (!(node instanceof TopologyRuntimeNode) || node.frameSource !== this.frameSource || node.definition !== def)
          throw new Error("Foreign topology node factory result");
        node.id = def.id;
        return node;
      });
      if (new Set(nodes).size !== nodes.length)
        throw new Error("Topology factory reused a node");
      const byId = new Map(nodes.map((n) => [String(n.id), n]));
      const builder = new import_core9.RuntimeGraphBuilder().withMode("static").withNodes(this.frameSource, ...nodes);
      for (const n of nodes)
        if (n instanceof TopologyConditionNode)
          builder.withChannel(this.frameSource, n, "support", "frame");
      for (const edge of this.definition.edges)
        builder.withChannel(byId.get(edge.from), byId.get(edge.to), "support", edge.input);
      this.graph = builder.build();
      for (const link of this.graph.links) {
        const edge = this.definition.edges.find((e) => e.from === link.oini?.id && e.to === link.ofin?.id && e.input === link.toSlot);
        link.id = edge?.id ?? "$observation:" + link.ofin.id;
      }
      import_core9.Scheduler.GetStaticOrder(this.graph);
      this.nodeRefs = [...this.graph.nodes];
      this.linkRefs = [...this.graph.links];
      this.shape = this.graphShape();
    }
    graphShape() {
      return topologyKey({ mode: this.graph.mode, nodes: this.graph.nodes.map((n) => ({
        id: n.id,
        enabled: n.enabled,
        inputs: n.inputPorts,
        outputs: n.outputPorts,
        definition: n instanceof TopologyRuntimeNode ? n.definition : null
      })), edges: this.graph.links.map((e) => ({
        id: e.id,
        from: e.oini?.id,
        to: e.ofin?.id,
        slot: e.slot,
        input: e.toSlot,
        enabled: e.enabled,
        delayed: e.delayed
      })) });
    }
    assertIntact() {
      if (this.nodeRefs.length !== this.graph.nodes.length || this.linkRefs.length !== this.graph.links.length || !this.nodeRefs.every((n, i) => n === this.graph.nodes[i]) || !this.linkRefs.every((n, i) => n === this.graph.links[i]) || this.shape !== this.graphShape())
        throw new Error("Topology projection changed: construct an explicit memory revision");
    }
  };

  // packages/harness/dist/topology-session.js
  var import_core10 = __toESM(require_core(), 1);
  var TopologyActivationSession = class {
    memory;
    session;
    constructor(memory) {
      this.memory = memory;
      this.session = new import_core10.Session(memory.graph);
    }
    get state() {
      return this.memory.frameSource.state(this.session);
    }
    beginDecision(id) {
      this.memory.assertIntact();
      if (!id || this.state.busy || this.state.boundDecision)
        throw new Error("Topology interaction already in use");
      this.state.boundDecision = id;
      this.state.closed = false;
      this.state.lastPass = void 0;
    }
    endDecision(id) {
      if (this.state.boundDecision !== id)
        throw new Error("Foreign topology decision lease");
      this.state.boundDecision = null;
      this.state.closed = true;
    }
    assertBound(timeSeconds) {
      this.memory.assertIntact();
      if (!this.state.boundDecision || this.state.closed)
        throw new Error("Topology decision session closed");
      const pass = this.state.lastPass;
      if (timeSeconds !== void 0 && (!Number.isFinite(timeSeconds) || pass && (timeSeconds < pass.timeSeconds || timeSeconds - pass.observedAtSeconds > this.memory.config.maximumObservationAgeSeconds)))
        throw new Error("Topology observation expired before execution");
    }
    reset() {
      if (this.state.busy || this.state.boundDecision)
        throw new Error("Cannot reset an active topology decision");
      const journal = this.state.journal;
      this.session.reset();
      this.state.journal = journal;
    }
    activate(frame, options = {}) {
      checkAbort(options.signal);
      this.memory.assertIntact();
      frame = immutableCopy(frame);
      if (Object.keys(frame).some((k) => ![
        "observationId",
        "decisionId",
        "observedAtSeconds",
        "availableAtSeconds",
        "timeSeconds",
        "memoryRevision",
        "schemaVersion",
        "context"
      ].includes(k)))
        throw new Error("Unexpected topology frame field");
      if (!frame.observationId || typeof frame.observationId !== "string" || !frame.decisionId || typeof frame.decisionId !== "string")
        throw new Error("Missing topology frame identity");
      validateState(frame.context?.state);
      validateIntention(frame.context?.intention);
      if (frame.context.operatingContextId !== void 0 || frame.context.cues !== void 0 || frame.context.key !== contextKey(frame.context.state, frame.context.intention) || frame.context.key !== this.memory.definition.contextKey || frame.memoryRevision !== this.memory.definition.revision || frame.schemaVersion !== this.memory.definition.schemaVersion)
        throw new Error("Foreign topology context, regime or revision");
      if (![frame.observedAtSeconds, frame.availableAtSeconds, frame.timeSeconds].every((t) => Number.isFinite(t) && t >= 0) || frame.observedAtSeconds > frame.availableAtSeconds || frame.availableAtSeconds > frame.timeSeconds || frame.timeSeconds - frame.observedAtSeconds > this.memory.config.maximumObservationAgeSeconds)
        throw new Error("Invalid or stale topology observation time");
      const s = this.state, fingerprint = topologyKey(frame);
      if (s.busy || s.boundDecision && s.boundDecision !== frame.decisionId)
        throw new Error("Foreign or overlapping topology decision");
      if (!s.closed && s.lastKey === fingerprint && s.lastPass)
        return s.lastPass;
      if (s.seenObservations.has(frame.observationId) || s.seenDecisions.has(frame.decisionId))
        throw new Error("Repeated topology observation or decision");
      if (s.lastTime !== null && frame.timeSeconds <= s.lastTime)
        throw new Error("Topology clock must increase");
      if (s.attempts >= this.memory.config.maximumPasses)
        throw new Error("Topology session capacity reached");
      const budget = options.maximumNodeFirings ?? this.memory.graph.nodes.length;
      if (!Number.isSafeInteger(budget) || budget < 1)
        throw new Error("Invalid topology work budget");
      Object.assign(s, {
        frame,
        abort: options.signal,
        busy: true,
        closed: false,
        claimed: false,
        lastPass: void 0,
        lastKey: fingerprint,
        trace: [],
        proposals: [],
        issued: /* @__PURE__ */ new WeakSet(),
        sourceFirings: 0,
        deliveries: 0,
        positives: 0,
        completions: 0,
        budget,
        lastTime: frame.timeSeconds
      });
      s.seenObservations.add(frame.observationId);
      s.seenDecisions.add(frame.decisionId);
      s.attempts++;
      try {
        this.session.run(frame.timeSeconds);
        checkAbort(options.signal);
        this.memory.assertIntact();
        if (s.trace.length !== this.memory.definition.nodes.length || s.sourceFirings !== 1)
          throw new Error("Incomplete topology passage");
        const pass = immutableCopy(this.decoratePass({
          kind: "topology-activation",
          version: 1,
          completed: true,
          observationId: frame.observationId,
          decisionId: frame.decisionId,
          memoryRevision: frame.memoryRevision,
          schemaVersion: frame.schemaVersion,
          timeSeconds: frame.timeSeconds,
          contextKey: frame.context.key,
          observedAtSeconds: frame.observedAtSeconds,
          availableAtSeconds: frame.availableAtSeconds,
          proposals: s.proposals.slice().sort((a, b) => a.branchId.localeCompare(b.branchId)),
          trace: s.trace,
          work: {
            sourceFirings: s.sourceFirings,
            nodeFirings: s.sourceFirings + s.trace.length,
            relationDeliveries: s.deliveries,
            positiveOutputs: s.positives,
            completionOnlyOutputs: s.completions,
            spikeEvents: 0
          }
        }));
        s.lastPass = pass;
        s.passes++;
        return pass;
      } finally {
        s.busy = false;
        s.abort = void 0;
        s.frame = void 0;
        this.session.queue.splice(0);
        this.session.deferred.splice(0);
        for (const n of this.session.nodeStates) {
          n.inputBuffers?.forEach((buffer) => {
            buffer.length = 0;
          });
          n.linksReady = 0;
        }
      }
    }
    decoratePass(pass) {
      return pass;
    }
    assertPass(pass, context, decisionId) {
      this.memory.assertIntact();
      const s = this.state;
      if (s.closed || !s.lastPass || topologyKey(s.lastPass) !== topologyKey(pass) || decisionId !== void 0 && pass.decisionId !== decisionId || context && (context.key !== pass.contextKey || !s.lastKey || topologyKey(context) !== topologyKey(JSON.parse(s.lastKey).context)))
        throw new Error("Foreign, stale or closed topology result");
    }
    arbitrate(pass) {
      this.assertPass(pass);
      const config = this.memory.config, grouped = /* @__PURE__ */ new Map();
      for (const proposal of pass.proposals) {
        const key2 = topologyKey(proposal.decision.invocation);
        grouped.set(key2, [...grouped.get(key2) ?? [], proposal]);
      }
      const ranked = [...grouped].map(([invocationKey, proposals]) => ({
        invocationKey,
        proposals,
        support: Math.max(...proposals.map((p) => p.support))
      })).sort((a, b) => b.support - a.support || a.invocationKey.localeCompare(b.invocationKey));
      const groups = ranked.map((g) => ({
        invocationKey: g.invocationKey,
        support: g.support,
        branchIds: g.proposals.map((p) => p.branchId).sort()
      }));
      const result = (reason, selected) => immutableCopy({ reason, groups, ...selected ? { selected } : {} });
      const best = ranked[0], next = ranked[1];
      if (!best)
        return result("empty");
      if (best.support < config.minimumSupport)
        return result("insufficient");
      if (next && best.support - next.support < config.minimumMargin)
        return result("ambiguous");
      const eligible = best.proposals.filter((p) => p.stats.directEligible && p.stats.confidence >= config.minimumConfidence && p.support >= config.minimumSupport && (!next || p.support - next.support >= config.minimumMargin)).sort((a, b) => b.support - a.support || a.branchId.localeCompare(b.branchId))[0];
      return eligible ? result("selected", eligible) : result("unreliable");
    }
    claim(pass, context, decisionId) {
      this.assertBound();
      this.assertPass(pass, context, decisionId);
      if (this.state.boundDecision !== decisionId || this.state.claimed)
        throw new Error("Topology result already claimed");
      this.state.claimed = true;
      return this.arbitrate(pass);
    }
    /** Called only after the harness authority checked the executed receipt. No credit assignment in T1. */
    appendExecutedExperience(experience) {
      this.assertBound();
      if (!this.state.claimed || experience.decisionId !== this.state.boundDecision || this.state.journal.some((e) => e.decisionId === experience.decisionId))
        throw new Error("Foreign or duplicate topology experience");
      const activation = this.state.lastPass;
      const record2 = { ...experience, activation, arbitration: this.arbitrate(activation) };
      this.state.journal.push(immutableCopy(record2));
    }
    journal() {
      return immutableCopy(this.state.journal);
    }
    inspect() {
      const s = this.state;
      return immutableCopy({
        kind: "topology-activation-t1",
        engine: "spikypanda-core",
        memoryRevision: this.memory.definition.revision,
        scheduling: this.memory.graph.mode,
        passes: s.passes,
        attempts: s.attempts,
        experiences: s.journal.length,
        lastPass: s.lastPass ?? null,
        nodes: this.memory.graph.nodes.map((n) => ({
          id: String(n.id),
          implementation: n.constructor.name,
          visits: this.session.nodeStateOf(n)?.visits ?? s.passes
        })),
        edges: this.memory.graph.links.map((e) => ({
          id: String(e.id),
          from: String(e.oini.id),
          to: String(e.ofin.id),
          input: e.toSlot
        }))
      });
    }
  };

  // packages/harness/dist/topology-nodes.js
  var candidate = (p, context) => ({
    transitionKey: p.branchId,
    context,
    action: p.decision.action,
    invocation: p.decision.invocation,
    expectedOutcome: p.decision.expectedOutcome,
    score: p.support,
    similarity: p.support,
    confidence: p.stats.confidence,
    eligible: p.stats.directEligible,
    stats: p.stats
  });
  var TopologyLookupNode = class extends PolicyLookupNode {
    activation;
    identify;
    constructor(activation, identify) {
      super();
      this.activation = activation;
      this.identify = identify;
    }
    async execute(context, session) {
      this.activation.assertBound();
      const definition = this.activation.memory.definition;
      const pass = this.activation.activate({
        ...this.identify(context, session),
        decisionId: session.frame.decisionId,
        context,
        memoryRevision: definition.revision,
        schemaVersion: definition.schemaVersion,
        timeSeconds: session.now() / 1e3
      }, { signal: session.signal });
      return { slot: "candidates", value: { context, topology: pass, candidates: pass.proposals.map((p) => candidate(p, context)) } };
    }
  };
  var TopologyGateNode = class extends ConfidenceGateNode {
    activation;
    constructor(activation) {
      super();
      this.activation = activation;
    }
    async execute(input, session) {
      const result = this.activation.claim(input.topology, input.context, session.frame.decisionId);
      if (!result.selected)
        return { slot: "fallback", value: input };
      const selected = result.selected;
      const available = await session.authority.listAvailable(input.context);
      session.assertActive();
      this.activation.assertBound(session.now() / 1e3);
      this.activation.assertPass(input.topology, input.context, session.frame.decisionId);
      if (!available.some((c) => c.id === selected.decision.invocation.capabilityId))
        return { slot: "fallback", value: input };
      return { slot: "policy", value: {
        context: input.context,
        candidate: candidate(selected, input.context),
        decision: { ...selected.decision, source: "policy" }
      } };
    }
  };
  var TopologyExperienceRecorderNode = class extends ExperienceRecorderNode {
    activation;
    constructor(activation) {
      super();
      this.activation = activation;
    }
    async execute(input, session) {
      session.assertCanComplete();
      session.authority.assertExecuted(input);
      this.activation.assertBound();
      const { context, decision, stateAfter, result, evaluation, candidate: chosen } = input;
      this.activation.appendExecutedExperience({
        id: "experience:" + session.frame.decisionId,
        decisionId: session.frame.decisionId,
        context,
        decision,
        stateAfter,
        result,
        evaluation,
        observedAt: session.now()
      });
      session.services.metrics.recordOutcome(evaluation, true);
      session.complete({
        decisionId: session.frame.decisionId,
        source: decision.source,
        stateBefore: context.state,
        intention: context.intention,
        decision,
        result,
        stateAfter,
        evaluation,
        candidateScore: chosen?.score,
        candidateConfidence: chosen?.confidence,
        startedAt: session.startedAt,
        completedAt: session.now()
      });
    }
  };
  var TopologyJournalPolicy = class extends PolicyGraph {
    activation;
    constructor(activation) {
      super();
      this.activation = activation;
    }
    findCandidateActions() {
      throw new Error("Classic policy lookup is not part of topology activation");
    }
    recordExperience() {
      throw new Error("T1 does not learn topology or branch reliability");
    }
    getRecentFailures(state, intention, limit = 5) {
      return this.activation.journal().filter((e) => e.context.key === contextKey(state, intention) && !e.evaluation.success).slice(-limit).reverse();
    }
  };
  function createTopologyHarness(options) {
    const { memory, identifyObservation, buildGraph, activation: suppliedActivation, ...runtimeOptions } = options;
    if (["policy", "driver", "operatingContexts", "cueObserver", "cueMode"].some((k) => Object.hasOwn(options, k)))
      throw new Error("Foreign services in topology harness");
    const activation = suppliedActivation ?? new TopologyActivationSession(memory);
    if (!(activation instanceof TopologyActivationSession) || activation.memory !== memory)
      throw new Error("Foreign topology activation session");
    const graph = buildGraph({
      lookup: new TopologyLookupNode(activation, identifyObservation),
      gate: new TopologyGateNode(activation),
      recorder: new TopologyExperienceRecorderNode(activation)
    });
    const coreDriver = createRuntimeGraphDriver(graph);
    const runtime = new AdaptivePolicyRuntime({
      ...runtimeOptions,
      policy: new TopologyJournalPolicy(activation),
      observer: { async observe() {
        activation.assertBound((runtimeOptions.clock?.() ?? Date.now()) / 1e3);
        const state = await runtimeOptions.observer.observe();
        activation.assertBound((runtimeOptions.clock?.() ?? Date.now()) / 1e3);
        return state;
      } },
      driver: async (runtime2, frame) => {
        activation.beginDecision(frame.decisionId);
        try {
          await coreDriver(runtime2, frame);
        } finally {
          activation.endDecision(frame.decisionId);
        }
      }
    });
    return { runtime, activation, graph };
  }

  // packages/harness/dist/topology-temporal-types.js
  var DEFAULT_TOPOLOGY_TEMPORAL_CONFIG = Object.freeze({
    version: 1,
    mode: "continuous",
    timeConstantSeconds: 3,
    threshold: 1.5,
    maximumGapSeconds: 2,
    resetAlpha: 0
  });

  // packages/harness/dist/topology-temporal-cells.js
  var import_core11 = __toESM(require_core(), 1);
  var port3 = (slot) => ({ slot, type: "spike", optional: false, kind: "stream", capacity: 1 });
  var ChargeSource = class extends import_core11.RuntimeNode {
    inputPorts = [];
    outputPorts = [port3("spike")];
    createNodeState() {
      return { linksReady: 0, charge: 0, rate: 0 };
    }
    reset(session) {
      Object.assign(session.nodeStateOf(this), { charge: 0, rate: 0 });
    }
    fire(session, t) {
      const s = session.nodeStateOf(this);
      this.publishAll(session, "spike", { timestamp: t, amplitude: s.charge, rate: s.rate, source: this });
    }
  };
  var ZeroResetCell = class extends import_core11.LifNeuronNode {
    inputPorts = [port3("spike")];
    outputPorts = [];
  };
  var ContinuousCell = class extends ZeroResetCell {
  };
  var ModulatedResetCell = class extends ZeroResetCell {
    alpha;
    constructor(alpha) {
      super();
      this.alpha = alpha;
    }
    fire(session, t) {
      const input = this.inputChannels("spike")[0];
      const token = session.peek(this.channelIndex(session, input));
      if (!token || token.timestamp !== t || !Number.isFinite(token.rate) || token.rate < 0 || token.rate > 1)
        throw new Error("Invalid topology reset evidence");
      const state = this.stateOf(session), before = state.spikeCount;
      super.fire(session, t);
      if (state.spikeCount !== before)
        state.membranePotential = this.threshold * this.alpha * token.rate;
    }
  };
  var TemporalTopologyBranchNode = class extends TopologyBranchNode {
    dynamics;
    source = new ChargeSource();
    neuron;
    integratorGraph;
    integratorShape;
    integratorNodes;
    integratorLinks;
    constructor(source, definition, dynamics) {
      super(source, definition);
      this.dynamics = dynamics;
      this.source.id = definition.id + ":charge";
      this.neuron = dynamics.mode === "continuous" ? new ContinuousCell() : dynamics.mode === "spikes" ? new ZeroResetCell() : new ModulatedResetCell(dynamics.resetAlpha);
      this.neuron.id = definition.id + ":lif";
      this.neuron.membraneTimeConstant = dynamics.timeConstantSeconds;
      this.neuron.threshold = dynamics.mode === "continuous" ? Number.MAX_VALUE : dynamics.threshold;
      this.neuron.refractoryPeriod = 0;
      this.integratorGraph = new import_core11.RuntimeGraphBuilder().withMode("static").withNodes(this.source, this.neuron).withChannel(this.source, this.neuron, "spike", "spike").build();
      this.integratorNodes = [...this.integratorGraph.nodes];
      this.integratorLinks = [...this.integratorGraph.links];
      this.integratorShape = this.shape();
    }
    shape() {
      return JSON.stringify({
        mode: this.integratorGraph.mode,
        nodes: this.integratorGraph.nodes.map((n) => ({
          id: n.id,
          enabled: n.enabled,
          input: n.inputPorts,
          output: n.outputPorts
        })),
        edges: this.integratorGraph.links.map((l) => ({
          from: l.oini?.id,
          to: l.ofin?.id,
          slot: l.slot,
          input: l.toSlot,
          enabled: l.enabled,
          delayed: l.delayed
        })),
        lif: [
          this.neuron.restingPotential,
          this.neuron.initialPotential,
          this.neuron.threshold,
          this.neuron.resetPotential,
          this.neuron.membraneTimeConstant,
          this.neuron.refractoryPeriod,
          this.neuron.spikeAmplitude
        ],
        dynamics: this.dynamics,
        alpha: this.neuron instanceof ModulatedResetCell ? this.neuron.alpha : 0
      });
    }
    assertIntact() {
      if (this.shape() !== this.integratorShape || this.integratorNodes.length !== this.integratorGraph.nodes.length || this.integratorLinks.length !== this.integratorGraph.links.length || !this.integratorNodes.every((n, i) => this.integratorGraph.nodes[i] === n) || !this.integratorLinks.every((l, i) => this.integratorGraph.links[i] === l))
        throw new Error("Topology integrator projection changed");
    }
    createNodeState() {
      return {
        ...super.createNodeState(),
        integrator: new import_core11.Session(this.integratorGraph),
        previousRate: 0,
        lastObserved: null,
        lastDynamics: null,
        integratorFirings: 0,
        totalSpikes: 0,
        resets: 0,
        failureResets: 0
      };
    }
    reset(session) {
      super.reset(session);
      const state = this.local(session);
      state.integrator.reset();
      Object.assign(state, {
        previousRate: 0,
        lastObserved: null,
        lastDynamics: null,
        integratorFirings: 0,
        totalSpikes: 0,
        resets: 0,
        failureResets: 0
      });
    }
    local(session) {
      return session.nodeStateOf(this);
    }
    clearAfterFailure(session) {
      const state = this.local(session);
      state.integrator.reset();
      state.previousRate = 0;
      state.lastObserved = null;
      state.lastDynamics = null;
      state.resets++;
      state.failureResets++;
    }
    transformSignal(session, signal) {
      this.assertIntact();
      const owner = this.frameSource.current(session);
      if (owner.temporalProtocol !== "branch-temporal-v1")
        throw new Error("Temporal topology requires a temporal activation session");
      const s = this.local(session), cfg = this.dynamics, time = owner.frame.observedAtSeconds;
      const cell = this.neuron.stateOf(s.integrator);
      const dt = s.lastObserved === null ? 0 : time - s.lastObserved;
      if (dt < 0 || s.lastObserved !== null && dt === 0)
        throw new Error("Topology observation clock must increase");
      const previousPotential = cell.membranePotential;
      const resetReason = signal.blockers.length ? "contradiction" : dt > cfg.maximumGapSeconds ? "gap" : null;
      if (resetReason) {
        cell.membranePotential = 0;
        cell.lastUpdateTime = null;
        cell.lastSpikeTime = null;
        s.previousRate = 0;
        s.resets++;
      }
      const rate = signal.known && !signal.blockers.length ? signal.support : 0;
      const corroboratedRate = resetReason ? 0 : Math.min(rate, s.previousRate);
      const charge = corroboratedRate * cfg.timeConstantSeconds * -Math.expm1(-dt / cfg.timeConstantSeconds);
      const beforeReset = cell.membranePotential * Math.exp(-dt / cfg.timeConstantSeconds) + charge;
      Object.assign(s.integrator.nodeStateOf(this.source), { charge, rate });
      const spikesBefore = cell.spikeCount;
      s.integrator.run(time);
      s.integratorFirings += 2;
      const spiked = cell.spikeCount > spikesBefore;
      if (spiked)
        s.totalSpikes++;
      const active = rate > 0 && (cfg.mode === "continuous" ? cell.membranePotential >= cfg.threshold : spiked);
      s.lastObserved = time;
      s.previousRate = rate;
      s.lastDynamics = immutableCopy({
        branchId: String(this.id),
        observedAtSeconds: time,
        elapsedSeconds: dt,
        rawSupport: rate,
        corroboratedRate,
        charge,
        previousPotential,
        potentialBeforeReset: beforeReset,
        potential: cell.membranePotential,
        lastResetPotential: spiked ? cell.membranePotential : null,
        active,
        spiked,
        spikes: s.totalSpikes,
        resetReason
      });
      return { ...signal, support: active ? signal.support : 0 };
    }
    dynamicsOf(session) {
      return this.local(session).lastDynamics;
    }
    inspectDynamics(session) {
      const s = this.local(session), cell = this.neuron.stateOf(s.integrator);
      return {
        branchId: String(this.id),
        potential: cell.membranePotential,
        lastObserved: s.lastObserved,
        previousRate: s.previousRate,
        spikes: s.totalSpikes,
        resets: s.resets,
        failureResets: s.failureResets,
        nodeFirings: s.integratorFirings,
        nodes: this.integratorGraph.nodes.map((n) => ({ id: String(n.id), implementation: n.constructor.name })),
        edges: this.integratorGraph.links.map((l) => ({ from: String(l.oini.id), to: String(l.ofin.id), slot: l.slot, input: l.toSlot }))
      };
    }
  };

  // packages/harness/dist/topology-temporal.js
  function validateTopologyTemporalConfig(config) {
    if (!config || Object.keys(config).some((k) => !Object.hasOwn(DEFAULT_TOPOLOGY_TEMPORAL_CONFIG, k)) || config.version !== 1 || !["continuous", "spikes", "spikes-modulated"].includes(config.mode) || ![config.timeConstantSeconds, config.threshold, config.maximumGapSeconds].every((n) => Number.isFinite(n) && n > 0) || config.threshold >= config.timeConstantSeconds || !Number.isFinite(config.resetAlpha) || config.resetAlpha < 0 || config.resetAlpha >= 1 || config.mode !== "spikes-modulated" && config.resetAlpha !== 0)
      throw new Error("Invalid topology temporal configuration");
  }
  var TemporalTopologyMemory = class extends TopologyMemory {
    dynamics;
    branches;
    constructor(definition, dynamics = DEFAULT_TOPOLOGY_TEMPORAL_CONFIG, config = DEFAULT_TOPOLOGY_CONFIG) {
      validateTopologyTemporalConfig(dynamics);
      const saved = immutableCopy(dynamics);
      super(definition, config, (source, def) => def.kind === "condition" ? new TopologyConditionNode(source, def) : def.kind === "and" ? new TopologyAndNode(source, def) : def.kind === "or" ? new TopologyOrNode(source, def) : new TemporalTopologyBranchNode(source, def, saved));
      this.dynamics = saved;
      this.branches = Object.freeze(this.graph.nodes.filter((n) => n instanceof TemporalTopologyBranchNode));
    }
    assertIntact() {
      super.assertIntact();
      for (const node of this.branches)
        node.assertIntact();
    }
  };
  var TemporalTopologySession = class extends TopologyActivationSession {
    constructor(memory) {
      if (!(memory instanceof TemporalTopologyMemory))
        throw new Error("Expected a temporal topology memory");
      super(memory);
      Object.assign(memory.frameSource.state(this.session), { temporalProtocol: "branch-temporal-v1" });
    }
    activate(frame, options = {}) {
      const state = this.memory.frameSource.state(this.session);
      if (state.lastKey && topologyKey(frame) !== state.lastKey && frame.observedAtSeconds <= JSON.parse(state.lastKey).observedAtSeconds)
        throw new Error("Topology measurement clock must increase; batch simultaneous measurements");
      const totalBudget = options.maximumNodeFirings ?? this.memory.graph.nodes.length + this.memory.branches.length * 2;
      if (!Number.isSafeInteger(totalBudget) || totalBudget < 1)
        throw new Error("Invalid topology work budget");
      const attempts = state.attempts;
      try {
        return super.activate(frame, { ...options, maximumNodeFirings: Math.max(1, totalBudget - 2 * this.memory.branches.length) });
      } catch (error) {
        if (state.attempts !== attempts)
          for (const branch of this.memory.branches)
            branch.clearAfterFailure(this.session);
        throw error;
      }
    }
    decoratePass(pass) {
      const branches = this.memory.branches.map((b) => b.dynamicsOf(this.session));
      const nodeFirings = branches.length * 2, deliveries = branches.length;
      return {
        ...pass,
        temporal: {
          kind: "branch-temporal-v1",
          config: this.memory.dynamics,
          branches: [...branches].sort((a, b) => a.branchId.localeCompare(b.branchId)),
          integratorNodeFirings: nodeFirings,
          integratorDeliveries: deliveries
        },
        work: {
          ...pass.work,
          nodeFirings: pass.work.nodeFirings + nodeFirings,
          relationDeliveries: pass.work.relationDeliveries + deliveries,
          spikeEvents: branches.filter((b) => b.spiked).length
        }
      };
    }
    inspect() {
      return immutableCopy({
        ...super.inspect(),
        kind: "topology-activation-t2",
        dynamics: this.memory.dynamics,
        integrators: this.memory.branches.map((b) => b.inspectDynamics(this.session))
      });
    }
  };
  function createTemporalTopologyHarness(options) {
    const activation = new TemporalTopologySession(options.memory);
    return { ...createTopologyHarness({ ...options, activation }), activation };
  }

  // packages/plugin-harness/dist/monitor.js
  var import_core12 = __toESM(require_core(), 1);
  var STYLE_ID = "harness-monitor-style";
  var CSS = `
.hm { font: 13px/1.4 ui-monospace, "Cascadia Mono", Consolas, monospace; color: #d6dde6; height: 100%; display: flex; gap: 14px; padding: 10px 12px; box-sizing: border-box; overflow: hidden; background: #171b22; }
.hm-main { flex: 1 1 66%; min-width: 0; display: flex; flex-direction: column; gap: 6px; overflow: hidden; }
.hm-side { flex: 0 0 32%; min-width: 220px; display: flex; flex-direction: column; gap: 6px; overflow: hidden; border-left: 1px solid #2c3541; padding-left: 12px; }
.hm-head { display: flex; justify-content: space-between; gap: 8px; align-items: baseline; }
.hm-intention { font-weight: 700; font-size: 14px; color: #f2f5f8; text-transform: uppercase; letter-spacing: 0.04em; }
.hm-meta { color: #8b97a6; white-space: nowrap; font-size: 11px; }
.hm-desc { color: #aab4c0; max-height: 2.8em; overflow: hidden; font-size: 12px; }
.hm-cards { flex: 1 1 auto; min-height: 0; overflow-y: auto; overflow-x: hidden; display: flex; flex-direction: column; gap: 6px; padding-right: 4px; }
/* A card keeps its height: the list scrolls, a flex column would squeeze its children instead. */
.hm-card { flex: 0 0 auto; border: 1px solid #2c3541; background: #1d232c; border-radius: 3px; font-size: 12px; overflow: hidden; }
.hm-card.event { background: #232733; }
/* The card's head is its title band: green while the decision runs and once it is done, red when the harness stopped it, yellow for an event. */
.hm-card-head { display: flex; gap: 10px; align-items: baseline; padding: 7px 12px; cursor: pointer; user-select: none; background: #1f3d33; border-left: 5px solid #3fb08a; }
.hm-card.live .hm-card-head { background: #1f4a3b; border-left-color: #75e2ba; box-shadow: inset 0 0 0 1px #2f6f5a; }
.hm-card.event .hm-card-head { background: #3a3220; border-left-color: #e8c46a; }
.hm-card-head.failed { background: #3a1f1c; border-left-color: #e0574a; }
.hm-card-head.idle { background: #1d232c; border-left-color: #4f6d8a; }
.hm-card-head .title { font-size: 17px; line-height: 1.25; font-weight: 700; color: #dffbef; flex: 1 1 auto; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.hm-card-head .title.warn { color: #f0b06a; }
.hm-card-head .title.error { color: #ffb3aa; }
.hm-card-head.idle .title { color: #8b97a6; font-weight: 500; }
.hm-card.event .hm-card-head .title { color: #f6e3a8; }
.hm-card-head .idx { color: #dffbef; opacity: 0.8; }
.hm-card-sub { display: flex; gap: 10px; align-items: baseline; padding: 5px 12px; }
.hm-card-head .idx { color: #75e2ba; font-weight: 700; min-width: 28px; }
.hm-card.event .hm-card-head .idx { color: #e8c46a; }
.hm-card-head .cap { color: #f2f5f8; font-weight: 700; font-size: 13px; }
.hm-card-head .src { color: #8b97a6; }
.hm-card-head .src.policy { color: #e8c46a; }
.hm-card-head .when { margin-left: auto; color: #6f7b89; font-size: 11px; white-space: nowrap; }
.hm-card-head .fold { color: #6f7b89; font-size: 11px; }
.hm-card-body { padding: 0 10px 6px 10px; }
.hm-card-desc { color: #aab4c0; }
.hm-step { display: flex; gap: 8px; padding: 1px 0; color: #c9d3de; }
.hm-step .n { flex: 0 0 22px; color: #75e2ba; font-weight: 700; text-align: right; }
.hm-step .s { flex: 0 0 116px; color: #8b97a6; }
.hm-step.warn { color: #f0b06a; }
.hm-step.error { color: #ffb3aa; }
.hm-step.current { background: #1d2a26; }
.hm-card .input { color: #aab4c0; margin-top: 3px; }
.hm-card .why { color: #aab4c0; font-style: italic; margin-top: 2px; }
.hm-card .call { margin-top: 4px; padding: 4px 8px; background: #151a21; border-left: 3px solid #4f6d8a; color: #c9d3de; }
.hm-card .call .tag { color: #9fd0ff; font-weight: 700; margin-right: 6px; }
.hm-card .call.refused { border-left-color: #f0b06a; }
.hm-card .call.refused .tag { color: #f0b06a; }
.hm-card .call.deny, .hm-card .call.error { border-left-color: #e0574a; }
.hm-card .call.deny .tag, .hm-card .call.error .tag { color: #ffb3aa; }
.hm-outcome { display: inline-block; padding: 2px 10px; border-radius: 3px; font-weight: 700; font-size: 13px; margin-left: 6px; }
.hm-outcome.completed { background: #1f3d33; color: #75e2ba; }
.hm-outcome.refused { background: #3a2a1c; color: #f0b06a; }
.hm-outcome.deny { background: #3a1f1c; color: #ffb3aa; }
.hm-outcome.stopped { background: #33203a; color: #dcaaff; }
.hm-outcome.report, .hm-outcome.ask { background: #22303d; color: #9fd0ff; }
.hm-outcome.error { background: #3a1f1c; color: #ffb3aa; }
.hm-side-title { font-size: 11px; letter-spacing: 0.14em; text-transform: uppercase; color: #8b97a6; }
.hm-values { display: flex; gap: 14px; font-size: 18px; font-weight: 700; }
.hm-values small { display: block; font-size: 10px; font-weight: 500; color: #8b97a6; letter-spacing: 0.1em; }
.hm-canvas { width: 100%; height: 56px; display: block; background: #12161c; border: 1px solid #2c3541; }
.hm-console { flex: 1; min-height: 40px; overflow: auto; font-size: 12px; }
.hm-line { padding: 2px 0; border-bottom: 1px dotted #242b34; color: #c9d3de; }
.hm-line .tag { display: inline-block; min-width: 50px; color: #8b97a6; text-transform: uppercase; font-size: 10px; letter-spacing: 0.1em; }
.hm-line.crew .tag { color: #9fd0ff; }
.hm-line.ask .tag { color: #e8c46a; }
.hm-line.refusal .tag { color: #f0b06a; }
.hm-line.error .tag { color: #ffb3aa; }
`;
  var HarnessMonitorNode = class extends import_core12.RuntimeNode {
    renderableType = "Harness.Monitor:trace";
    inputPorts = [];
    outputPorts = [];
    /** The two series the strip draws; the host names them (the keys of its observation values). */
    series = [
      { key: "co2Ppm", label: "CO2 ppm", color: "#75e2ba", min: 0, max: 6e3 },
      { key: "speedPercent", label: "speed %", color: "#e8c46a", min: 0, max: 100 }
    ];
    /** The sentence shown when nothing runs. */
    idleText = "waiting";
    _host = null;
    _els = null;
    _canvas = null;
    _dirty = true;
    _intention = null;
    _now = null;
    /** Newest first. */
    _cards = [];
    _decisionCount = 0;
    /** Cards the reader opened or closed by hand; the newest decision is open unless closed. */
    _open = /* @__PURE__ */ new Map();
    _onCardsClick = null;
    _observations = [];
    _console = [];
    _width = 0;
    constructor(onsc = null, opsc = null, position) {
      super(onsc, opsc, position);
    }
    /** What the host running the harness reports; rendered on the next tick. */
    push(event) {
      switch (event.kind) {
        case "reset":
          this._intention = null;
          this._now = null;
          this._cards = [];
          this._decisionCount = 0;
          this._open.clear();
          this._observations = [];
          this._console = [];
          break;
        case "intention":
          this._intention = event;
          this._now = null;
          this._cards.unshift({ kind: "event", index: event.minute ?? 0, intention: event.id, description: event.description, minute: event.minute, at: Date.now(), steps: [] });
          break;
        case "stage":
          if (event.stage === "observe" && event.status === "start") {
            this._decisionCount++;
            this._cards.unshift({ kind: "decision", index: this._decisionCount, intention: this._intention?.id ?? "", minute: this._intention?.minute, at: Date.now(), steps: [] });
            while (this._cards.length > 80) {
              const dropped = this._cards.pop();
              if (dropped)
                this._open.delete(dropped);
            }
          }
          break;
        case "narrate": {
          const level = event.level ?? "info";
          const card = this._currentDecision();
          if (card) {
            card.steps.push({ stage: event.stage, text: event.text, level });
            card.title = event.now ?? event.text;
            card.titleLevel = level;
          }
          this._now = { text: event.now ?? event.text, level };
          break;
        }
        case "decision": {
          const card = this._currentDecision();
          if (card)
            card.decision = event;
          break;
        }
        case "call": {
          const card = this._currentDecision();
          if (card)
            card.call = event;
          break;
        }
        case "outcome": {
          const card = this._currentDecision();
          if (card)
            card.outcome = event;
          break;
        }
        case "observation":
          this._observations.push(event.values);
          if (this._observations.length > 200)
            this._observations.shift();
          break;
        case "console":
          this._console.push({ level: event.level, message: event.message });
          if (this._console.length > 100)
            this._console.shift();
          break;
      }
      this._dirty = true;
      this._scheduleRepaint();
    }
    /** The decision in progress: the newest decision card (an event card may sit above it only before its first decision). */
    _currentDecision() {
      return this._cards.find((c) => c.kind === "decision");
    }
    /**
     * The dashboard repaints its tiles on the runner's animation loop, which
     * does not run for a harness (the harness runtime steps the graph, not
     * the studio's player): the tile repaints itself, coalescing the pushes
     * of one step. A timer rather than an animation frame: frames stop in a
     * hidden tab, and a run that ends while the page is not on screen must
     * still be on the tile when it comes back.
     */
    _repaintScheduled = false;
    _scheduleRepaint() {
      if (this._repaintScheduled || !this._host)
        return;
      this._repaintScheduled = true;
      setTimeout(() => {
        this._repaintScheduled = false;
        try {
          this.repaint();
        } catch (e) {
          console.error("[harness-monitor] repaint failed:", e);
        }
      }, 0);
    }
    fire(_session, _t) {
    }
    mountInto(host) {
      this._host = host;
      if (!document.getElementById(STYLE_ID)) {
        const style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = CSS;
        document.head.appendChild(style);
      }
      host.innerHTML = "";
      const root = el("div", "hm");
      const main = el("div", "hm-main");
      const head = el("div", "hm-head");
      const intention = el("span", "hm-intention");
      const meta = el("span", "hm-meta");
      head.append(intention, meta);
      const desc = el("div", "hm-desc");
      const cards = el("div", "hm-cards");
      this._onCardsClick = (ev) => {
        const headEl = ev.target.closest(".hm-card-head");
        if (!headEl)
          return;
        const idx = Number(headEl.dataset.card);
        const card = this._cards[idx];
        if (!card || card.kind !== "decision")
          return;
        this._open.set(card, !this._isOpen(card, idx));
        this._dirty = true;
        this.repaint();
      };
      cards.addEventListener("click", this._onCardsClick);
      main.append(head, desc, cards);
      const side = el("div", "hm-side");
      const sideTitle = el("div", "hm-side-title");
      sideTitle.textContent = "the cabin";
      const values = el("div", "hm-values");
      const canvas = document.createElement("canvas");
      canvas.className = "hm-canvas";
      const consoleTitle = el("div", "hm-side-title");
      consoleTitle.textContent = "to the crew";
      const consoleEl = el("div", "hm-console");
      side.append(sideTitle, values, canvas, consoleTitle, consoleEl);
      root.append(main, side);
      host.appendChild(root);
      this._els = { intention, meta, desc, cards, values, console: consoleEl };
      this._canvas = canvas;
      this._dirty = true;
      this.repaint();
    }
    unmountFrom(host) {
      if (this._els && this._onCardsClick)
        this._els.cards.removeEventListener("click", this._onCardsClick);
      host.innerHTML = "";
      this._host = null;
      this._els = null;
      this._canvas = null;
    }
    onResize(width, _height) {
      this._width = width;
      this._dirty = true;
      this._scheduleRepaint();
    }
    repaint() {
      if (!this._dirty || !this._els || !this._host)
        return;
      this._dirty = false;
      const e = this._els;
      const it = this._intention;
      e.intention.textContent = it ? it.id.replace(/-/g, " ") : "idle";
      e.meta.textContent = it ? [it.minute !== void 0 ? `minute ${it.minute}` : "", it.guard ? `guard ${it.guard}` : "", it.reasoner ?? ""].filter(Boolean).join("  |  ") : "";
      e.desc.textContent = it?.description ?? "";
      const keepScroll = e.cards.scrollTop;
      e.cards.innerHTML = this._cards.length ? this._cards.map((c, i) => this._renderCard(c, i)).join("") : `<div class="hm-card"><div class="hm-card-head idle"><span class="title">${escape2(this._now?.text ?? this.idleText)}</span></div></div>`;
      e.cards.scrollTop = keepScroll;
      e.values.innerHTML = this.series.map((s) => `<span style="color:${s.color}">${this._lastValue(s.key)}<small>${escape2(s.label)}</small></span>`).join("");
      e.console.innerHTML = this._console.slice(-30).map((c) => `<div class="hm-line ${c.level}"><span class="tag">${escape2(c.level)}</span>${escape2(c.message)}</div>`).join("");
      e.console.scrollTop = e.console.scrollHeight;
      this._drawSeries();
    }
    _isOpen(card, index) {
      const chosen = this._open.get(card);
      if (chosen !== void 0)
        return chosen;
      return card === this._currentDecision() && index <= 1;
    }
    _renderCard(c, i) {
      const when = new Date(c.at).toLocaleTimeString();
      if (c.kind === "event") {
        return `<div class="hm-card event"><div class="hm-card-head" data-card="${i}"><span class="idx">${c.minute !== void 0 ? `min ${c.minute}` : "event"}</span><span class="title">${escape2(c.intention.replace(/-/g, " "))}</span><span class="when">${when}</span></div>` + (c.description ? `<div class="hm-card-body hm-card-desc">${escape2(c.description)}</div>` : "") + `</div>`;
      }
      const live = c === this._currentDecision() && !c.outcome;
      const open = this._isOpen(c, i);
      const d = c.decision;
      const o = c.outcome;
      const outcomeClass = o ? o.outcome.replace(/\s.*/, "") : "";
      const title = c.title ?? (live ? "deciding..." : "no decision");
      const head = `<div class="hm-card-head${c.titleLevel === "error" ? " failed" : ""}" data-card="${i}"><span class="idx">#${c.index}</span><span class="title ${c.titleLevel ?? "info"}" title="${escape2(title)}">${escape2(title)}</span><span class="when">${when}</span><span class="fold">${open ? "\u25BE" : "\u25B8"}</span></div><div class="hm-card-sub">` + (d ? `<span class="cap">${escape2(d.capabilityId)}</span><span class="src ${d.source}">${d.source === "policy" ? "learned replay" : "reasoned"}</span>` : `<span class="src">${live ? "in progress" : ""}</span>`) + (o ? `<span class="hm-outcome ${outcomeClass}">${escape2(o.outcome)}</span>` : "") + `</div>`;
      if (!open)
        return `<div class="hm-card${live ? " live" : ""}">${head}</div>`;
      const steps = c.steps.map((s, k) => `<div class="hm-step ${s.level}${live && k === c.steps.length - 1 ? " current" : ""}"><span class="n">${k + 1}</span><span class="s">${escape2(s.stage)}</span><span>${escape2(s.text)}</span></div>`).join("");
      const call = c.call ? `<div class="call ${escape2(c.call.outcome)}"><span class="tag">${escape2(c.call.capabilityId)} ${c.call.outcome === "completed" ? "answered" : c.call.outcome}${c.call.latencyMs !== void 0 ? ` in ${Math.round(c.call.latencyMs)} ms` : ""}:</span>${escape2(c.call.error ?? summarizeValue(c.call.output))}</div>` : "";
      const result = d ? `<div class="input">${escape2(compactJson(d.input))}</div>` + call + (d.rationale ? `<div class="why">${escape2(d.rationale)}</div>` : "") + (o?.error && !c.call ? `<div class="why">${escape2(o.error)}</div>` : "") : "";
      return `<div class="hm-card${live ? " live" : ""}">${head}<div class="hm-card-body">${steps}${result}</div></div>`;
    }
    _lastValue(key2) {
      const last = this._observations[this._observations.length - 1];
      const v = last?.[key2];
      return v === void 0 ? "-" : typeof v === "number" ? String(Math.round(v)) : String(v);
    }
    _drawSeries() {
      const canvas = this._canvas;
      if (!canvas)
        return;
      const w = Math.max(50, canvas.clientWidth || Math.round(this._width * 0.3) || 200);
      const h = 56;
      if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w;
        canvas.height = h;
      }
      const ctx = canvas.getContext("2d");
      if (!ctx)
        return;
      ctx.clearRect(0, 0, w, h);
      const n = this._observations.length;
      if (n < 2)
        return;
      for (const s of this.series) {
        const values = this._observations.map((obs) => typeof obs[s.key] === "number" ? obs[s.key] : NaN);
        const finite2 = values.filter((v) => Number.isFinite(v));
        if (!finite2.length)
          continue;
        const min = s.min ?? Math.min(...finite2);
        const max = s.max ?? Math.max(...finite2);
        const span = max - min || 1;
        ctx.strokeStyle = s.color;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        let started = false;
        values.forEach((v, i) => {
          if (!Number.isFinite(v))
            return;
          const x = i / (n - 1) * (w - 4) + 2;
          const y = h - 3 - (v - min) / span * (h - 6);
          if (!started) {
            ctx.moveTo(x, y);
            started = true;
          } else
            ctx.lineTo(x, y);
        });
        ctx.stroke();
      }
    }
  };
  function el(tag, className) {
    const e = document.createElement(tag);
    e.className = className;
    return e;
  }
  function escape2(s) {
    return s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c] ?? c);
  }
  function summarizeValue(value, limit = 560) {
    if (value === null || value === void 0)
      return "no output";
    if (typeof value !== "object")
      return String(value);
    const parts = [];
    const scalar = (v) => {
      if (v === null)
        return "null";
      if (typeof v === "number")
        return Number.isInteger(v) ? String(v) : String(Math.round(v * 10) / 10);
      if (typeof v === "boolean")
        return String(v);
      if (typeof v === "string")
        return v.length > 48 ? `"${v.slice(0, 45)}..."` : `"${v}"`;
      return null;
    };
    const fields = (o, max) => Object.entries(o).map(([k, v]) => {
      const sv = scalar(v);
      return sv === null ? null : `${k}: ${sv}`;
    }).filter((x) => x !== null).slice(0, max).join(", ");
    const list = (a) => {
      const shown = a.slice(0, 4).map((item) => item && typeof item === "object" && !Array.isArray(item) ? `{${fields(item, 5)}}` : scalar(item) ?? "...");
      return `[${shown.join(", ")}${a.length > 4 ? `, +${a.length - 4}` : ""}]`;
    };
    if (Array.isArray(value))
      return list(value);
    for (const [k, v] of Object.entries(value)) {
      const s = scalar(v);
      if (s !== null)
        parts.push(`${k}: ${s}`);
      else if (Array.isArray(v))
        parts.push(`${k}: ${list(v)}`);
      else if (v && typeof v === "object") {
        const inner = Object.entries(v).map(([ik, iv]) => {
          const is = scalar(iv);
          return is === null ? null : `${ik}: ${is}`;
        }).filter((x) => x !== null).slice(0, 6).join(", ");
        parts.push(`${k}: {${inner}${inner ? "" : "..."}}`);
      }
    }
    const text = parts.join(", ");
    return text.length > limit ? `${text.slice(0, limit - 3)}...` : text;
  }
  function compactJson(value) {
    if (!value || typeof value !== "object")
      return String(value ?? "");
    const text = Object.entries(value).map(([k, v]) => `${k}: ${typeof v === "string" ? v : JSON.stringify(v)}`).join(", ");
    return text.length > 160 ? `${text.slice(0, 157)}...` : text;
  }
  var MONITOR_NODES = [{ type: "Harness.Monitor:trace", label: "Run monitor", ctor: HarnessMonitorNode }];

  // packages/plugin-harness/dist/index.js
  var subPlugins = {};
  for (const category of new Set(HARNESS_NODES.map((entry) => entry.type.split(":")[0]))) {
    subPlugins[category] = { activate(ctx) {
      for (const entry of HARNESS_NODES.filter((entry2) => entry2.type.startsWith(`${category}:`))) {
        const sample = createHarnessNode(entry.type);
        ctx.nodes.register(entry.type, () => createHarnessNode(entry.type), {
          label: entry.label,
          category,
          inputPorts: sample.inputPorts,
          outputPorts: sample.outputPorts
        });
      }
    } };
  }
  subPlugins["Harness.Monitor"] = { activate(ctx) {
    for (const entry of MONITOR_NODES) {
      ctx.nodes.register(entry.type, () => new entry.ctor(), { label: entry.label, category: "Harness.Monitor", inputPorts: [], outputPorts: [] });
    }
  } };
  var plugin = { activate() {
  }, subPlugins };
  var index_default = plugin;
  return __toCommonJS(index_exports);
})();
//# sourceMappingURL=SpkPluginHarness.studio.js.map
