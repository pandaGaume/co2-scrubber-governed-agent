"use strict";
var SpkPluginHarness = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // harness-host:harness
  var require_harness = __commonJS({
    "harness-host:harness"(exports, module) {
      if (!globalThis.SpikypandaHarness) throw new Error("Load the shared SpikypandaHarness before its visual plugin");
      module.exports = globalThis.SpikypandaHarness;
    }
  });

  // packages/plugin-harness/dist/index.js
  var index_exports = {};
  __export(index_exports, {
    CapabilityExecutorNode: () => import_harness.CapabilityExecutorNode,
    ConfidenceGateNode: () => import_harness.ConfidenceGateNode,
    ContextualExperienceRecorderNode: () => import_harness2.ContextualExperienceRecorderNode,
    ContextualPolicyLookupNode: () => import_harness2.ContextualPolicyLookupNode,
    CueObserverNode: () => import_harness3.CueObserverNode,
    CuePolicyLookupNode: () => import_harness3.CuePolicyLookupNode,
    DecisionContextNode: () => import_harness.DecisionContextNode,
    DecisionMergeNode: () => import_harness.DecisionMergeNode,
    ExperienceRecorderNode: () => import_harness.ExperienceRecorderNode,
    FallbackRequestNode: () => import_harness.FallbackRequestNode,
    HARNESS_NODES: () => import_harness.HARNESS_NODES,
    HarnessNode: () => import_harness.HarnessNode,
    OutcomeEvaluatorNode: () => import_harness.OutcomeEvaluatorNode,
    OutcomeObserverNode: () => import_harness.OutcomeObserverNode,
    PolicyLookupNode: () => import_harness.PolicyLookupNode,
    ReasoningProviderNode: () => import_harness.ReasoningProviderNode,
    SafetyGuardNode: () => import_harness.SafetyGuardNode,
    StateObserverNode: () => import_harness.StateObserverNode,
    compileHarnessGraph: () => import_harness4.compileHarnessGraph,
    createGraphDriver: () => import_harness4.createGraphDriver,
    createHarnessNode: () => import_harness.createHarnessNode,
    createRuntimeGraphDriver: () => import_harness4.createRuntimeGraphDriver,
    default: () => index_default,
    harnessPort: () => import_harness.harnessPort,
    parseHarnessDefinition: () => import_harness4.parseHarnessDefinition,
    validateHarnessGraph: () => import_harness4.validateHarnessGraph
  });

  // packages/plugin-harness/dist/nodes.js
  var import_harness = __toESM(require_harness(), 1);
  var import_harness2 = __toESM(require_harness(), 1);
  var import_harness3 = __toESM(require_harness(), 1);

  // packages/plugin-harness/dist/graph.js
  var import_harness4 = __toESM(require_harness(), 1);

  // packages/plugin-harness/dist/index.js
  var subPlugins = {};
  for (const category of new Set(import_harness.HARNESS_NODES.map((entry) => entry.type.split(":")[0]))) {
    subPlugins[category] = { activate(ctx) {
      for (const entry of import_harness.HARNESS_NODES.filter((entry2) => entry2.type.startsWith(`${category}:`))) {
        const sample = (0, import_harness.createHarnessNode)(entry.type);
        ctx.nodes.register(entry.type, () => (0, import_harness.createHarnessNode)(entry.type), {
          label: entry.label,
          category,
          inputPorts: sample.inputPorts,
          outputPorts: sample.outputPorts
        });
      }
    } };
  }
  var plugin = { activate() {
  }, subPlugins };
  var index_default = plugin;
  return __toCommonJS(index_exports);
})();
//# sourceMappingURL=SpkPluginHarness.js.map
